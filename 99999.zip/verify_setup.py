# -*- coding: utf-8 -*-
"""
Simple verification script for ЖКХ Контроль Bot
Compatible with Python 2.7+ and 3.x
"""

import os
import sys

def check_python_version():
    """Check Python version"""
    print("🐍 Python version: %s" % sys.version)
    
    major, minor = sys.version_info[:2]
    
    if major < 3:
        print("❌ Python 3.7+ is required for this bot")
        print("   Current version: Python %d.%d" % (major, minor))
        print("   Please upgrade to Python 3.7 or higher")
        return False
    elif major == 3 and minor < 7:
        print("⚠️  Python 3.7+ is recommended")
        print("   Current version: Python %d.%d" % (major, minor))
        print("   Some features may not work correctly")
    else:
        print("✅ Python version is compatible")
    
    return True

def check_files():
    """Check if main files exist"""
    print("\n📁 Checking project files...")
    
    required_files = [
        'main.py',
        'config.py', 
        'requirements.txt',
        '.env'
    ]
    
    missing_files = []
    
    for filename in required_files:
        if os.path.exists(filename):
            print("✅ %s: exists" % filename)
        else:
            print("❌ %s: missing" % filename)
            missing_files.append(filename)
    
    if missing_files:
        print("\n❌ Missing files: %s" % ', '.join(missing_files))
        return False
    
    print("\n✅ All required files present")
    return True

def check_directories():
    """Check if required directories exist"""
    print("\n📂 Checking directories...")
    
    required_dirs = [
        'bot',
        'handlers', 
        'services',
        'database',
        'utils'
    ]
    
    for dirname in required_dirs:
        if os.path.isdir(dirname):
            print("✅ %s/: exists" % dirname)
        else:
            print("❌ %s/: missing" % dirname)
    
    print("✅ Directory structure checked")

def check_configuration():
    """Check basic configuration"""
    print("\n⚙️  Checking configuration...")
    
    if os.path.exists('.env'):
        with open('.env', 'r') as f:
            content = f.read()
            
        if 'TELEGRAM_BOT_TOKEN=' in content:
            print("✅ Telegram bot token: configured")
        else:
            print("❌ Telegram bot token: missing")
            
        if 'CLAUDE_API_KEY=' in content:
            print("✅ Claude API key: configured")
        else:
            print("❌ Claude API key: missing")
            
        if 'YANDEX_OAUTH_TOKEN=' in content:
            print("✅ Yandex OAuth token: configured")
        else:
            print("❌ Yandex OAuth token: missing")
    else:
        print("❌ .env file not found")

def print_header():
    """Print application header"""
    print("=" * 60)
    print("🏠 ЖКХ КОНТРОЛЬ - TELEGRAM BOT")
    print("=" * 60)
    print("📋 Version: 1.0.0")
    print("🤖 Telegram Bot for analyzing utility bills")
    print("🧠 Uses Claude Sonnet-4 and Yandex.Cloud")
    print("📊 Generates graphical reports")
    print("🔍 Detects billing violations")
    print("=" * 60)

def print_next_steps():
    """Print next steps"""
    print("\n📋 NEXT STEPS:")
    print("1. Install dependencies:")
    print("   Windows: install_dependencies.bat")
    print("   Linux/Mac: pip install -r requirements.txt")
    print("")
    print("2. Configure your .env file with API keys")
    print("")
    print("3. Test the bot configuration:")
    print("   python -c \"import sys; print('Python:', sys.version)\"")
    print("")
    print("4. Start the bot:")
    print("   python main.py")

def main():
    """Main verification function"""
    print_header()
    
    print("\n🔍 Starting verification...")
    
    # Run checks
    python_ok = check_python_version()
    files_ok = check_files()
    check_directories()
    check_configuration()
    
    # Summary
    print("\n" + "=" * 60)
    print("📋 VERIFICATION SUMMARY")
    print("=" * 60)
    
    if python_ok and files_ok:
        print("🎉 BASIC SETUP VERIFIED!")
        print("✅ Project structure is correct")
        print_next_steps()
    else:
        print("⚠️  SETUP INCOMPLETE")
        print("❌ Please fix the issues above")
        
        if not python_ok:
            print("\n🔧 Python version issue:")
            print("   Download Python 3.7+ from https://python.org")
            
        if not files_ok:
            print("\n🔧 Missing files issue:")
            print("   Make sure you have all project files")
    
    print("=" * 60)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n👋 Verification interrupted by user")
    except Exception as e:
        print("\n💥 Error during verification: %s" % str(e))