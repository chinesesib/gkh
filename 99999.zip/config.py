"""
Конфигурация приложения ЖКХ Контроль
"""

from typing import Optional


class Settings:
    """Настройки приложения"""
    
    def __init__(self):
        # Telegram Bot Configuration
        self.telegram_bot_token = "8380738925:AAEcsmEedzxfQ2CytKP6foeGIUxM3OkTXQo"
        
        # Yandex Cloud Configuration
        self.yandex_oauth_token = "y0__xDXps3DBxjB3RMg4t75pRQwosvY3AdjuRiw-xEDOlaE5coklxeFwYkPMQ"
        self.yandex_folder_id = "b1gl2pjs6vov1aq0lpno"
        self.yandex_service_account_id = "aje5bsp2qpt3g62hp34q"
        
        # Claude Sonnet-4 API Configuration
        self.claude_api_key = "sk-aitunnel-Z6MRcWBnbLhsrWq03PpQZ9PcMew7BkbJ"
        self.claude_base_url = "https://api.aitunnel.ru/v1/"
        
        # Database Configuration
        self.database_url = "sqlite:///database/zhkh_control.db"
        
        # Application Configuration
        self.debug = False
        self.log_level = "INFO"
        self.max_file_size_mb = 50
        
        # Cache Configuration
        self.cache_ttl_seconds = 3600
        
        # Regional Tariff API
        self.regional_tariff_api_url = "https://api.example.ru/tariffs/"
        
        # YooKassa Payment
        self.yookassa_shop_id = "1058856"
        self.yookassa_api_key = "test_kMWsMm-Xtl3IiYFGxBSrgQDrdxaJ245TihaHNp5-2Es"
        self.subscription_price = 200.0
        self.free_analyses_limit = 2


# Глобальный экземпляр настроек
settings = Settings()


# Yandex Cloud API URLs
class YandexCloudEndpoints:
    """Эндпоинты Yandex Cloud API"""
    
    IAM_TOKEN_URL = "https://iam.api.cloud.yandex.net/iam/v1/tokens"
    FOUNDATION_MODELS_URL = "https://llm.api.cloud.yandex.net/foundationModels/v1/"
    

# Константы для анализа ЖКХ
class UtilityConstants:
    """Константы для анализа коммунальных услуг"""
    
    # Типы услуг ЖКХ
    UTILITY_TYPES = {
        "холодная_вода": ["холодная вода", "хвс", "водоснабжение холодное"],
        "горячая_вода": ["горячая вода", "гвс", "водоснабжение горячее"],
        "отопление": ["отопление", "теплоснабжение", "тепловая энергия"],
        "электроэнергия": ["электроэнергия", "электричество", "эл. энергия"],
        "газ": ["газ", "газоснабжение", "природный газ"],
        "водоотведение": ["водоотведение", "канализация", "стоки"],
        "капитальный_ремонт": ["капитальный ремонт", "кап. ремонт", "взнос на кр"],
        "содержание": ["содержание жилья", "содержание", "управление"],
        "уборка": ["уборка", "клининг", "санитарное содержание"]
    }
    
    # Единицы измерения
    MEASUREMENT_UNITS = {
        "м³": ["куб.м", "м3", "кубометр"],
        "кВт·ч": ["квт*ч", "квтч", "киловатт-час"],
        "Гкал": ["гкал", "гигакалория"],
        "м²": ["кв.м", "м2", "квадратный метр"]
    }


# Настройки графических отчетов
class ReportSettings:
    """Настройки для генерации отчетов"""
    
    CHART_COLORS = {
        "normal": "#4CAF50",      # Зеленый - норма
        "warning": "#FF9800",     # Оранжевый - предупреждение
        "danger": "#F44336",      # Красный - превышение
        "info": "#2196F3"         # Синий - информация
    }
    
    CHART_SIZE = (12, 8)
    DPI = 300
    FONT_SIZE = 12