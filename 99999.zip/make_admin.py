#!/usr/bin/env python3
"""
Script to make user 1043893977 an administrator
"""

import asyncio
import sys
import os

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database.connection import make_user_admin, database

async def main():
    """Make user 1043893977 an administrator"""
    print("Making user 1043893977 an administrator...")
    
    try:
        # Initialize the database
        await database.init_database()
        
        # Make the user an admin
        await make_user_admin(1043893977)
        
        print("✅ User 1043893977 has been made an administrator!")
        
    except Exception as e:
        print(f"❌ Error making user admin: {e}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())