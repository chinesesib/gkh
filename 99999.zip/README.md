# 🏠 ЖКХ Контроль - Telegram Bot

Современный Telegram-бот на русском языке для анализа квитанций ЖКХ с использованием искусственного интеллекта.

## 🎯 Возможности

- **📄 Анализ PDF квитанций** - Извлечение и анализ данных из квитанций ЖКХ
- **🧠 ИИ-анализ** - Использование Claude Sonnet-4 для выявления нарушений
- **🔍 Проверка тарифов** - Сравнение с региональными нормативами
- **📊 Графические отчеты** - Визуализация результатов анализа
- **💰 Расчет переплат** - Определение финансовых потерь
- **⚠️ Выявление нарушений** - Обнаружение завышенных тарифов
- **📋 История анализов** - Сохранение результатов в базе данных

## 🛠️ Технологии

- **Python 3.7+** - Основной язык разработки
- **aiogram 3.x** - Telegram Bot framework
- **Claude Sonnet-4** - ИИ для анализа текста
- **Yandex.Cloud** - Обработка PDF документов
- **SQLite** - База данных для хранения результатов
- **Matplotlib/Seaborn** - Генерация графиков
- **AsyncIO** - Асинхронная обработка

## 📦 Установка

### 1. Клонирование проекта

```bash
git clone <repository-url>
cd zhkh-control-bot
```

### 2. Установка зависимостей

#### Windows:
```bash
install_dependencies.bat
```

#### Linux/Mac:
```bash
pip install -r requirements.txt
```

### 3. Настройка окружения

Скопируйте `.env.template` в `.env` и заполните настройки:

```bash
cp .env.template .env
```

Отредактируйте `.env` файл:

```env
# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN=your_bot_token_here

# Yandex Cloud Configuration  
YANDEX_OAUTH_TOKEN=your_oauth_token
YANDEX_FOLDER_ID=your_folder_id
YANDEX_SERVICE_ACCOUNT_ID=your_service_account_id

# Claude Sonnet-4 API Configuration
CLAUDE_API_KEY=your_claude_api_key
CLAUDE_BASE_URL=https://api.aitunnel.ru/v1/

# Other settings...
```

### 4. Тестирование конфигурации

```bash
python test_bot.py
```

### 5. Запуск бота

```bash
python main.py
```

## ⚙️ Конфигурация

### Telegram Bot Token

1. Создайте бота через [@BotFather](https://t.me/botfather)
2. Получите токен и добавьте в `.env`

### Yandex.Cloud API

1. Зарегистрируйтесь в [Yandex.Cloud](https://cloud.yandex.ru/)
2. Создайте OAuth-токен в [Yandex.OAuth](https://oauth.yandex.ru/)
3. Обменяйте OAuth-токен на IAM-токен:

```bash
curl --request POST \
  --data '{"yandexPassportOauthToken":"<OAuth-токен>"}' \
  https://iam.api.cloud.yandex.net/iam/v1/tokens
```

### Claude Sonnet-4 API

1. Получите API ключ от провайдера
2. Добавьте в конфигурацию

## 📋 Использование

### Основные команды

- `/start` - Запуск бота и главное меню
- `/help` - Справка по использованию
- `/feedback` - Отправка обратной связи

### Процесс анализа

1. **Загрузка файла** - Отправьте PDF квитанцию боту
2. **Обработка** - Бот извлекает текст и анализирует данные
3. **Анализ ИИ** - Claude Sonnet-4 проверяет тарифы
4. **Результаты** - Получите отчет с выявленными нарушениями

### Формат квитанций

- **Формат**: PDF файлы
- **Размер**: до 50 МБ
- **Требования**: Читаемый текст (не скан изображения)

## 🗂️ Структура проекта

```
zhkh-control-bot/
├── main.py                 # Точка входа
├── config.py              # Конфигурация
├── requirements.txt       # Зависимости
├── .env                   # Переменные окружения
├── test_bot.py           # Тесты
├── bot/                  # Основной код бота
│   ├── __init__.py
│   └── middleware.py     # Middleware
├── handlers/             # Обработчики событий
│   ├── __init__.py
│   ├── start_handler.py
│   ├── document_handler.py
│   ├── help_handler.py
│   └── admin_handler.py
├── services/             # Бизнес-логика
│   ├── __init__.py
│   ├── claude_service.py      # Claude AI
│   ├── yandex_cloud_service.py # Yandex.Cloud
│   ├── pdf_service.py         # PDF обработка
│   ├── analysis_service.py    # Анализ квитанций
│   └── report_service.py      # Генерация отчетов
├── database/             # База данных
│   ├── __init__.py
│   └── connection.py
├── utils/               # Утилиты
│   ├── __init__.py
│   └── logger.py        # Логирование
├── models/              # Модели данных
├── tests/               # Тесты
├── logs/                # Логи
└── reports/             # Сгенерированные отчеты
```

## 🔧 Разработка

### Добавление новых функций

1. **Обработчики** - Добавьте в `handlers/`
2. **Сервисы** - Бизнес-логика в `services/`
3. **Модели** - Структуры данных в `models/`

### Тестирование

```bash
# Запуск тестов конфигурации
python test_bot.py

# Запуск unit-тестов
pytest tests/
```

### Логирование

Логи сохраняются в директории `logs/`:
- `zhkh_control_YYYYMMDD.log` - Общие логи
- `errors_YYYYMMDD.log` - Ошибки
- `business_YYYYMMDD.log` - Бизнес-события

## 📊 Мониторинг

### Административные команды

- `/admin` - Административная панель
- `/stats` - Статистика использования
- `/health` - Проверка состояния системы
- `/logs` - Просмотр логов

### Метрики

- Количество пользователей
- Анализы документов
- Выявленные нарушения
- Производительность системы

## 🛡️ Безопасность

- **Конфиденциальность** - Личные данные удаляются после анализа
- **Шифрование** - Все API запросы защищены
- **Валидация** - Проверка загружаемых файлов
- **Логирование** - Аудит всех действий

## 🚀 Производство

### Развертывание

1. **Сервер** - Linux VPS/Dedicated
2. **Python** - Версия 3.7+
3. **Systemd** - Для автозапуска
4. **Nginx** - Reverse proxy (опционально)

### Systemd Service

Создайте `/etc/systemd/system/zhkh-bot.service`:

```ini
[Unit]
Description=ЖКХ Контроль Telegram Bot
After=network.target

[Service]
Type=simple
User=zhkh-bot
WorkingDirectory=/opt/zhkh-control-bot
ExecStart=/opt/zhkh-control-bot/venv/bin/python main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable zhkh-bot
sudo systemctl start zhkh-bot
```

## 🐛 Устранение неполадок

### Частые проблемы

1. **SSL ошибки** - Используйте `--trusted-host` при установке пакетов
2. **Ошибки импорта** - Проверьте установку зависимостей
3. **API недоступен** - Проверьте токены и сетевое подключение
4. **PDF не обрабатывается** - Убедитесь в качестве файла

### Логи ошибок

```bash
tail -f logs/errors_$(date +%Y%m%d).log
```

## 📞 Поддержка

- **Issues** - Создавайте issue в репозитории
- **Documentation** - Проверьте README и комментарии в коде
- **Logs** - Анализируйте логи для диагностики

## 📄 Лицензия

MIT License - см. файл LICENSE

## 🤝 Вклад в проект

1. Fork репозитория
2. Создайте feature branch
3. Внесите изменения
4. Создайте Pull Request

---

**ЖКХ Контроль** - Защищаем права потребителей коммунальных услуг! 🏠💪