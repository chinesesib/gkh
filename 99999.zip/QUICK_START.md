# 🚀 Quick Start Guide - ЖКХ Контроль Bot

## ⚡ Fast Setup (5 minutes)

### Step 1: Check Python Version
```bash
python --version
```
**Required: Python 3.7 or higher**

If you have Python 2.7, download Python 3.7+ from https://python.org

### Step 2: Install Dependencies
```bash
# Windows
install_dependencies.bat

# Or manually
pip install aiogram aiohttp PyPDF2 pdfplumber pymupdf openai requests pandas numpy matplotlib seaborn plotly pillow aiosqlite sqlalchemy python-dotenv pydantic pydantic-settings loguru asyncio-throttle cachetools pytest pytest-asyncio
```

### Step 3: Setup API Keys

Edit the `.env` file:

```env
# Get from @BotFather on Telegram
TELEGRAM_BOT_TOKEN=8380738925:AAEcsmEedzxfQ2CytKP6foeGIUxM3OkTXQo

# Get from Yandex.Cloud
YANDEX_OAUTH_TOKEN=y0__xDXps3DBxjB3RMg4t75pRQwosvY3AdjuRiw-xEDOlaE5coklxeFwYkPMQ
YANDEX_FOLDER_ID=b1gl2pjs6vov1aq0lpno
YANDEX_SERVICE_ACCOUNT_ID=aje5bsp2qpt3g62hp34q

# Get from AI service provider
CLAUDE_API_KEY=sk-aitunnel-Z6MRcWBnbLhsrWq03PpQZ9PcMew7BkbJ
CLAUDE_BASE_URL=https://api.aitunnel.ru/v1/
```

### Step 4: Verify Setup
```bash
python verify_setup.py
```

### Step 5: Run the Bot
```bash
python main.py
```

## 📱 Bot Usage

1. **Start** - Send `/start` to the bot
2. **Upload** - Send a PDF utility bill
3. **Wait** - Analysis takes 1-2 minutes  
4. **Review** - Check results and violations
5. **Download** - Get detailed reports

## 🛠️ API Setup Details

### Telegram Bot Token
1. Message [@BotFather](https://t.me/botfather)
2. Create new bot: `/newbot`
3. Choose name: `ЖКХ Контроль`
4. Choose username: `zhkh_control_bot`
5. Copy the token

### Yandex.Cloud Setup
1. Register at [cloud.yandex.ru](https://cloud.yandex.ru)
2. Create OAuth token at [oauth.yandex.ru](https://oauth.yandex.ru)
3. Get IAM token:
```bash
curl --request POST \
  --data '{"yandexPassportOauthToken":"YOUR_OAUTH_TOKEN"}' \
  https://iam.api.cloud.yandex.net/iam/v1/tokens
```

### Claude API Setup
1. Get API key from provider
2. Test connection:
```bash
curl -H "Authorization: Bearer YOUR_API_KEY" \
     -H "Content-Type: application/json" \
     -d '{"model":"claude-sonnet-4","messages":[{"role":"user","content":"test"}],"max_tokens":10}' \
     https://api.aitunnel.ru/v1/chat/completions
```

## 🚨 Troubleshooting

### "Module not found" errors
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### SSL Certificate errors
```bash
pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org -r requirements.txt
```

### "Permission denied" errors
```bash
# Windows: Run as Administrator
# Linux/Mac: Use sudo or virtual environment
```

### Bot doesn't respond
1. Check bot token in .env
2. Verify internet connection
3. Check logs in `logs/` directory

## 📊 Features Overview

| Feature | Description | Status |
|---------|-------------|---------|
| PDF Analysis | Extract text from utility bills | ✅ Ready |
| AI Analysis | Claude Sonnet-4 violation detection | ✅ Ready |
| Tariff Comparison | Compare with regional standards | ✅ Ready |
| Graphical Reports | Charts and visualizations | ✅ Ready |
| Database Storage | SQLite for analysis history | ✅ Ready |
| Multi-language | Russian interface | ✅ Ready |
| Admin Panel | Monitoring and statistics | ✅ Ready |

## 🔧 Advanced Configuration

### Custom Regional Tariffs
Edit `config.py` and modify `UtilityConstants.UTILITY_TYPES`

### Logging Levels
Set in `.env`:
```env
LOG_LEVEL=DEBUG  # DEBUG, INFO, WARNING, ERROR
```

### File Size Limits
```env
MAX_FILE_SIZE_MB=50  # Maximum PDF size in MB
```

### Database Location
```env
DATABASE_URL=sqlite:///custom_path.db
```

## 📞 Support

- 📧 Issues: Create GitHub issue
- 📋 Logs: Check `logs/` directory
- 🔍 Debug: Run `python verify_setup.py`
- 📖 Docs: See README.md for full documentation

---
**Made with ❤️ for Russian utility consumers** 🏠