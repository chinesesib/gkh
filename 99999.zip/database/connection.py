"""
Подключение к базе данных и инициализация схемы
"""

import asyncio
import aiosqlite
from pathlib import Path
import logging
from datetime import datetime

from config import settings

logger = logging.getLogger(__name__)


class Database:
    """Класс для работы с базой данных"""
    
    def __init__(self):
        # Извлекаем путь к файлу БД из URL
        db_url = settings.database_url
        if db_url.startswith('sqlite:///'):
            self.db_path = db_url[10:]  # Убираем 'sqlite:///'
        else:
            self.db_path = "zhkh_control.db"
    
    async def init_database(self):
        """Инициализация базы данных"""
        
        logger.info("🗄️ Инициализация базы данных...")
        
        async with aiosqlite.connect(self.db_path) as db:
            # Создаем таблицы
            await self._create_tables(db)
            await db.commit()
        
        logger.info("✅ База данных инициализирована")
    
    async def _create_tables(self, db: aiosqlite.Connection):
        """Создание таблиц в базе данных"""
        
        # Таблица пользователей
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                telegram_id INTEGER UNIQUE NOT NULL,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                language_code TEXT,
                phone_number TEXT,
                device_mac_address TEXT,
                full_name TEXT,
                address TEXT,
                analyses_count INTEGER DEFAULT 0,
                subscription_expires_at DATETIME,
                subscription_type TEXT DEFAULT 'free',
                last_notification_sent DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT TRUE,
                is_admin BOOLEAN DEFAULT FALSE,
                is_authenticated BOOLEAN DEFAULT FALSE
            )
        """)
        
        # Таблица анализов документов
        await db.execute("""
            CREATE TABLE IF NOT EXISTS analyses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                file_name TEXT NOT NULL,
                file_size INTEGER,
                analysis_started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                analysis_completed_at DATETIME,
                analysis_duration REAL,
                status TEXT DEFAULT 'processing',
                violations_count INTEGER DEFAULT 0,
                total_overpayment REAL DEFAULT 0,
                result_json TEXT,
                error_message TEXT,
                cached BOOLEAN DEFAULT FALSE,
                FOREIGN KEY (user_id) REFERENCES users (telegram_id)
            )
        """)
        
        # Таблица нарушений
        await db.execute("""
            CREATE TABLE IF NOT EXISTS violations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                analysis_id INTEGER NOT NULL,
                service_name TEXT NOT NULL,
                violation_type TEXT NOT NULL,
                description TEXT,
                financial_impact REAL,
                recommendation TEXT,
                FOREIGN KEY (analysis_id) REFERENCES analyses (id)
            )
        """)
        
        # Таблица услуг в анализах
        await db.execute("""
            CREATE TABLE IF NOT EXISTS services (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                analysis_id INTEGER NOT NULL,
                service_name TEXT NOT NULL,
                tariff_actual REAL,
                tariff_standard REAL,
                consumption REAL,
                unit TEXT,
                amount_charged REAL,
                amount_should_be REAL,
                overpayment REAL DEFAULT 0,
                is_violation BOOLEAN DEFAULT FALSE,
                FOREIGN KEY (analysis_id) REFERENCES analyses (id)
            )
        """)
        
        # Таблица обратной связи
        await db.execute("""
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                message TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                is_processed BOOLEAN DEFAULT FALSE,
                admin_response TEXT,
                FOREIGN KEY (user_id) REFERENCES users (telegram_id)
            )
        """)
        
        # Таблица отчетов
        await db.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                analysis_id INTEGER NOT NULL,
                report_type TEXT NOT NULL,
                file_path TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (analysis_id) REFERENCES analyses (id)
            )
        """)
        
        # Таблица рассылок (broadcast messages)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS broadcast_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_id INTEGER NOT NULL,
                message_text TEXT NOT NULL,
                sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                recipients_count INTEGER,
                FOREIGN KEY (admin_id) REFERENCES users (telegram_id)
            )
        """)
        
        # Таблица платежей
        await db.execute("""
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                payment_id TEXT UNIQUE NOT NULL,
                amount REAL NOT NULL,
                currency TEXT DEFAULT 'RUB',
                status TEXT NOT NULL,
                subscription_type TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                completed_at DATETIME,
                yookassa_payment_id TEXT,
                error_message TEXT,
                FOREIGN KEY (user_id) REFERENCES users (telegram_id)
            )
        """)
        
        # Таблица шаблонов документов
        await db.execute("""
            CREATE TABLE IF NOT EXISTS document_templates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                template_type TEXT NOT NULL,
                template_name TEXT NOT NULL,
                template_content TEXT NOT NULL,
                variables TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Таблица сгенерированных документов
        await db.execute("""
            CREATE TABLE IF NOT EXISTS generated_documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                analysis_id INTEGER,
                template_id INTEGER NOT NULL,
                document_type TEXT NOT NULL,
                file_path TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (telegram_id),
                FOREIGN KEY (analysis_id) REFERENCES analyses (id),
                FOREIGN KEY (template_id) REFERENCES document_templates (id)
            )
        """)
        
        # Индексы для производительности
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users (telegram_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_phone ON users (phone_number)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_mac ON users (device_mac_address)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_analyses_user_id ON analyses (user_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_analyses_status ON analyses (status)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_violations_analysis_id ON violations (analysis_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_services_analysis_id ON services (analysis_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments (user_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_payments_status ON payments (status)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_generated_docs_user_id ON generated_documents (user_id)")
        
        logger.info("📋 Таблицы базы данных созданы")


# Глобальный экземпляр
database = Database()


async def init_database():
    """Функция инициализации базы данных"""
    await database.init_database()


async def get_db():
    """Получение соединения с базой данных"""
    return aiosqlite.connect(database.db_path)


async def make_user_admin(telegram_id: int):
    """Назначить пользователя администратором"""
    async with aiosqlite.connect(database.db_path) as db:
        await db.execute("""
            UPDATE users 
            SET is_admin = TRUE 
            WHERE telegram_id = ?
        """, (telegram_id,))
        await db.commit()
        logger.info(f"Пользователь {telegram_id} назначен администратором")


async def is_user_admin(telegram_id: int) -> bool:
    """Проверить, является ли пользователь администратором"""
    async with aiosqlite.connect(database.db_path) as db:
        cursor = await db.execute("""
            SELECT is_admin FROM users WHERE telegram_id = ?
        """, (telegram_id,))
        row = await cursor.fetchone()
        return row and row[0]


async def get_all_users() -> list:
    """Получить всех пользователей бота"""
    async with aiosqlite.connect(database.db_path) as db:
        cursor = await db.execute("""
            SELECT telegram_id FROM users WHERE is_active = TRUE
        """)
        rows = await cursor.fetchall()
        return [row[0] for row in rows]


async def save_broadcast_message(admin_id: int, message_text: str, recipients_count: int):
    """Сохранить информацию о рассылке в базе данных"""
    async with aiosqlite.connect(database.db_path) as db:
        cursor = await db.execute("""
            INSERT INTO broadcast_messages (admin_id, message_text, recipients_count)
            VALUES (?, ?, ?)
        """, (admin_id, message_text, recipients_count))
        await db.commit()
        return cursor.lastrowid


async def authenticate_user_by_phone(telegram_id: int, phone_number: str, device_mac: str = None) -> bool:
    """Аутентификация пользователя по номеру телефона"""
    async with aiosqlite.connect(database.db_path) as db:
        # Проверяем, есть ли уже пользователь с этим номером
        cursor = await db.execute("""
            SELECT telegram_id FROM users 
            WHERE phone_number = ? AND telegram_id != ?
        """, (phone_number, telegram_id))
        existing_user = await cursor.fetchone()
        
        if existing_user:
            logger.warning(f"Номер телефона {phone_number} уже зарегистрирован")
            return False
        
        # Обновляем данные пользователя
        await db.execute("""
            UPDATE users 
            SET phone_number = ?, device_mac_address = ?, is_authenticated = TRUE
            WHERE telegram_id = ?
        """, (phone_number, device_mac, telegram_id))
        await db.commit()
        
        logger.info(f"Пользователь {telegram_id} аутентифицирован")
        return True


async def get_user_subscription_info(telegram_id: int) -> dict:
    """Получить информацию о подписке пользователя"""
    async with aiosqlite.connect(database.db_path) as db:
        cursor = await db.execute("""
            SELECT analyses_count, subscription_expires_at, subscription_type
            FROM users WHERE telegram_id = ?
        """, (telegram_id,))
        row = await cursor.fetchone()
        
        if not row:
            return {'analyses_count': 0, 'subscription_expires_at': None, 'subscription_type': 'free'}
        
        return {
            'analyses_count': row[0] or 0,
            'subscription_expires_at': row[1],
            'subscription_type': row[2] or 'free'
        }


async def can_user_analyze(telegram_id: int) -> tuple[bool, str]:
    """Проверить, может ли пользователь анализировать квитанции"""
    from datetime import datetime
    
    subscription_info = await get_user_subscription_info(telegram_id)
    analyses_count = subscription_info['analyses_count']
    subscription_expires_at = subscription_info['subscription_expires_at']
    subscription_type = subscription_info['subscription_type']
    
    # Проверяем бесплатные анализы (2 штуки)
    if analyses_count < 2:
        return True, 'free_usage'
    
    # Проверяем платную подписку
    if subscription_expires_at:
        expires_date = datetime.fromisoformat(subscription_expires_at.replace('Z', '+00:00'))
        if datetime.now() < expires_date:
            return True, 'subscription_active'
    
    return False, 'subscription_required'


async def increment_user_analyses(telegram_id: int):
    """Увеличить счетчик анализов пользователя"""
    async with aiosqlite.connect(database.db_path) as db:
        await db.execute("""
            UPDATE users 
            SET analyses_count = analyses_count + 1
            WHERE telegram_id = ?
        """, (telegram_id,))
        await db.commit()


async def grant_subscription(telegram_id: int, subscription_type: str = 'monthly', days: int = 30):
    """Выдать подписку пользователю"""
    from datetime import datetime, timedelta
    
    expires_at = datetime.now() + timedelta(days=days)
    
    async with aiosqlite.connect(database.db_path) as db:
        await db.execute("""
            UPDATE users 
            SET subscription_type = ?, subscription_expires_at = ?
            WHERE telegram_id = ?
        """, (subscription_type, expires_at.isoformat(), telegram_id))
        await db.commit()
        
    logger.info(f"Пользователю {telegram_id} выдана подписка на {days} дней")


async def save_payment(user_id: int, payment_id: str, amount: float, subscription_type: str) -> int:
    """Сохранить информацию о платеже"""
    async with aiosqlite.connect(database.db_path) as db:
        cursor = await db.execute("""
            INSERT INTO payments (user_id, payment_id, amount, status, subscription_type)
            VALUES (?, ?, ?, 'pending', ?)
        """, (user_id, payment_id, amount, subscription_type))
        await db.commit()
        return cursor.lastrowid


async def update_payment_status(payment_id: str, status: str, yookassa_payment_id: str = None, error_message: str = None):
    """Обновить статус платежа"""
    from datetime import datetime
    
    async with aiosqlite.connect(database.db_path) as db:
        if status == 'completed':
            await db.execute("""
                UPDATE payments 
                SET status = ?, completed_at = ?, yookassa_payment_id = ?
                WHERE payment_id = ?
            """, (status, datetime.now().isoformat(), yookassa_payment_id, payment_id))
        else:
            await db.execute("""
                UPDATE payments 
                SET status = ?, error_message = ?
                WHERE payment_id = ?
            """, (status, error_message, payment_id))
        await db.commit()


async def get_payment_info(payment_id: str) -> dict:
    """Получить информацию о платеже"""
    async with aiosqlite.connect(database.db_path) as db:
        cursor = await db.execute("""
            SELECT user_id, amount, status, subscription_type, created_at
            FROM payments WHERE payment_id = ?
        """, (payment_id,))
        row = await cursor.fetchone()
        
        if not row:
            return None
            
        return {
            'user_id': row[0],
            'amount': row[1],
            'status': row[2],
            'subscription_type': row[3],
            'created_at': row[4]
        }


async def update_user_profile_from_receipt(telegram_id: int, full_name: str = None, address: str = None):
    """Обновить профиль пользователя данными из квитанции"""
    async with aiosqlite.connect(database.db_path) as db:
        update_fields = []
        values = []
        
        if full_name:
            update_fields.append("full_name = ?")
            values.append(full_name)
        
        if address:
            update_fields.append("address = ?")
            values.append(address)
        
        if update_fields:
            values.append(telegram_id)
            query = f"UPDATE users SET {', '.join(update_fields)} WHERE telegram_id = ?"
            await db.execute(query, values)
            await db.commit()
            logger.info(f"Профиль пользователя {telegram_id} обновлен")


async def get_users_with_expiring_subscriptions() -> list:
    """Получить пользователей с заканчивающимися подписками"""
    from datetime import datetime, timedelta
    
    # Пользователи, у которых подписка заканчивается через 7 дней
    notification_date = datetime.now() + timedelta(days=7)
    week_ago = datetime.now() - timedelta(days=7)
    
    async with aiosqlite.connect(database.db_path) as db:
        cursor = await db.execute("""
            SELECT telegram_id, subscription_expires_at 
            FROM users 
            WHERE subscription_expires_at IS NOT NULL 
            AND subscription_expires_at <= ?
            AND subscription_expires_at > ?
            AND (last_notification_sent IS NULL OR last_notification_sent < ?)
        """, (notification_date.isoformat(), datetime.now().isoformat(), week_ago.isoformat()))
        
        return await cursor.fetchall()


async def update_notification_sent(telegram_id: int):
    """Отметить, что уведомление отправлено"""
    from datetime import datetime
    
    async with aiosqlite.connect(database.db_path) as db:
        await db.execute("""
            UPDATE users 
            SET last_notification_sent = ?
            WHERE telegram_id = ?
        """, (datetime.now().isoformat(), telegram_id))
        await db.commit()


async def create_or_update_user(telegram_id: int, username: str = None, 
                               first_name: str = None, last_name: str = None, 
                               language_code: str = None):
    """Создать или обновить пользователя в базе данных"""
    async with aiosqlite.connect(database.db_path) as db:
        # Проверяем, существует ли пользователь
        cursor = await db.execute("SELECT id FROM users WHERE telegram_id = ?", (telegram_id,))
        existing_user = await cursor.fetchone()
        
        if existing_user:
            # Обновляем существующего пользователя
            await db.execute("""
                UPDATE users 
                SET username = ?, first_name = ?, last_name = ?, 
                    language_code = ?, last_activity = ?
                WHERE telegram_id = ?
            """, (username, first_name, last_name, language_code, 
                  datetime.now().isoformat(), telegram_id))
            logger.info(f"Пользователь {telegram_id} обновлен")
        else:
            # Создаем нового пользователя
            await db.execute("""
                INSERT INTO users (telegram_id, username, first_name, last_name, language_code, created_at, last_activity)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (telegram_id, username, first_name, last_name, language_code,
                  datetime.now().isoformat(), datetime.now().isoformat()))
            logger.info(f"Создан новый пользователь {telegram_id}")
        
        await db.commit()


async def is_user_authenticated(telegram_id: int) -> bool:
    """Проверить, прошел ли пользователь аутентификацию по телефону"""
    async with aiosqlite.connect(database.db_path) as db:
        cursor = await db.execute(
            "SELECT is_authenticated FROM users WHERE telegram_id = ?",
            (telegram_id,)
        )
        row = await cursor.fetchone()
        return bool(row and row[0])