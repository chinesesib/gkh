#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script to check available analyses in the database
"""

import asyncio
import sys
import os

# Add the project root to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.analysis_service import analysis_service

async def check_analyses():
    """Check what analyses are available in the database"""
    print("🔍 Checking available analyses in the database...")
    
    try:
        # Try to get analysis history for a test user
        history = await analysis_service.get_analysis_history(1043893977, 10)
        print(f"✅ Found {len(history)} analyses in history")
        
        for i, analysis in enumerate(history, 1):
            print(f"\n{i}. Analysis ID: {analysis['id']}")
            print(f"   File name: {analysis['file_name']}")
            print(f"   Status: {analysis['status']}")
            print(f"   Violations count: {analysis['violations_count']}")
            print(f"   Total overpayment: {analysis['total_overpayment']}")
            
        # Try to get details for analysis ID 2 specifically
        if len(history) > 0:
            analysis_id = history[0]['id']  # Get the first analysis ID
            print(f"\n🔍 Getting details for analysis ID {analysis_id}...")
            details = await analysis_service.get_analysis_details(analysis_id, 1043893977)
            if details:
                print("✅ Analysis details found:")
                print(f"   Summary: {details.get('summary', {})}")
                print(f"   Services count: {len(details.get('services', []))}")
                print(f"   Violations count: {len(details.get('violations', []))}")
            else:
                print("❌ No details found for this analysis")
        else:
            print("❌ No analyses found in history")
            
    except Exception as e:
        print(f"❌ Error checking analyses: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(check_analyses())