# -*- coding: utf-8 -*-
"""
Базовый тест конфигурации бота ЖКХ Контроль
"""

import asyncio
import sys
import os

# Добавляем корневую директорию в path
sys.path.insert(0, os.path.dirname(__file__))

from config import settings
from utils.logger import setup_logging
import logging


async def test_configuration():
    """Тест конфигурации приложения"""
    
    print("🔧 Тестирование конфигурации...")
    
    # Проверяем обязательные настройки
    required_settings = [
        'telegram_bot_token',
        'yandex_oauth_token', 
        'yandex_folder_id',
        'claude_api_key'
    ]
    
    missing_settings = []
    
    for setting in required_settings:
        value = getattr(settings, setting, None)
        if not value or value == "":
            missing_settings.append(setting)
        else:
            print(f"✅ {setting}: настроен")
    
    if missing_settings:
        print(f"❌ Отсутствуют настройки: {', '.join(missing_settings)}")
        return False
    
    print("✅ Все обязательные настройки присутствуют")
    return True


async def test_imports():
    """Тест импорта модулей"""
    
    print("\n📦 Тестирование импорта модулей...")
    
    modules_to_test = [
        ('config', 'Конфигурация'),
        ('utils.logger', 'Логирование'),
        ('bot.middleware', 'Middleware'),
        ('handlers', 'Обработчики'),
        ('services.claude_service', 'Claude сервис'),
        ('services.yandex_cloud_service', 'Yandex.Cloud сервис'),
        ('services.pdf_service', 'PDF сервис'),
        ('services.analysis_service', 'Сервис анализа'),
        ('services.report_service', 'Сервис отчетов'),
        ('database.connection', 'База данных')
    ]
    
    failed_imports = []
    
    for module_name, description in modules_to_test:
        try:
            __import__(module_name)
            print(f"✅ {description}: импорт успешен")
        except ImportError as e:
            print(f"❌ {description}: ошибка импорта - {e}")
            failed_imports.append(module_name)
        except Exception as e:
            print(f"⚠️ {description}: предупреждение - {e}")
    
    if failed_imports:
        print(f"\n❌ Неудачные импорты: {', '.join(failed_imports)}")
        return False
    
    print("\n✅ Все модули импортированы успешно")
    return True


async def test_database():
    """Тест базы данных"""
    
    print("\n🗄️ Тестирование базы данных...")
    
    try:
        from database.connection import init_database
        await init_database()
        print("✅ База данных инициализирована")
        return True
    except Exception as e:
        print(f"❌ Ошибка базы данных: {e}")
        return False


async def test_services():
    """Тест сервисов"""
    
    print("\n🔧 Тестирование сервисов...")
    
    # Тест конфигурации Yandex.Cloud
    try:
        from services.yandex_cloud_service import YandexCloudService
        async with YandexCloudService() as yandex_service:
            health = await yandex_service.health_check()
            if health.get('status') == 'healthy':
                print("✅ Yandex.Cloud: сервис доступен")
            else:
                print(f"⚠️ Yandex.Cloud: {health.get('status')} - {health.get('error', '')}")
    except Exception as e:
        print(f"❌ Yandex.Cloud: ошибка - {e}")
    
    # Тест Claude API
    try:
        from services.claude_service import ClaudeService
        claude_service = ClaudeService()
        health = await claude_service.health_check()
        if health.get('status') == 'healthy':
            print("✅ Claude API: сервис доступен")
        else:
            print(f"⚠️ Claude API: {health.get('status')} - {health.get('error', '')}")
    except Exception as e:
        print(f"❌ Claude API: ошибка - {e}")
    
    # Тест PDF сервиса
    try:
        from services.pdf_service import PDFService
        pdf_service = PDFService()
        print("✅ PDF сервис: инициализирован")
    except Exception as e:
        print(f"❌ PDF сервис: ошибка - {e}")


def print_project_info():
    """Вывод информации о проекте"""
    
    print("\n" + "="*60)
    print("🏠 ЖКХ КОНТРОЛЬ - TELEGRAM BOT")
    print("="*60)
    print("📋 Версия: 1.0.0")
    print("🤖 Telegram Bot для анализа квитанций ЖКХ")
    print("🧠 Использует Claude Sonnet-4 и Yandex.Cloud")
    print("📊 Генерирует графические отчеты")
    print("🔍 Выявляет нарушения тарификации")
    print("="*60)


async def main():
    """Основная функция тестирования"""
    
    setup_logging()
    
    print_project_info()
    
    print("\n🚀 Запуск тестирования системы...")
    
    # Запускаем тесты
    tests = [
        test_configuration(),
        test_imports(),
        test_database(),
        test_services()
    ]
    
    results = await asyncio.gather(*tests, return_exceptions=True)
    
    # Подводим итоги
    print("\n" + "="*60)
    print("📋 РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ")
    print("="*60)
    
    success_count = sum(1 for result in results if result is True)
    total_tests = len(tests)
    
    if success_count == total_tests:
        print("🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО!")
        print("✅ Бот готов к запуску")
        print("\nДля запуска выполните:")
        print("python main.py")
    else:
        print(f"⚠️ Пройдено {success_count} из {total_tests} тестов")
        print("❌ Необходимо исправить ошибки перед запуском")
        
        print("\n🔧 Рекомендации:")
        print("1. Установите зависимости: install_dependencies.bat")
        print("2. Проверьте настройки в .env файле")
        print("3. Убедитесь в доступности интернета")
    
    print("="*60)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 Тестирование прервано пользователем")
    except Exception as e:
        print(f"\n💥 Критическая ошибка тестирования: {e}")