"""
Middleware для Telegram Bot ЖКХ Контроль
"""

import time
from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, User, Message
from aiogram import Dispatcher
import logging

from bot.rate_limiting_middleware import rate_limiter

logger = logging.getLogger(__name__)


class LoggingMiddleware(BaseMiddleware):
    """Middleware для логирования запросов"""
    
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        start_time = time.time()
        
        # Получение информации о пользователе
        user: User = data.get('event_from_user')
        user_info = f"User {user.id} (@{user.username})" if user else "Unknown user"
        
        # Получение типа события
        event_type = type(event).__name__
        
        logger.info(f"📨 {event_type} from {user_info}")
        
        try:
            result = await handler(event, data)
            
            # Логирование времени выполнения
            execution_time = round(time.time() - start_time, 3)
            logger.info(f"✅ Processed in {execution_time}s")
            
            return result
            
        except Exception as e:
            execution_time = round(time.time() - start_time, 3)
            logger.error(f"❌ Error after {execution_time}s: {e}")
            raise


class UserTrackingMiddleware(BaseMiddleware):
    """Middleware для отслеживания активности пользователей"""
    
    def __init__(self):
        self.user_sessions = {}
    
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        user: User = data.get('event_from_user')
        
        if user:
            # Обновление информации о пользователе
            self.user_sessions[user.id] = {
                'user_id': user.id,
                'username': user.username,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'last_activity': time.time(),
                'language_code': user.language_code
            }
            
            # Создание или обновление пользователя в базе данных
            try:
                from database.connection import create_or_update_user
                await create_or_update_user(
                    telegram_id=user.id,
                    username=user.username,
                    first_name=user.first_name,
                    last_name=user.last_name,
                    language_code=user.language_code
                )
            except Exception as e:
                logger.error(f"Ошибка создания/обновления пользователя {user.id}: {e}")
            
            # Добавление данных в контекст
            data['user_session'] = self.user_sessions[user.id]
        
        return await handler(event, data)


class FileSizeMiddleware(BaseMiddleware):
    """Middleware для проверки размера файлов"""
    
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        # Проверяем только сообщения с документами
        if isinstance(event, Message) and event.document:
            from config import settings
            
            max_size_bytes = settings.max_file_size_mb * 1024 * 1024
            file_size = event.document.file_size
            
            if file_size and file_size > max_size_bytes:
                await event.reply(
                    f"❌ Файл слишком большой!\n"
                    f"📊 Размер файла: {file_size / (1024*1024):.1f} МБ\n"
                    f"📏 Максимальный размер: {settings.max_file_size_mb} МБ\n\n"
                    f"Пожалуйста, выберите файл меньшего размера."
                )
                return  # Прекращаем обработку
        
        return await handler(event, data)


class ErrorHandlingMiddleware(BaseMiddleware):
    """Middleware для обработки ошибок"""
    
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        try:
            return await handler(event, data)
        except Exception as e:
            logger.exception(f"Unhandled error in handler: {e}")
            
            # Отправляем сообщение об ошибке пользователю
            if isinstance(event, Message):
                await event.reply(
                    "😔 Произошла внутренняя ошибка при обработке вашего запроса.\n"
                    "Пожалуйста, попробуйте позже или обратитесь к администратору."
                )
            
            # Не подавляем исключение для дальнейшей обработки
            raise


class AuthRequiredMiddleware(BaseMiddleware):
    """Блокирует действия для неаутентифицированных пользователей (без телефона)"""
    
    ALLOWED_MESSAGE_COMMANDS = {"start", "auth"}
    ALLOWED_CALLBACK_PREFIXES = {"start_auth"}
    
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        try:
            user: User = data.get('event_from_user')
            if not user:
                return await handler(event, data)
            
            from aiogram.types import Message, CallbackQuery
            # Разрешаем старт/аутентификацию и отправку контакта
            if isinstance(event, Message):
                text = (event.text or "").lstrip("/")
                cmd = text.split()[0].lower() if text else ""
                if cmd in self.ALLOWED_MESSAGE_COMMANDS or event.contact:
                    return await handler(event, data)
            elif isinstance(event, CallbackQuery):
                data_str = event.data or ""
                if any(data_str.startswith(p) for p in self.ALLOWED_CALLBACK_PREFIXES):
                    return await handler(event, data)
            
            # Проверяем статус аутентификации в БД
            from database.connection import is_user_authenticated
            if await is_user_authenticated(user.id):
                return await handler(event, data)
            
            # Блокируем: просим пройти аутентификацию
            auth_hint = (
                "🔐 Для продолжения подтвердите номер телефона.\n\n"
                "Откройте меню: 'Аутентификация' → '📞 Поделиться номером телефона'"
            )
            if isinstance(event, Message):
                await event.reply(auth_hint)
            elif isinstance(event, CallbackQuery):
                await event.answer("Требуется аутентификация", show_alert=True)
                try:
                    await event.message.answer(auth_hint)
                except Exception:
                    pass
            return
        except Exception as e:
            logger.error(f"AuthRequiredMiddleware error: {e}")
            return await handler(event, data)

def setup_middleware(dp: Dispatcher):
    """Настройка всех middleware"""
    
    logger.info("🔧 Настройка middleware...")
    
    # Порядок важен! Middleware выполняются в порядке регистрации
    
    # 1. Обработка ошибок (самый первый)
    dp.message.middleware(ErrorHandlingMiddleware())
    dp.callback_query.middleware(ErrorHandlingMiddleware())
    
    # 2. Rate Limiting (защита от злоупотреблений)
    dp.message.middleware(rate_limiter)
    dp.callback_query.middleware(rate_limiter)
    
    # 3. Логирование
    dp.message.middleware(LoggingMiddleware())
    dp.callback_query.middleware(LoggingMiddleware())
    
    # 4. Отслеживание пользователя и запись в БД
    dp.message.middleware(UserTrackingMiddleware())
    dp.callback_query.middleware(UserTrackingMiddleware())

    # 5. Требование аутентификации: должно идти после записи пользователя, но до бизнес-логики
    dp.message.middleware(AuthRequiredMiddleware())
    dp.callback_query.middleware(AuthRequiredMiddleware())
    
    # 6. Проверка размера файлов (только для сообщений)
    dp.message.middleware(FileSizeMiddleware())
    
    logger.info("✅ Middleware настроены успешно")