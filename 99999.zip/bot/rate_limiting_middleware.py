# -*- coding: utf-8 -*-
"""
Rate Limiting Middleware для Telegram Bot ЖКХ Контроль
Ограничивает частоту запросов от пользователей для предотвращения злоупотреблений
"""

import time
import asyncio
from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, User, Message, CallbackQuery
import logging

logger = logging.getLogger(__name__)


class RateLimitingMiddleware(BaseMiddleware):
    """Middleware для ограничения частоты запросов"""
    
    def __init__(self):
        # Словарь для хранения времени последних запросов
        self.user_requests = {}
        
        # Лимиты (запросов в минуту)
        self.limits = {
            'message': 10,      # 10 сообщений в минуту
            'callback': 30,      # 30 нажатий кнопок в минуту
            'file_upload': 3,   # 3 загрузки файлов в минуту
            'analysis': 2       # 2 анализа в минуту
        }
        
        # Время блокировки (в секундах)
        self.block_duration = 300  # 5 минут
        
        # Словарь заблокированных пользователей
        self.blocked_users = {}
    
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        
        user: User = data.get('event_from_user')
        if not user:
            return await handler(event, data)
        
        user_id = user.id
        current_time = time.time()
        
        # Проверяем, не заблокирован ли пользователь
        if user_id in self.blocked_users:
            if current_time - self.blocked_users[user_id] < self.block_duration:
                remaining_time = int(self.block_duration - (current_time - self.blocked_users[user_id]))
                await self._send_rate_limit_message(event, remaining_time)
                return
            else:
                # Разблокируем пользователя
                del self.blocked_users[user_id]
        
        # Определяем тип запроса
        request_type = self._get_request_type(event)
        if not request_type:
            return await handler(event, data)
        
        # Проверяем лимиты
        if await self._check_rate_limit(user_id, request_type, current_time):
            return await handler(event, data)
        else:
            # Превышен лимит - блокируем пользователя
            self.blocked_users[user_id] = current_time
            await self._send_rate_limit_message(event, self.block_duration)
            return
    
    def _get_request_type(self, event: TelegramObject) -> str:
        """Определяет тип запроса для применения соответствующих лимитов"""
        
        if isinstance(event, Message):
            if event.document or event.photo:
                return 'file_upload'
            elif event.text and any(keyword in event.text.lower() for keyword in ['анализ', 'analyze', 'проверить']):
                return 'analysis'
            else:
                return 'message'
        
        elif isinstance(event, CallbackQuery):
            if event.data and any(keyword in event.data.lower() for keyword in ['analyze', 'analysis', 'upload']):
                return 'analysis'
            else:
                return 'callback'
        
        return None
    
    async def _check_rate_limit(self, user_id: int, request_type: str, current_time: float) -> bool:
        """Проверяет, не превышен ли лимит запросов"""
        
        if user_id not in self.user_requests:
            self.user_requests[user_id] = {}
        
        if request_type not in self.user_requests[user_id]:
            self.user_requests[user_id][request_type] = []
        
        # Очищаем старые запросы (старше минуты)
        minute_ago = current_time - 60
        self.user_requests[user_id][request_type] = [
            req_time for req_time in self.user_requests[user_id][request_type]
            if req_time > minute_ago
        ]
        
        # Проверяем лимит
        limit = self.limits.get(request_type, 10)
        if len(self.user_requests[user_id][request_type]) >= limit:
            logger.warning(f"Rate limit exceeded for user {user_id}, type: {request_type}")
            return False
        
        # Добавляем текущий запрос
        self.user_requests[user_id][request_type].append(current_time)
        return True
    
    async def _send_rate_limit_message(self, event: TelegramObject, remaining_time: int):
        """Отправляет сообщение о превышении лимита"""
        
        minutes = remaining_time // 60
        seconds = remaining_time % 60
        
        if minutes > 0:
            time_str = f"{minutes} мин {seconds} сек"
        else:
            time_str = f"{seconds} сек"
        
        message_text = f"""
🚫 <b>Превышен лимит запросов</b>

Вы слишком часто отправляете запросы. 
Пожалуйста, подождите <b>{time_str}</b> перед следующим запросом.

<b>Лимиты:</b>
• 📨 Сообщения: {self.limits['message']} в минуту
• 🔘 Нажатия кнопок: {self.limits['callback']} в минуту  
• 📄 Загрузка файлов: {self.limits['file_upload']} в минуту
• 🔍 Анализ квитанций: {self.limits['analysis']} в минуту

<i>Это ограничение помогает обеспечить стабильную работу бота для всех пользователей.</i>
"""
        
        try:
            if isinstance(event, Message):
                await event.reply(message_text, parse_mode="HTML")
            elif isinstance(event, CallbackQuery):
                await event.answer("Превышен лимит запросов", show_alert=True)
                if event.message:
                    await event.message.answer(message_text, parse_mode="HTML")
        except Exception as e:
            logger.error(f"Error sending rate limit message: {e}")
    
    def get_user_stats(self, user_id: int) -> Dict[str, Any]:
        """Возвращает статистику запросов пользователя"""
        
        if user_id not in self.user_requests:
            return {"requests": {}, "blocked": False}
        
        current_time = time.time()
        stats = {}
        
        for request_type, requests in self.user_requests[user_id].items():
            # Считаем запросы за последнюю минуту
            recent_requests = [req for req in requests if current_time - req < 60]
            stats[request_type] = {
                "last_minute": len(recent_requests),
                "limit": self.limits.get(request_type, 10),
                "remaining": max(0, self.limits.get(request_type, 10) - len(recent_requests))
            }
        
        return {
            "requests": stats,
            "blocked": user_id in self.blocked_users,
            "block_remaining": int(self.block_duration - (current_time - self.blocked_users[user_id])) if user_id in self.blocked_users else 0
        }
    
    def cleanup_old_data(self):
        """Очищает старые данные для экономии памяти"""
        
        current_time = time.time()
        cleanup_threshold = current_time - 3600  # 1 час
        
        # Очищаем старые запросы
        for user_id in list(self.user_requests.keys()):
            for request_type in list(self.user_requests[user_id].keys()):
                self.user_requests[user_id][request_type] = [
                    req_time for req_time in self.user_requests[user_id][request_type]
                    if req_time > cleanup_threshold
                ]
                
                # Удаляем пустые записи
                if not self.user_requests[user_id][request_type]:
                    del self.user_requests[user_id][request_type]
            
            # Удаляем пользователей без запросов
            if not self.user_requests[user_id]:
                del self.user_requests[user_id]
        
        # Очищаем старые блокировки
        expired_blocks = [
            user_id for user_id, block_time in self.blocked_users.items()
            if current_time - block_time > self.block_duration
        ]
        
        for user_id in expired_blocks:
            del self.blocked_users[user_id]
        
        logger.info(f"Rate limiting cleanup: removed {len(expired_blocks)} expired blocks")


# Глобальный экземпляр для использования в других частях приложения
rate_limiter = RateLimitingMiddleware()


async def start_rate_limit_cleanup():
    """Запускает периодическую очистку данных rate limiting"""
    
    while True:
        try:
            await asyncio.sleep(300)  # Каждые 5 минут
            rate_limiter.cleanup_old_data()
        except Exception as e:
            logger.error(f"Error in rate limit cleanup: {e}")

