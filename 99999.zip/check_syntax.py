# -*- coding: utf-8 -*-
"""
Syntax checker for all Python files in the project
"""

import os
import py_compile
import sys

def check_syntax(file_path):
    """Check syntax of a Python file"""
    try:
        py_compile.compile(file_path, doraise=True)
        return True, None
    except py_compile.PyCompileError as e:
        return False, str(e)

def check_all_files():
    """Check syntax of all Python files"""
    
    files_to_check = [
        'main.py',
        'config.py',
        'utils/logger.py',
        'bot/middleware.py',
        'handlers/__init__.py',
        'handlers/start_handler.py',
        'handlers/document_handler.py', 
        'handlers/help_handler.py',
        'handlers/admin_handler.py',
        'services/claude_service.py',
        'services/yandex_cloud_service.py',
        'services/pdf_service.py',
        'services/analysis_service.py',
        'services/report_service.py',
        'database/connection.py'
    ]
    
    print("Checking Python syntax for all files...\n")
    
    all_good = True
    
    for file_path in files_to_check:
        if os.path.exists(file_path):
            is_valid, error = check_syntax(file_path)
            if is_valid:
                print("OK: %s - Syntax valid" % file_path)
            else:
                print("ERROR: %s - Syntax Error: %s" % (file_path, error))
                all_good = False
        else:
            print("WARNING: %s - File not found" % file_path)
    
    print("\n" + "="*50)
    if all_good:
        print("SUCCESS: ALL FILES HAVE VALID SYNTAX!")
        print("No syntax errors found")
    else:
        print("FAILURE: SYNTAX ERRORS FOUND")
        print("Please fix the errors above")
    print("="*50)
    
    return all_good

if __name__ == "__main__":
    success = check_all_files()
    sys.exit(0 if success else 1)