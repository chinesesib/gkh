"""
Онбординг и FAQ/чек‑листы
"""

from aiogram import Router, F
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, Message

router = Router()


def _help_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Как оспорить начисления", callback_data="faq_dispute")],
        [InlineKeyboardButton(text="Как подготовить квитанцию", callback_data="faq_prepare")],
        [InlineKeyboardButton(text="Чек‑лист: перед подачей жалобы", callback_data="faq_checklist")],
        [InlineKeyboardButton(text="← Назад", callback_data="back_to_start")],
    ])


@router.callback_query(F.data == "help")
async def callback_help(callback_query: CallbackQuery):
    text = (
        "❓ <b>Помощь и обучение</b>\n\n"
        "Здесь собраны краткие инструкции и чек‑листы по спорным ситуациям."
    )
    await callback_query.message.edit_text(text, reply_markup=_help_keyboard(), parse_mode="HTML")
    await callback_query.answer()


@router.callback_query(F.data == "faq_dispute")
async def callback_faq_dispute(callback_query: CallbackQuery):
    text = (
        "📑 <b>Как оспорить начисления</b>\n\n"
        "1) Загрузите квитанцию → выполните анализ.\n"
        "2) Откройте анализ → \"Создать документы\".\n"
        "3) Подайте жалобу в УК/ЖИ (бот сформирует шаблоны).\n"
        "4) Отследите сроки ответа (30 дней).\n"
    )
    await callback_query.message.edit_text(text, reply_markup=_help_keyboard(), parse_mode="HTML")
    await callback_query.answer()


@router.callback_query(F.data == "faq_prepare")
async def callback_faq_prepare(callback_query: CallbackQuery):
    text = (
        "🧾 <b>Как подготовить квитанцию</b>\n\n"
        "• Сделайте четкое фото/скан или скачайте PDF из ЛК.\n"
        "• Убедитесь, что видны ФИО, адрес, суммы и расшифровка услуг.\n"
        "• Не редактируйте цифры, не закрывайте части страницы.\n"
    )
    await callback_query.message.edit_text(text, reply_markup=_help_keyboard(), parse_mode="HTML")
    await callback_query.answer()


@router.callback_query(F.data == "faq_checklist")
async def callback_faq_checklist(callback_query: CallbackQuery):
    text = (
        "✅ <b>Чек‑лист перед жалобой</b>\n\n"
        "☑ Анализ выполнен, нарушения зафиксированы.\n"
        "☑ Адрес и ФИО корректно распознаны.\n"
        "☑ Приложены копии квитанций за период.\n"
        "☑ Рассчитана переплата.\n"
    )
    await callback_query.message.edit_text(text, reply_markup=_help_keyboard(), parse_mode="HTML")
    await callback_query.answer()






