"""
Обработчики команды помощи и FAQ
"""

from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
import logging

logger = logging.getLogger(__name__)

router = Router()


@router.message(Command("help"))
async def cmd_help(message: Message):
    """Обработка команды /help"""
    
    help_text = """
❓ <b>Справка по ЖКХ Контроль</b>

<b>Основные команды:</b>
/start - Главное меню
/help - Эта справка
/feedback - Обратная связь

<b>Как пользоваться ботом:</b>
1️⃣ Отправьте PDF файл квитанции ЖКХ
2️⃣ Дождитесь завершения анализа (1-2 минуты)
3️⃣ Изучите результаты и рекомендации

<b>Что проверяется:</b>
• 💧 Тарифы на воду (холодная/горячая)
• 🔥 Тарифы на отопление
• ⚡ Тарифы на электричество
• 🏠 Плата за содержание жилья
• 🔧 Взносы на капремонт
• 🚿 Плата за водоотведение

<b>Результаты анализа:</b>
• ✅ Соответствие региональным нормативам
• ⚠️ Выявленные нарушения тарификации
• 💰 Расчет переплат по каждой услуге
• 📊 Графическое сравнение тарифов
• 📋 Рекомендации по дальнейшим действиям

<b>Требования к файлам:</b>
• Формат: PDF
• Размер: до 50 МБ
• Текст должен быть читаемым

<b>🔒 Безопасность:</b>
Ваши данные обрабатываются конфиденциально и автоматически удаляются после анализа.
"""
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📄 Загрузить квитанцию", callback_data="upload_receipt")
        ],
        [
            InlineKeyboardButton(text="❓ FAQ", callback_data="faq"),
            InlineKeyboardButton(text="📞 Поддержка", callback_data="support")
        ],
        [
            InlineKeyboardButton(text="🏠 Главное меню", callback_data="back_to_start")
        ]
    ])
    
    await message.answer(help_text, reply_markup=keyboard, parse_mode="HTML")


@router.callback_query(F.data == "faq")
async def callback_faq(callback_query):
    """Часто задаваемые вопросы"""
    
    faq_text = """
❓ <b>Часто задаваемые вопросы</b>

<b>Q: Какие файлы поддерживаются?</b>
A: Поддерживаются только PDF файлы с текстовым содержимым. Сканы изображений могут обрабатываться неточно.

<b>Q: Сколько времени занимает анализ?</b>
A: Обычно от 30 секунд до 2 минут, в зависимости от размера файла и загруженности сервера.

<b>Q: Откуда берутся нормативные тарифы?</b>
A: Тарифы сравниваются с официальными региональными нормативами, утвержденными регулирующими органами.

<b>Q: Можно ли анализировать квитанции любого региона?</b>
A: Да, бот поддерживает анализ квитанций из любого региона России.

<b>Q: Что делать, если обнаружены нарушения?</b>
A: Рекомендуется обратиться в управляющую компанию с требованием разъяснений. При необходимости - в жилищную инспекцию.

<b>Q: Сохраняются ли мои данные?</b>
A: Личные данные из квитанций автоматически удаляются после анализа. Сохраняется только обезличенная статистика.

<b>Q: Файл не обрабатывается, что делать?</b>
A: Проверьте, что файл в формате PDF и содержит читаемый текст (не просто картинку). Размер не должен превышать 50 МБ.

<b>Q: Можно ли получить расшифровку по каждой позиции?</b>
A: Да, используйте кнопку "Подробный отчет" для получения детальной расшифровки по всем услугам.
"""
    
    await callback_query.message.edit_text(
        faq_text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="← Назад к справке", callback_data="back_to_help")]
        ])
    )
    
    await callback_query.answer()


@router.callback_query(F.data == "support")
async def callback_support(callback_query):
    """Информация о поддержке"""
    
    support_text = """
📞 <b>Поддержка пользователей</b>

<b>Техническая поддержка:</b>
• Время работы: Пн-Пт 9:00-18:00 (МСК)
• Email: support@zhkh-control.ru
• Telegram: @zhkh_support_bot

<b>По вопросам анализа:</b>
• Консультации по результатам анализа
• Помощь в интерпретации нарушений
• Советы по взаимодействию с УК

<b>Сообщить об ошибке:</b>
Используйте команду /feedback для отправки сообщения о проблеме или предложения по улучшению.

<b>Часто встречающиеся проблемы:</b>

🔸 <b>Файл не загружается</b>
• Проверьте формат (только PDF)
• Убедитесь, что размер до 50 МБ
• Попробуйте конвертировать файл заново

🔸 <b>Текст не распознается</b>  
• Файл должен содержать текст, а не просто картинку
• Качество скана должно быть достаточным
• Попробуйте получить оригинальную PDF квитанцию

🔸 <b>Неточные результаты</b>
• Убедитесь, что квитанция содержит все необходимые данные
• Проверьте правильность указанного региона
• Сообщите нам о проблеме через /feedback

<b>Обновления:</b>
Следите за обновлениями функций в нашем канале: @zhkh_control_news
"""
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📝 Обратная связь", callback_data="feedback_form")
        ],
        [
            InlineKeyboardButton(text="← Назад к справке", callback_data="back_to_help")
        ]
    ])
    
    await callback_query.message.edit_text(
        support_text,
        parse_mode="HTML",
        reply_markup=keyboard
    )
    
    await callback_query.answer()


@router.callback_query(F.data == "feedback_form")
async def callback_feedback_form(callback_query):
    """Форма обратной связи"""
    
    feedback_text = """
📝 <b>Обратная связь</b>

Чтобы отправить сообщение разработчикам, используйте команду:

<code>/feedback Ваше сообщение</code>

<b>Примеры:</b>
<code>/feedback Не могу загрузить файл квитанции от МосЭнерго</code>
<code>/feedback Предлагаю добавить анализ газовых тарифов</code>
<code>/feedback Отличный бот, спасибо за работу!</code>

<b>Что можно сообщить:</b>
• 🐛 Ошибки в работе бота
• 💡 Предложения по улучшению
• ❓ Вопросы по функциональности
• 👍 Отзывы о качестве работы
• 📋 Проблемы с конкретными квитанциями

<b>Время ответа:</b>
Обычно отвечаем в течение 1-2 рабочих дней.

Ваше мнение поможет нам сделать бот лучше! 🙏
"""
    
    await callback_query.message.edit_text(
        feedback_text,
        parse_mode="HTML", 
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="← Назад к поддержке", callback_data="support")]
        ])
    )
    
    await callback_query.answer()


@router.callback_query(F.data == "back_to_help")
async def callback_back_to_help(callback_query):
    """Возврат к справке"""
    
    help_text = """
❓ <b>Справка по ЖКХ Контроль</b>

<b>Основные команды:</b>
/start - Главное меню
/help - Эта справка
/feedback - Обратная связь

<b>Как пользоваться ботом:</b>
1️⃣ Отправьте PDF файл квитанции ЖКХ
2️⃣ Дождитесь завершения анализа (1-2 минуты)
3️⃣ Изучите результаты и рекомендации

<b>Что проверяется:</b>
• 💧 Тарифы на воду (холодная/горячая)
• 🔥 Тарифы на отопление
• ⚡ Тарифы на электричество
• 🏠 Плата за содержание жилья
• 🔧 Взносы на капремонт
• 🚿 Плата за водоотведение

<b>Результаты анализа:</b>
• ✅ Соответствие региональным нормативам
• ⚠️ Выявленные нарушения тарификации
• 💰 Расчет переплат по каждой услуге
• 📊 Графическое сравнение тарифов
• 📋 Рекомендации по дальнейшим действиям

<b>🔒 Безопасность:</b>
Ваши данные обрабатываются конфиденциально и автоматически удаляются после анализа.
"""
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📄 Загрузить квитанцию", callback_data="upload_receipt")
        ],
        [
            InlineKeyboardButton(text="❓ FAQ", callback_data="faq"),
            InlineKeyboardButton(text="📞 Поддержка", callback_data="support")
        ],
        [
            InlineKeyboardButton(text="🏠 Главное меню", callback_data="back_to_start")
        ]
    ])
    
    await callback_query.message.edit_text(
        help_text,
        parse_mode="HTML",
        reply_markup=keyboard
    )
    
    await callback_query.answer()


@router.message(Command("feedback"))
async def cmd_feedback(message: Message):
    """Обработка команды обратной связи"""
    
    # Извлекаем текст сообщения после команды
    feedback_text = message.text[len("/feedback"):].strip()
    
    if not feedback_text:
        await message.reply(
            "📝 <b>Отправка обратной связи</b>\n\n"
            "Используйте команду в формате:\n"
            "<code>/feedback Ваше сообщение</code>\n\n"
            "<b>Пример:</b>\n"
            "<code>/feedback Не работает загрузка PDF файлов</code>",
            parse_mode="HTML"
        )
        return
    
    # TODO: Сохранить feedback в базу данных или отправить администраторам
    
    user = message.from_user
    logger.info(f"📝 Обратная связь от {user.id} (@{user.username}): {feedback_text[:100]}...")
    
    await message.reply(
        "✅ <b>Спасибо за обратную связь!</b>\n\n"
        "Ваше сообщение получено и будет рассмотрено в ближайшее время.\n"
        "Если требуется ответ, мы свяжемся с вами через бот.\n\n"
        "<i>Время ответа: обычно 1-2 рабочих дня</i>",
        parse_mode="HTML"
    )


def register_help_handlers(dp):
    """Регистрация обработчиков помощи"""
    dp.include_router(router)