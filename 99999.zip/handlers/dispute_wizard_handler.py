"""
Мастер споров: пошаговый сценарий формирования требований и шаблонов
"""

from aiogram import Router, F
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
import logging
from database.connection import get_db

router = Router()
logger = logging.getLogger(__name__)


class DisputeStates(StatesGroup):
    choose_analysis = State()
    choose_issue = State()


ISSUES = [
    ("overcharge", "Переплата/завышенные начисления"),
    ("wrong_tariff", "Неприменение/ошибка тарифа"),
    ("meter_issue", "Ошибки показаний счетчиков"),
    ("service_not_provided", "Услуга не оказывается/не в полном объеме"),
]


def _issues_keyboard() -> InlineKeyboardMarkup:
    # Build keyboard rows from ISSUES list
    kb = []
    for key, title in ISSUES:
        kb.append([InlineKeyboardButton(text=title, callback_data=f"dw_issue:{key}")])
    kb.append([InlineKeyboardButton(text="← Назад", callback_data="back_to_start")])
    return InlineKeyboardMarkup(inline_keyboard=kb)


@router.callback_query(F.data == "dispute_wizard")
async def start_dispute_wizard(callback_query: CallbackQuery, state: FSMContext):
    user = callback_query.from_user
    if not user:
        await callback_query.answer()
        return
    # История анализов
    try:
        from services.analysis_service import analysis_service
        history = await analysis_service.get_analysis_history(user.id, limit=10)
    except Exception as e:
        logger.error(f"Dispute wizard history error: {e}")
        history = []

    if not history:
        kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="📄 Загрузить квитанцию", callback_data="upload_receipt")], [InlineKeyboardButton(text="← Назад", callback_data="back_to_start")]])
        await callback_query.message.edit_text("🧭 <b>Мастер споров</b>\n\nНет анализов. Сначала загрузите квитанцию и выполните анализ.", reply_markup=kb, parse_mode="HTML")
        await callback_query.answer()
        return

    # Список кнопок с анализами (с датой/временем и статусом на русском)
    rows = []
    status_map = {
        'processing': "В обработке",
        'completed': "Завершен",
        'error': "Ошибка",
    }
    for a in history[:10]:
        aid = a.get('id') or a.get('analysis_id')
        started = (a.get('started_at') or a.get('analysis_started_at') or '')
        completed = (a.get('completed_at') or a.get('analysis_completed_at') or '')
        when = (started or completed or '')[:16]
        st_rus = status_map.get(a.get('status'), '')
        suffix = f" · {st_rus}" if st_rus else ""
        rows.append([InlineKeyboardButton(text=f"#{aid} · {when}{suffix}", callback_data=f"dw_pick:{aid}")])
    rows.append([InlineKeyboardButton(text="← Назад", callback_data="back_to_start")])
    kb = InlineKeyboardMarkup(inline_keyboard=rows)
    await state.set_state(DisputeStates.choose_analysis)
    await callback_query.message.edit_text("🧭 <b>Мастер споров</b>\n\nВыберите анализ:", reply_markup=kb, parse_mode="HTML")
    await callback_query.answer()


@router.callback_query(F.data.startswith("dw_pick:"))
async def pick_analysis(callback_query: CallbackQuery, state: FSMContext):
    cur_state = await state.get_state()
    logger.info(f"DW: dw_pick received in state={cur_state}")
    try:
        analysis_id = int(callback_query.data.split(":", 1)[1])
    except Exception:
        await callback_query.answer("Некорректный анализ", show_alert=True)
        return
    await state.update_data(analysis_id=analysis_id)
    await state.set_state(DisputeStates.choose_issue)
    try:
        await callback_query.message.edit_text("Выберите проблему:", reply_markup=_issues_keyboard())
    except Exception as e:
        logger.info(f"DW: edit_text failed, sending new message. err={e}")
        await callback_query.message.answer("Выберите проблему:", reply_markup=_issues_keyboard())
    await callback_query.answer()


@router.callback_query(F.data.startswith("dw_issue:"))
async def pick_issue(callback_query: CallbackQuery, state: FSMContext):
    cur_state = await state.get_state()
    logger.info(f"DW: dw_issue received in state={cur_state}")
    key = callback_query.data.split(":", 1)[1]
    data = await state.get_data()
    analysis_id = data.get('analysis_id')

    # Предложить релевантные шаблоны
    buttons = [
        [InlineKeyboardButton(text="📋 Жалоба в УК", callback_data=f"complaint_template_{analysis_id}")],
        [InlineKeyboardButton(text="📝 Заявление на перерасчет", callback_data=f"recalculation_template_{analysis_id}")],
        [InlineKeyboardButton(text="🏛️ Обращение в жилинспекцию", callback_data=f"housing_inspection_template_{analysis_id}")],
        [InlineKeyboardButton(text="📄 Претензия", callback_data=f"claim_template_{analysis_id}")],
        [InlineKeyboardButton(text="← В начало мастера", callback_data="dispute_wizard")],
        [InlineKeyboardButton(text="← Главное меню", callback_data="back_to_start")],
    ]
    text = (
        "🧭 <b>Мастер споров</b>\n\n"
        "Подобраны документы на основе выбранного анализа.\n"
        "Выберите, что нужно сформировать:"
    )
    try:
        await callback_query.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons), parse_mode="HTML")
    except Exception as e:
        logger.info(f"DW: edit_text (issue) failed, sending new message. err={e}")
        await callback_query.message.answer(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons), parse_mode="HTML")
    await callback_query.answer()


@router.message(F.text.startswith('/dispute'))
async def cmd_dispute(message: Message, state: FSMContext):
    # Узкий алиас на запуск мастера
    fake_cb = type('obj', (), {'from_user': message.from_user, 'message': message})
    await start_dispute_wizard(fake_cb, state)


# ====== Генерация документов из мастера споров ======
async def _get_user_profile(telegram_id: int) -> dict:
    """Получить профиль пользователя из БД для заполнения шаблонов."""
    db = await get_db()
    async with db as conn:
        cur = await conn.execute(
            """
            SELECT full_name, address, phone_number
            FROM users
            WHERE telegram_id = ?
            """,
            (telegram_id,)
        )
        row = await cur.fetchone()
        return {
            'telegram_id': telegram_id,
            'full_name': row[0] if row else None,
            'address': row[1] if row else None,
            'phone_number': row[2] if row else None,
        }


async def _handle_generate_document(callback_query: CallbackQuery, template_type: str, analysis_id: int):
    user = callback_query.from_user
    if not user:
        await callback_query.answer()
        return
    try:
        from services.analysis_service import analysis_service
        from services.document_service import document_service

        # Получаем данные анализа и пользователя
        analysis_data = await analysis_service.get_analysis_details(analysis_id, user.id)
        if not analysis_data:
            await callback_query.answer("Не удалось получить данные анализа", show_alert=True)
            return
        user_data = await _get_user_profile(user.id)

        # Генерируем и сохраняем документ
        content = await document_service.generate_document(template_type, user_data, analysis_data)
        file_path = await document_service.save_generated_document(user.id, analysis_id, template_type, content)

        text = (
            f"✅ Документ создан и сохранен.\n\n"
            f"Тип: <b>{template_type}</b>\n"
            f"Путь: <code>{file_path}</code>\n\n"
            f"Откройте раздел ‘Мои документы’, чтобы посмотреть список."
        )
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📄 Мои документы", callback_data="my_documents")],
            [InlineKeyboardButton(text="← В мастер", callback_data="dispute_wizard")],
            [InlineKeyboardButton(text="← Главное меню", callback_data="back_to_start")],
        ])
        try:
            await callback_query.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
        except Exception:
            await callback_query.message.answer(text, reply_markup=kb, parse_mode="HTML")
        await callback_query.answer()
    except Exception as e:
        logger.error(f"DW: document generation error: {e}")
        await callback_query.answer("Ошибка при генерации документа", show_alert=True)


@router.callback_query(F.data.startswith("complaint_template_"))
async def gen_complaint(callback_query: CallbackQuery):
    try:
        analysis_id = int(callback_query.data.rsplit("_", 1)[1])
    except Exception:
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    await _handle_generate_document(callback_query, "complaint", analysis_id)


@router.callback_query(F.data.startswith("recalculation_template_"))
async def gen_recalculation(callback_query: CallbackQuery):
    try:
        analysis_id = int(callback_query.data.rsplit("_", 1)[1])
    except Exception:
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    await _handle_generate_document(callback_query, "recalculation", analysis_id)


@router.callback_query(F.data.startswith("housing_inspection_template_"))
async def gen_housing_inspection(callback_query: CallbackQuery):
    try:
        analysis_id = int(callback_query.data.rsplit("_", 1)[1])
    except Exception:
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    await _handle_generate_document(callback_query, "housing_inspection", analysis_id)


@router.callback_query(F.data.startswith("claim_template_"))
async def gen_claim(callback_query: CallbackQuery):
    try:
        analysis_id = int(callback_query.data.rsplit("_", 1)[1])
    except Exception:
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    await _handle_generate_document(callback_query, "claim", analysis_id)






