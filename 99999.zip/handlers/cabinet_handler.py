"""
Личный кабинет: история анализов и документов, статусы и быстрые действия
"""

from aiogram import Router, F
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
import logging

from database.connection import get_user_subscription_info

router = Router()
logger = logging.getLogger(__name__)


async def _build_cabinet_text(user_id: int) -> tuple[str, InlineKeyboardMarkup]:
    # Информация о подписке/лимитах
    sub = await get_user_subscription_info(user_id)
    analyses_count = sub.get('analyses_count') or 0
    subscription_type = sub.get('subscription_type') or 'free'
    subscription_expires_at = sub.get('subscription_expires_at')

    # История анализов (кратко)
    try:
        from services.analysis_service import analysis_service
        history = await analysis_service.get_analysis_history(user_id, limit=5)
    except Exception as e:
        logger.warning(f"Cabinet: history error for {user_id}: {e}")
        history = []

    # Документы (кратко)
    try:
        from services.document_service import document_service
        documents = await document_service.get_user_documents(user_id)
    except Exception as e:
        logger.warning(f"Cabinet: documents error for {user_id}: {e}")
        documents = []

    # Считаем только завершенные анализы
    completed_analyses = [a for a in (history or []) if a.get('status') == 'completed']
    docs_count = len(documents)
    recent_analyses = completed_analyses

    lines: list[str] = []
    lines.append("👤 <b>Личный кабинет</b>\n")
    lines.append("<b>Подписка:</b> {}".format('Бесплатная' if subscription_type == 'free' else subscription_type))
    if subscription_expires_at:
        lines.append(f"<b>Доступ до:</b> {subscription_expires_at}")
    # Отображаем фактическое число завершенных
    lines.append(f"<b>Анализов выполнено:</b> {len(completed_analyses)}")
    lines.append(f"<b>Документов создано:</b> {docs_count}\n")

    # Последние анализы
    lines.append("<b>Последние анализы:</b>")
    if recent_analyses:
        status_map = {
            'processing': ("В обработке", "анализ выполняется"),
            'completed': ("Завершен", "анализ успешно завершен"),
            'error': ("Ошибка", "анализ завершился с ошибкой")
        }
        for a in recent_analyses[:5]:
            aid = a.get('id') or a.get('analysis_id')
            # Покажем дату/время старта если есть, иначе завершения
            started = (a.get('started_at') or a.get('analysis_started_at') or '')
            completed = (a.get('completed_at') or a.get('analysis_completed_at') or '')
            when = (started or completed or '')[:16]
            raw_status = a.get('status', 'completed')
            st_text, st_hint = status_map.get(raw_status, (raw_status, ''))
            hint = f" ({st_hint})" if st_hint else ""
            lines.append(f"• #{aid} · {when} · {st_text}{hint}")
    else:
        lines.append("— пока нет завершенных анализов")

    # Последние документы
    lines.append("\n<b>Последние документы:</b>")
    if documents:
        type_names = {
            'complaint': 'Жалоба',
            'recalculation': 'Заявление на перерасчет',
            'housing_inspection': 'Обращение в жилинспекцию',
            'claim': 'Претензия',
        }
        for d in documents[:5]:
            dtype = d.get('document_type', 'document')
            created = (d.get('created_at') or '')[:19]
            name = type_names.get(dtype, dtype)
            lines.append(f"• {name} · {created}")
    else:
        lines.append("— пока нет")

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📄 Загрузить квитанцию", callback_data="upload_receipt")],
        [InlineKeyboardButton(text="📊 Мои анализы", callback_data="my_analyses"),
         InlineKeyboardButton(text="📝 Мои документы", callback_data="my_documents")],
        [InlineKeyboardButton(text="💳 Подписка", callback_data="subscription_info")],
        [InlineKeyboardButton(text="← Назад", callback_data="back_to_start")],
    ])

    return "\n".join(lines), keyboard


@router.callback_query(F.data == "cabinet")
async def callback_cabinet(callback_query: CallbackQuery):
    user = callback_query.from_user
    if not user:
        await callback_query.answer()
        return

    text, kb = await _build_cabinet_text(user.id)
    try:
        await callback_query.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    except Exception:
        await callback_query.message.answer(text, reply_markup=kb, parse_mode="HTML")
    await callback_query.answer()


@router.message(F.text.startswith('/cabinet'))
async def cmd_cabinet(message: Message):
    user = message.from_user
    if not user:
        return
    text, kb = await _build_cabinet_text(user.id)
    await message.answer(text, reply_markup=kb, parse_mode="HTML")


# Мои документы
@router.callback_query(F.data == "my_documents")
async def callback_my_documents(callback_query: CallbackQuery):
    user = callback_query.from_user
    if not user:
        await callback_query.answer()
        return
    try:
        from services.document_service import document_service
        documents = await document_service.get_user_documents(user.id)
    except Exception as e:
        logger.warning(f"Cabinet: documents error for {user.id}: {e}")
        documents = []

    lines: list[str] = []
    lines.append("📄 <b>Мои документы</b>\n")
    if documents:
        for d in documents[:10]:
            dtype = d.get('document_type', 'document')
            created = (d.get('created_at') or '')[:19]
            path = d.get('file_path') or ''
            lines.append(f"• {dtype} · {created}\n  {path}")
    else:
        lines.append("— пока нет сгенерированных документов")

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="← В кабинет", callback_data="cabinet")],
        [InlineKeyboardButton(text="← Главное меню", callback_data="back_to_start")],
    ])
    try:
        await callback_query.message.edit_text("\n".join(lines), reply_markup=kb, parse_mode="HTML")
    except Exception:
        await callback_query.message.answer("\n".join(lines), reply_markup=kb, parse_mode="HTML")
    await callback_query.answer()


# Мои анализы (короткий список)
@router.callback_query(F.data == "my_analyses")
async def callback_my_analyses(callback_query: CallbackQuery):
    user = callback_query.from_user
    if not user:
        await callback_query.answer()
        return
    try:
        from services.analysis_service import analysis_service
        history = await analysis_service.get_analysis_history(user.id, limit=10)
    except Exception as e:
        logger.warning(f"Cabinet: history error for {user.id}: {e}")
        history = []

    lines: list[str] = []
    lines.append("📊 <b>Мои анализы</b>\n")
    if history:
        status_map = {
            'processing': "В обработке",
            'completed': "Завершен",
            'error': "Ошибка",
        }
        for a in history[:10]:
            aid = a.get('id') or a.get('analysis_id')
            started = (a.get('started_at') or a.get('analysis_started_at') or '')
            completed = (a.get('completed_at') or a.get('analysis_completed_at') or '')
            when = (started or completed or '')[:16]
            st_rus = status_map.get(a.get('status'), '')
            lines.append(f"• #{aid} · {when} · {st_rus}")
    else:
        lines.append("— пока нет выполненных анализов")

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="← В кабинет", callback_data="cabinet")],
        [InlineKeyboardButton(text="← Главное меню", callback_data="back_to_start")],
    ])
    try:
        await callback_query.message.edit_text("\n".join(lines), reply_markup=kb, parse_mode="HTML")
    except Exception:
        await callback_query.message.answer("\n".join(lines), reply_markup=kb, parse_mode="HTML")
    await callback_query.answer()






