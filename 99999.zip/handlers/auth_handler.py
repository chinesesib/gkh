"""
Обработчики аутентификации и управления подпиской
"""

from aiogram import Router, F
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove
)
from aiogram.filters import Command
import logging
from datetime import datetime

from database.connection import (
    authenticate_user_by_phone, get_user_subscription_info, 
    can_user_analyze, increment_user_analyses
)
from services.payment_service import payment_service
from services.notification_service import NotificationService
from config import settings

logger = logging.getLogger(__name__)

router = Router()


@router.message(Command("auth"))
async def cmd_auth(message: Message):
    """Команда для аутентификации по номеру телефона"""
    
    user = message.from_user
    if not user:
        return
    
    # Проверяем, аутентифицирован ли уже пользователь
    subscription_info = await get_user_subscription_info(user.id)
    
    # Создаем клавиатуру для запроса номера телефона
    phone_keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📞 Поделиться номером телефона", request_contact=True)]
        ],
        resize_keyboard=True,
        one_time_keyboard=True
    )
    
    auth_text = """
🔐 <b>Аутентификация в ЖКХ Контроль</b>

Для предотвращения злоупотреблений и обеспечения честного использования бота, необходимо подтвердить ваш номер телефона.

<b>Преимущества аутентификации:</b>
• Защита от дублирования аккаунтов
• Безопасность вашего аккаунта
• Доступ ко всем функциям бота

Нажмите кнопку ниже, чтобы поделиться номером телефона.

🔒 <i>Ваш номер используется только для аутентификации и не передается третьим лицам.</i>
"""
    
    await message.answer(
        auth_text,
        reply_markup=phone_keyboard,
        parse_mode="HTML"
    )


@router.message(F.contact)
async def handle_contact(message: Message):
    """Обработка получения контакта пользователя"""
    
    user = message.from_user
    contact = message.contact
    
    if not user or not contact:
        await message.answer("❌ Ошибка получения контакта")
        return
    
    # Проверяем, что пользователь отправил свой контакт
    if contact.user_id != user.id:
        await message.answer(
            "❌ Необходимо отправить свой собственный номер телефона",
            reply_markup=ReplyKeyboardRemove()
        )
        return
    
    phone_number = contact.phone_number
    
    try:
        # TODO: В реальном боте можно попытаться получить MAC-адрес через веб-приложение
        # Для демонстрации используем None
        device_mac = None
        
        # Аутентифицируем пользователя
        auth_success = await authenticate_user_by_phone(user.id, phone_number, device_mac)
        
        if auth_success:
            # Получаем информацию о подписке
            subscription_info = await get_user_subscription_info(user.id)
            analyses_count = subscription_info['analyses_count']
            
            success_text = f"""
✅ <b>Аутентификация успешна!</b>

Ваш номер телефона подтвержден: {phone_number}

📊 <b>Статус аккаунта:</b>
• Выполнено анализов: {analyses_count}
• Бесплатных анализов осталось: {max(0, settings.free_analyses_limit - analyses_count)}

Теперь вы можете пользоваться всеми функциями бота!
"""
            
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="📄 Загрузить квитанцию",
                        callback_data="upload_receipt"
                    )
                ],
                [
                    InlineKeyboardButton(
                        text="💳 Информация о подписке",
                        callback_data="subscription_info"
                    )
                ]
            ])
            
            await message.answer(
                success_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
            
        else:
            error_text = """
❌ <b>Ошибка аутентификации</b>

Этот номер телефона уже зарегистрирован в системе другим пользователем.

Каждый номер телефона может быть привязан только к одному аккаунту.

Если это ваш номер, обратитесь к администратору для решения проблемы.
"""
            
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="❓ Связаться с поддержкой",
                        callback_data="contact_support"
                    )
                ]
            ])
            
            await message.answer(
                error_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
    
    except Exception as e:
        logger.error(f"❌ Ошибка аутентификации пользователя {user.id}: {e}")
        await message.answer(
            "❌ Произошла ошибка при аутентификации. Попробуйте позже.",
            reply_markup=ReplyKeyboardRemove()
        )
    
    # Убираем клавиатуру
    await message.answer(".", reply_markup=ReplyKeyboardRemove(), parse_mode=None)
    await message.delete()


@router.callback_query(F.data == "subscription_info")
async def callback_subscription_info(callback_query: CallbackQuery):
    """Показать информацию о подписке"""
    
    user = callback_query.from_user
    if not user:
        await callback_query.answer()
        return
    
    try:
        subscription_info = await get_user_subscription_info(user.id)
        analyses_count = subscription_info['analyses_count']
        subscription_type = subscription_info['subscription_type']
        expires_at = subscription_info['subscription_expires_at']
        
        free_left = max(0, settings.free_analyses_limit - analyses_count)
        
        if subscription_type == 'free' or not expires_at:
            # Бесплатный аккаунт
            if free_left > 0:
                status_text = f"""
📊 <b>Информация о подписке</b>

🆓 <b>Тарифный план:</b> Бесплатный
📋 <b>Выполнено анализов:</b> {analyses_count}
🎁 <b>Бесплатных анализов осталось:</b> {free_left}

После использования бесплатных анализов потребуется подписка:
💰 <b>Стоимость:</b> {int(settings.subscription_price)} руб/месяц

<b>Преимущества подписки:</b>
• Безлимитный анализ квитанций
• Генерация жалоб и заявлений
• Приоритетная поддержка
"""
            else:
                status_text = f"""
📊 <b>Информация о подписке</b>

🆓 <b>Тарифный план:</b> Бесплатный (исчерпан)
📋 <b>Выполнено анализов:</b> {analyses_count}
⚠️ <b>Бесплатные анализы закончились</b>

Для продолжения использования требуется подписка:
💰 <b>Стоимость:</b> {int(settings.subscription_price)} руб/месяц

<b>Преимущества подписки:</b>
• Безлимитный анализ квитанций
• Автоматическая генерация документов
• Техническая поддержка
"""
        else:
            # Платная подписка
            expires_date = datetime.fromisoformat(expires_at.replace('Z', '+00:00'))
            days_left = (expires_date - datetime.now()).days
            
            status_text = f"""
📊 <b>Информация о подписке</b>

💎 <b>Тарифный план:</b> Премиум
📋 <b>Выполнено анализов:</b> {analyses_count}
📅 <b>Действует до:</b> {expires_date.strftime("%d.%m.%Y")}
⏰ <b>Дней осталось:</b> {days_left}

<b>Активные возможности:</b>
• ✅ Безлимитный анализ квитанций
• ✅ Генерация документов
• ✅ Техническая поддержка
"""
        
        keyboard_buttons = []
        
        if subscription_type == 'free' or not expires_at:
            keyboard_buttons.append([
                InlineKeyboardButton(
                    text="💳 Купить подписку",
                    callback_data="create_payment"
                )
            ])
        else:
            keyboard_buttons.append([
                InlineKeyboardButton(
                    text="💳 Продлить подписку",
                    callback_data="extend_subscription"
                )
            ])
        
        keyboard_buttons.append([
            InlineKeyboardButton(
                text="← Назад",
                callback_data="back_to_start"
            )
        ])
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
        
        await callback_query.message.edit_text(
            status_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )
        
    except Exception as e:
        logger.error(f"❌ Ошибка получения информации о подписке для {user.id}: {e}")
        await callback_query.answer("❌ Ошибка получения информации о подписке")
    
    await callback_query.answer()


@router.callback_query(F.data.in_(["create_payment", "extend_subscription"]))
async def callback_create_payment(callback_query: CallbackQuery):
    """Создать платеж за подписку"""
    
    user = callback_query.from_user
    if not user:
        await callback_query.answer()
        return
    
    try:
        # Создаем платеж
        payment_data = await payment_service.create_subscription_payment(
            user_id=user.id,
            subscription_type="monthly"
        )
        
        payment_text = f"""
💳 <b>Оплата подписки</b>

<b>Детали платежа:</b>
• Сумма: {payment_data['amount']} руб
• Период: 1 месяц
• ID платежа: {payment_data['payment_id'][:8]}...

Нажмите кнопку ниже для перехода к оплате.

После успешной оплаты вы будете автоматически перенаправлены обратно в бот.

⚠️ <i>У вас есть 15 минут для завершения платежа</i>
"""
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💳 Оплатить",
                    url=payment_data['confirmation_url']
                )
            ],
            [
                InlineKeyboardButton(
                    text="🔄 Проверить статус",
                    callback_data=f"check_payment:{payment_data['payment_id']}"
                )
            ],
            [
                InlineKeyboardButton(
                    text="❌ Отменить",
                    callback_data="subscription_info"
                )
            ]
        ])
        
        await callback_query.message.edit_text(
            payment_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )
        
    except Exception as e:
        logger.error(f"❌ Ошибка создания платежа для {user.id}: {e}")
        await callback_query.message.edit_text(
            "❌ Ошибка создания платежа. Попробуйте позже.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="← Назад", callback_data="subscription_info")]
            ])
        )
    
    await callback_query.answer()


@router.callback_query(F.data.startswith("check_payment:"))
async def callback_check_payment(callback_query: CallbackQuery):
    """Проверить статус платежа"""
    
    payment_id = callback_query.data.split(":", 1)[1]
    user = callback_query.from_user
    
    if not user:
        await callback_query.answer()
        return
    
    try:
        # Проверяем статус платежа
        payment_status = await payment_service.check_payment_status(payment_id)
        
        if payment_status['status'] == 'succeeded':
            # Платеж успешен
            await callback_query.message.edit_text(
                """
✅ <b>Платеж успешно завершен!</b>

Ваша подписка активирована. Теперь вы можете пользоваться всеми возможностями бота без ограничений!

Спасибо за покупку! 🎉
""",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="📄 Загрузить квитанцию", callback_data="upload_receipt")],
                    [InlineKeyboardButton(text="📊 Мои анализы", callback_data="my_analyses")]
                ]),
                parse_mode="HTML"
            )
            
        elif payment_status['status'] in ['pending', 'waiting_for_capture']:
            await callback_query.answer("⏳ Платеж в обработке. Попробуйте через минуту.")
            
        elif payment_status['status'] in ['canceled', 'failed']:
            error_msg = payment_status.get('error', 'Платеж не прошел')
            await callback_query.message.edit_text(
                f"""
❌ <b>Платеж не прошел</b>

Причина: {error_msg}

Вы можете попробовать оплатить еще раз или обратиться в службу поддержки.
""",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="💳 Попробовать снова", callback_data="create_payment")],
                    [InlineKeyboardButton(text="← Назад", callback_data="subscription_info")]
                ]),
                parse_mode="HTML"
            )
        else:
            await callback_query.answer("ℹ️ Статус платежа неизвестен. Попробуйте позже.")
    
    except Exception as e:
        logger.error(f"❌ Ошибка проверки платежа {payment_id}: {e}")
        await callback_query.answer("❌ Ошибка проверки платежа")
    
    await callback_query.answer()


@router.callback_query(F.data == "contact_support")
async def callback_contact_support(callback_query: CallbackQuery):
    """Связаться с поддержкой"""
    
    support_text = """
🆘 <b>Техническая поддержка</b>

Если у вас возникли проблемы с работой бота, вы можете:

1️⃣ Отправить сообщение через команду /feedback
2️⃣ Написать администратору напрямую

<b>Часто решаемые проблемы:</b>
• Проблемы с аутентификацией
• Вопросы по платежам
• Технические ошибки
• Вопросы по анализу квитанций

Мы отвечаем в течение 24 часов.
"""
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="✍️ Написать в поддержку",
                callback_data="write_feedback"
            )
        ],
        [
            InlineKeyboardButton(
                text="← Назад",
                callback_data="back_to_start"
            )
        ]
    ])
    
    await callback_query.message.edit_text(
        support_text,
        reply_markup=keyboard,
        parse_mode="HTML"
    )
    
    await callback_query.answer()


# Функция для проверки возможности анализа
async def check_analysis_permission(user_id: int) -> tuple[bool, str, InlineKeyboardMarkup]:
    """Проверить, может ли пользователь выполнить анализ"""
    
    can_analyze, reason = await can_user_analyze(user_id)
    
    if can_analyze:
        return True, "", None
    
    if reason == 'subscription_required':
        message = f"""
⚠️ <b>Превышен лимит бесплатных анализов</b>

Вы использовали все {settings.free_analyses_limit} бесплатных анализа.

Для продолжения работы с ботом необходимо оформить подписку:

💰 <b>Стоимость:</b> {int(settings.subscription_price)} руб/месяц
🎯 <b>Преимущества:</b>
• Безлимитный анализ квитанций
• Генерация жалоб и заявлений
• Приоритетная поддержка
"""
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💳 Оформить подписку",
                    callback_data="create_payment"
                )
            ],
            [
                InlineKeyboardButton(
                    text="ℹ️ Подробнее",
                    callback_data="subscription_info"
                )
            ]
        ])
        
        return False, message, keyboard
    
    return False, "❌ Ошибка проверки доступа", None


@router.message(F.text.regexp(r'^(\+?7|8)?[\s\-]?\(?[489][0-9]{2}\)?[\s\-]?[0-9]{3}[\s\-]?[0-9]{2}[\s\-]?[0-9]{2}$'))
async def handle_phone_text(message: Message):
    """Обработка текстового ввода номера телефона"""
    
    user = message.from_user
    if not user:
        return
    
    phone_text = message.text.strip()
    
    # Нормализуем номер телефона
    import re
    
    # Убираем все символы кроме цифр
    phone_digits = re.sub(r'\D', '', phone_text)
    
    # Приводим к формату +7XXXXXXXXXX
    if phone_digits.startswith('8'):
        phone_digits = '7' + phone_digits[1:]
    elif phone_digits.startswith('7'):
        phone_digits = '7' + phone_digits[1:]
    elif not phone_digits.startswith('7'):
        phone_digits = '7' + phone_digits
    
    if len(phone_digits) != 11:
        await message.answer(
            "❌ Неверный формат номера телефона.\n\n"
            "Пожалуйста, введите номер в одном из форматов:\n"
            "• 89021430233\n"
            "• +7 902 143 02 33\n"
            "• 8 (902) 143-02-33\n\n"
            "Или используйте кнопку 'Поделиться номером телефона' для автоматического ввода."
        )
        return
    
    phone_number = '+' + phone_digits
    
    try:
        # TODO: В реальном боте можно попытаться получить MAC-адрес через веб-приложение
        # Для демонстрации используем None
        device_mac = None
        
        # Аутентифицируем пользователя
        auth_success = await authenticate_user_by_phone(user.id, phone_number, device_mac)
        
        if auth_success:
            # Получаем информацию о подписке
            subscription_info = await get_user_subscription_info(user.id)
            analyses_count = subscription_info['analyses_count']
            
            success_text = f"""
✅ <b>Аутентификация успешна!</b>

Ваш номер телефона подтвержден: {phone_number}

📊 <b>Статус аккаунта:</b>
• Выполнено анализов: {analyses_count}
• Бесплатных анализов осталось: {max(0, settings.free_analyses_limit - analyses_count)}

Теперь вы можете пользоваться всеми функциями бота!
"""
            
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="📄 Загрузить квитанцию",
                        callback_data="upload_receipt"
                    )
                ],
                [
                    InlineKeyboardButton(
                        text="💳 Информация о подписке",
                        callback_data="subscription_info"
                    )
                ]
            ])
            
            await message.answer(
                success_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
            
        else:
            error_text = """
❌ <b>Ошибка аутентификации</b>

Этот номер телефона уже зарегистрирован в системе другим пользователем.

Каждый номер телефона может быть привязан только к одному аккаунту.

Если это ваш номер, обратитесь к администратору для решения проблемы.
"""
            
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="❓ Связаться с поддержкой",
                        callback_data="contact_support"
                    )
                ]
            ])
            
            await message.answer(
                error_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
    
    except Exception as e:
        logger.error(f"❌ Ошибка аутентификации пользователя {user.id}: {e}")
        await message.answer(
            "❌ Произошла ошибка при аутентификации. Попробуйте позже."
        )