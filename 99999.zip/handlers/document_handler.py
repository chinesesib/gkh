"""
Обработчики документов (PDF квитанции ЖКХ)
"""

import asyncio
import os
from datetime import datetime
from aiogram import Router, F
from aiogram.types import Message, Document, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import logging
import re

def parse_currency_value(value):
    """Парсинг валютных значений из строки в float"""
    if isinstance(value, (int, float)):
        return float(value)
    
    if not isinstance(value, str):
        return 0.0
    
    # Убираем все символы кроме цифр, точек, запятых и минуса
    cleaned = re.sub(r'[^\d.,\-]', '', str(value))
    
    # Заменяем запятую на точку для десятичного разделителя
    cleaned = cleaned.replace(',', '.')
    
    # Убираем пробелы
    cleaned = cleaned.replace(' ', '')
    
    try:
        return float(cleaned)
    except (ValueError, TypeError):
        return 0.0

from services.pdf_service import PDFService
from services.yandex_cloud_service import YandexCloudService
from services.claude_service import ClaudeService
from services.analysis_service import AnalysisService
from services.report_service import ReportService
from services.document_service import document_service

logger = logging.getLogger(__name__)

router = Router()


class DocumentProcessingStates(StatesGroup):
    """Состояния обработки документов"""
    waiting_for_document = State()
    processing_document = State()
    analysis_complete = State()


@router.message(F.document)
async def handle_document(message: Message, state: FSMContext):
    """Обработка загруженного документа"""
    
    # Check if user and document exist
    if not message.from_user or not message.document:
        await message.reply("❌ Ошибка получения информации о документе или пользователе.")
        return
        
    document: Document = message.document
    user_id = message.from_user.id
    
    logger.info(f"📄 Получен документ от пользователя {user_id}: {document.file_name}")
    
    # Проверяем тип файла
    if not document.file_name or not document.file_name.lower().endswith('.pdf'):
        await message.reply(
            "❌ <b>Неподдерживаемый формат файла!</b>\n\n"
            "Пожалуйста, отправьте PDF файл с квитанцией ЖКХ.\n"
            "Другие форматы не поддерживаются.",
            parse_mode="HTML"
        )
        return
    
    # Проверяем размер файла (уже проверено в middleware, но на всякий случай)
    if document.file_size and document.file_size > 50 * 1024 * 1024:  # 50 МБ
        await message.reply(
            "❌ <b>Файл слишком большой!</b>\n\n"
            f"Размер файла: {document.file_size / (1024*1024):.1f} МБ\n"
            "Максимальный размер: 50 МБ",
            parse_mode="HTML"
        )
        return
    
    # Отправляем сообщение о начале обработки
    processing_message = await message.reply(
        "⏳ <b>Ожидайте...</b> (идет обработка)\n\n"
        "🔄 <b>Обработка документа...</b>\n\n"
        "📥 Загружаю файл...\n"
        "⏱️ Это может занять 1-2 минуты",
        parse_mode="HTML"
    )
    
    try:
        # Устанавливаем состояние обработки
        await state.set_state(DocumentProcessingStates.processing_document)
        
        # Сохраняем информацию о документе в состоянии
        await state.update_data(
            document_file_id=document.file_id,
            document_name=document.file_name,
            processing_message_id=processing_message.message_id
        )
        
        # Запускаем обработку документа
        await process_document(message, document, processing_message)
        
    except Exception as e:
        logger.error(f"❌ Ошибка при обработке документа: {e}")
        
        try:
            await processing_message.edit_text(
                "❌ <b>Ошибка при обработке документа</b>\n\n"
                "Произошла ошибка при анализе вашего файла. "
                "Пожалуйста, попробуйте еще раз или обратитесь к администратору.\n\n"
                f"<code>Ошибка: {str(e)[:100]}...</code>",
                parse_mode="HTML"
            )
        except Exception as edit_error:
            logger.warning(f"Could not edit processing message: {edit_error}")
            # Если не можем отредактировать сообщение, отправляем новое
            await message.reply(
                "❌ <b>Ошибка при обработке документа</b>\n\n"
                "Произошла ошибка при анализе вашего файла. "
                "Пожалуйста, попробуйте еще раз.",
                parse_mode="HTML"
            )
        
        await state.clear()


async def process_document(message: Message, document: Document, processing_message: Message):
    """Основная логика обработки документа"""
    
    if not message.from_user:
        raise ValueError("Нет информации о пользователе")
        
    user_id = message.from_user.id
    bot = message.bot
    file_path = None  # Initialize file_path variable
    
    try:
        # Шаг 1: Загрузка файла
        await processing_message.edit_text(
            "⏳ <b>Ожидайте...</b> (идет обработка)\n\n"
            "🔄 <b>Обработка документа...</b>\n\n"
            "📥 Загружаю файл... ✅\n"
            "📄 Извлечение текста из PDF...",
            parse_mode="HTML"
        )
        
        # Получаем файл от Telegram
        if not bot:
            raise ValueError("Нет доступа к боту")
            
        file_info = await bot.get_file(document.file_id)
        if not file_info.file_path:
            raise ValueError("Не удалось получить путь к файлу")
            
        file_path = f"temp_{user_id}_{document.file_id}.pdf"
        
        await bot.download_file(file_info.file_path, file_path)
        
        # Шаг 2: Анализ с помощью AnalysisService (включает извлечение текста и сохранение в БД)
        await processing_message.edit_text(
            "⏳ <b>Ожидайте...</b> (идет обработка)\n\n"
            "🔄 <b>Обработка документа...</b>\n\n"
            "📥 Загружаю файл... ✅\n"
            "📄 Анализ квитанции ЖКХ...",
            parse_mode="HTML"
        )
        
        # Используем AnalysisService для полного анализа
        from services.analysis_service import analysis_service
        
        # Создаем callback для обновления прогресса
        async def progress_callback(analysis_id: str, progress_percent: int, message: str):
            try:
                await processing_message.edit_text(
                    "⏳ <b>Ожидайте...</b> (идет обработка)\n\n"
                    + f"🔄 <b>Анализ квитанции ЖКХ</b>\n\n{message}",
                    parse_mode="HTML"
                )
            except Exception as e:
                logger.warning(f"Ошибка обновления прогресса: {e}")
        
        # Устанавливаем callback для прогресса
        analysis_service.set_progress_callback(f"{user_id}_{datetime.now().timestamp()}", progress_callback)
        
        analysis_result = await analysis_service.analyze_document(
            file_path, user_id, document.file_name or "Без названия", document.file_size or 0
        )
        
        # Получаем ID анализа из метаданных
        analysis_id = analysis_result.get('meta', {}).get('analysis_id')
        
        if not analysis_id:
            raise ValueError("Не удалось получить ID анализа")
        
        # Шаг 3: Создание отчета
        await processing_message.edit_text(
            "⏳ <b>Ожидайте...</b> (идет обработка)\n\n"
            "🔄 <b>Обработка документа...</b>\n\n"
            "📥 Загружаю файл... ✅\n"
            "📄 Анализ квитанции ЖКХ... ✅\n"
            "📊 Генерация отчета...",
            parse_mode="HTML"
        )
        
        # Генерируем отчет
        report_service = ReportService()
        report_data = await report_service.generate_report(analysis_result, user_id)
        
        # Добавляем ID анализа в данные отчета для использования в callback'ах
        report_data['analysis_id'] = analysis_id
        
        # Шаг 4: Отправка результатов
        await send_analysis_results(message, analysis_result, report_data, processing_message)
        
    except Exception as e:
        logger.error(f"Ошибка в process_document: {e}")
        raise
    finally:
        # Удаляем временный файл
        try:
            if file_path and os.path.exists(file_path):
                os.remove(file_path)
        except Exception:
            pass


async def send_analysis_results(message: Message, analysis_result: dict, report_data: dict, processing_message: Message):
    """Отправка результатов анализа пользователю"""
    
    # Формируем текст основного отчета
    summary = analysis_result.get('summary', {})
    violations = analysis_result.get('violations', [])
    
    # Определяем общий статус
    if violations:
        status_emoji = "⚠️"
        status_text = "Обнаружены нарушения"
        status_color = "🔴"
    else:
        status_emoji = "✅"
        status_text = "Нарушений не обнаружено"
        status_color = "🟢"
    
    # Создаем основное сообщение
    report_text = f"""
{status_emoji} <b>Анализ квитанции ЖКХ завершен</b>

{status_color} <b>Общий статус:</b> {status_text}

<b>📊 Краткий обзор:</b>
• Проанализировано услуг: {len(summary.get('services', []))}
• Общая сумма: {summary.get('total_amount', 'Н/Д')} ₽
• Потенциальная переплата: {summary.get('overpayment', 0)} ₽

"""
    
    if violations:
        report_text += "<b>⚠️ Обнаруженные нарушения:</b>\n"
        for i, violation in enumerate(violations[:3], 1):  # Показываем первые 3
            report_text += f"{i}. {violation.get('description', 'Нарушение тарификации')}\n"
        
        if len(violations) > 3:
            report_text += f"• И еще {len(violations) - 3} нарушений...\n"
    
    report_text += "\n<i>Для получения подробного отчета используйте кнопки ниже.</i>"
    
    # Получаем ID анализа для callback'ов
    analysis_id = report_data.get('analysis_id', 'unknown')
    
    # Создаем клавиатуру с действиями (используем analysis_id вместо report_id)
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="📋 Подробный отчет",
                callback_data=f"detailed_report_{analysis_id}"
            )
        ],
        [
            InlineKeyboardButton(
                text="📊 Графики", 
                callback_data=f"charts_{analysis_id}"
            ),
            InlineKeyboardButton(
                text="💰 Расчеты",
                callback_data=f"calculations_{analysis_id}"
            )
        ],
        [
            InlineKeyboardButton(
                text="📄 Создать документы",
                callback_data=f"documentation_{analysis_id}"
            ),
            InlineKeyboardButton(
                text="🔮 Расширенный анализ",
                callback_data=f"enhanced_analysis_{analysis_id}"
            )
        ],
        [
            InlineKeyboardButton(
                text="📄 Новый анализ",
                callback_data="upload_receipt"
            )
        ]
    ])
    
    # Удаляем сообщение о процессе и отправляем результат
    try:
        await processing_message.delete()
    except Exception as e:
        logger.warning(f"Could not delete processing message: {e}")
    
    await message.reply(
        report_text,
        reply_markup=keyboard,
        parse_mode="HTML"
    )
    
    # Если есть графики, отправляем их отдельно
    if report_data.get('charts'):
        await asyncio.sleep(1)  # Небольшая задержка
        
        try:
            from aiogram.types import FSInputFile
            chart_path = report_data['charts']['summary_chart']
            
            # Проверяем существование файла
            if os.path.exists(chart_path):
                chart_file = FSInputFile(chart_path)
                chart_message = await message.reply_photo(
                    photo=chart_file,
                    caption="📊 <b>Сводная диаграмма анализа</b>\n\nСравнение фактических и нормативных тарифов по услугам ЖКХ.",
                    parse_mode="HTML"
                )
            else:
                logger.warning(f"Chart file not found: {chart_path}")
                await message.reply("⚠️ График не удалось загрузить, но анализ завершен успешно.")
        except Exception as e:
            logger.error(f"Error sending chart: {e}")
            await message.reply("⚠️ График не удалось отправить, но анализ завершен успешно.")


# Обработчики callback'ов для детального просмотра

@router.callback_query(F.data.startswith("detailed_report_"))
async def callback_detailed_report(callback_query):
    """Показать подробный отчет"""
    
    # Extract analysis ID from callback data
    try:
        analysis_id = int(callback_query.data.split("_")[-1])
        user_id = callback_query.from_user.id
    except (ValueError, IndexError):
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    
    try:
        # Get analysis details from database
        from services.analysis_service import analysis_service
        analysis_details = await analysis_service.get_analysis_details(analysis_id, user_id)
        
        if not analysis_details:
            await callback_query.answer("Анализ не найден", show_alert=True)
            return
        
        # Generate detailed report text based on actual data
        summary = analysis_details.get('summary', {})
        services = analysis_details.get('services', [])
        violations = analysis_details.get('violations', [])
        
        detailed_text = "📋 <b>Подробный отчет анализа</b>\n\n"
        
        # Add basic information
        detailed_text += "<b>🏠 Информация о квитанции:</b>\n"
        detailed_text += f"• Период: {summary.get('period', 'Не указан')}\n"
        detailed_text += f"• Общая сумма: {summary.get('total_amount', 'Не указана')} ₽\n"
        detailed_text += f"• Услуг проанализировано: {len(services)}\n\n"
        
        # Add services information
        if services:
            detailed_text += "<b>🔧 Услуги ЖКХ:</b>\n"
            for service in services[:6]:  # Limit to first 6 services
                name = service.get('name', 'Неизвестная услуга')
                amount = service.get('amount_charged', service.get('amount', 0))
                is_violation = service.get('is_violation', False)
                
                # Format amount properly
                if isinstance(amount, (int, float)):
                    amount_str = f"{amount:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
                elif isinstance(amount, str):
                    # Remove any existing currency symbols and format properly
                    amount_clean = amount.replace(' ₽', '').replace('₽', '').replace(' ', '').replace(',', '.')
                    try:
                        amount_value = float(amount_clean)
                        amount_str = f"{amount_value:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
                    except (ValueError, TypeError):
                        amount_str = amount
                else:
                    amount_str = str(amount)
                
                violation_mark = "⚠️" if is_violation else "✅"
                # Дополнительные детали: тарифы, объем, переплата
                tariff_actual = service.get('tariff_actual')
                tariff_standard = service.get('tariff_standard')
                consumption = service.get('consumption')
                unit = service.get('unit', '')
                amount_should_be = service.get('amount_should_be')
                overpayment = service.get('overpayment')
                violation_type = service.get('violation_type')

                def _fmt_num(val):
                    if isinstance(val, (int, float)):
                        return f"{val:,.2f}".replace(",", " ").replace(".", ",")
                    if isinstance(val, str):
                        cleaned = val.replace(' ₽', '').replace('₽', '').replace(' ', '').replace(',', '.')
                        try:
                            v = float(cleaned)
                            return f"{v:,.2f}".replace(",", " ").replace(".", ",")
                        except Exception:
                            return val
                    return str(val) if val is not None else "Н/Д"

                detailed_text += f"• {violation_mark} {name}: {amount_str}\n"
                # Показываем детали построчно (если есть)
                details_lines = []
                if tariff_actual is not None or tariff_standard is not None:
                    details_lines.append(f"  • Тариф: факт {_fmt_num(tariff_actual)} / норма {_fmt_num(tariff_standard)}")
                if consumption is not None:
                    unit_str = f" {unit}" if unit else ""
                    details_lines.append(f"  • Объем: {_fmt_num(consumption)}{unit_str}")
                if amount_should_be is not None:
                    details_lines.append(f"  • Должно быть начислено: {_fmt_num(amount_should_be)} ₽")
                if overpayment not in (None, 0, '0', '0.0'):
                    details_lines.append(f"  • Переплата: {_fmt_num(overpayment)} ₽")
                if violation_type:
                    details_lines.append(f"  • Тип отклонения: {violation_type}")
                if details_lines:
                    detailed_text += "\n".join(details_lines) + "\n"
            detailed_text += "\n"
        
        # Add violations information
        if violations:
            detailed_text += "<b>⚠️ Обнаруженные нарушения:</b>\n"
            for i, violation in enumerate(violations[:5], 1):  # Limit to first 5 violations
                description = violation.get('description', 'Нарушение тарификации')
                detailed_text += f"{i}. {description}\n"
            
            if len(violations) > 5:
                detailed_text += f"... и еще {len(violations) - 5} нарушений\n"
            detailed_text += "\n"
        
        # Add financial analysis
        financial = analysis_details.get('financial_analysis', {})
        if financial:
            detailed_text += "<b>💰 Финансовый анализ:</b>\n"
            monthly_overpayment = financial.get('monthly_overpayment', 0)
            yearly_overpayment = financial.get('yearly_overpayment', 0)
            
            # Format the values properly to avoid duplicate currency symbols
            if isinstance(monthly_overpayment, str):
                # Remove any existing currency symbols and format properly
                monthly_clean = monthly_overpayment.replace(' ₽', '').replace('₽', '').replace(' ', '').replace(',', '.')
                try:
                    monthly_value = float(monthly_clean)
                    monthly_str = f"{monthly_value:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
                except (ValueError, TypeError):
                    monthly_str = monthly_overpayment
            elif isinstance(monthly_overpayment, (int, float)):
                monthly_str = f"{monthly_overpayment:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
            else:
                monthly_str = str(monthly_overpayment)
                
            if isinstance(yearly_overpayment, str):
                # Remove any existing currency symbols and format properly
                yearly_clean = yearly_overpayment.replace(' ₽', '').replace('₽', '').replace(' ', '').replace(',', '.')
                try:
                    yearly_value = float(yearly_clean)
                    yearly_str = f"{yearly_value:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
                except (ValueError, TypeError):
                    yearly_str = yearly_overpayment
            elif isinstance(yearly_overpayment, (int, float)):
                yearly_str = f"{yearly_overpayment:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
            else:
                yearly_str = str(yearly_overpayment)
            
            if monthly_overpayment:
                detailed_text += f"• Ежемесячная переплата: {monthly_str}\n"
            if yearly_overpayment:
                detailed_text += f"• Годовая переплата: {yearly_str}\n"
            detailed_text += "\n"
        
        # Add recommendations
        recommendations = analysis_details.get('recommendations', [])
        if recommendations:
            detailed_text += "<b>📝 Рекомендации:</b>\n"
            for i, rec in enumerate(recommendations[:3], 1):
                detailed_text += f"{i}. {rec}\n"
        
        await callback_query.message.edit_text(
            detailed_text,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="← Назад к результатам", callback_data="back_to_results")]
            ])
        )
        
        await callback_query.answer()
        
    except Exception as e:
        logger.error(f"Error in callback_detailed_report: {e}")
        await callback_query.answer("Ошибка при загрузке отчета", show_alert=True)


@router.callback_query(F.data.startswith("charts_"))
async def callback_charts(callback_query):
    """Показать дополнительные графики"""
    
    await callback_query.answer("📊 Генерация дополнительных графиков...")
    
    # Extract analysis ID from callback data
    try:
        analysis_id = int(callback_query.data.split("_")[-1])
        user_id = callback_query.from_user.id
    except (ValueError, IndexError):
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    
    # Отправляем сообщение о начале генерации
    processing_msg = await callback_query.message.reply(
        "🔄 <b>Генерация дополнительных графиков...</b>\n\n"
        "📊 Создаем детальные диаграммы анализа...",
        parse_mode="HTML"
    )
    
    try:
        # Получаем данные анализа из базы данных
        from services.analysis_service import analysis_service
        analysis_details = await analysis_service.get_analysis_details(analysis_id, user_id)
        
        if not analysis_details:
            await processing_msg.edit_text(
                "❌ <b>Ошибка получения данных анализа</b>\n\n"
                "Анализ не найден. Попробуйте позже или обратитесь к администратору.",
                parse_mode="HTML"
            )
            return
        
        # Генерируем дополнительные графики
        from services.report_service import ReportService
        report_service = ReportService()
        
        charts_data = await report_service.generate_additional_charts(analysis_details, user_id)
        
        if not charts_data:
            await processing_msg.edit_text(
                "❌ <b>Ошибка генерации графиков</b>\n\n"
                "Попробуйте позже или обратитесь к администратору.",
                parse_mode="HTML"
            )
            return
        
        # Удаляем сообщение о процессе
        try:
            await processing_msg.delete()
        except Exception:
            pass
        
        # Отправляем графики по одному
        from aiogram.types import FSInputFile
        
        charts_info = [
            ('violation_trend', '📈 <b>Анализ нарушений</b>\n\nДетальный анализ нарушений по типам и суммам.'),
            ('service_breakdown', '🔍 <b>Распределение услуг</b>\n\nАнализ распределения стоимости и соответствия нормам.'),
            ('monthly_comparison', '📅 <b>Сравнение по месяцам</b>\n\nПрогноз платежей и переплат на год.'),
            ('savings_potential', '💰 <b>Потенциал экономии</b>\n\nРасчет потенциальной экономии при устранении нарушений.')
        ]
        
        for chart_type, caption in charts_info:
            if chart_type in charts_data:
                chart_path = charts_data[chart_type]
                
                if os.path.exists(chart_path):
                    try:
                        chart_file = FSInputFile(chart_path)
                        await callback_query.message.reply_photo(
                            photo=chart_file,
                            caption=caption,
                            parse_mode="HTML"
                        )
                        await asyncio.sleep(0.5)  # Небольшая задержка между отправками
                    except Exception as e:
                        logger.error(f"Error sending chart {chart_type}: {e}")
                        continue
        
        # Отправляем итоговое сообщение
        await callback_query.message.reply(
            "✅ <b>Дополнительные графики созданы!</b>\n\n"
            "📊 Выше представлены детальные графики анализа:\n\n"
            "• Анализ нарушений\n"
            "• Распределение услуг\n"
            "• Сравнение по месяцам\n"
            "• Потенциал экономии\n\n"
            "🔄 Для повторного анализа отправьте новую квитанцию.",
            parse_mode="HTML"
        )
        
    except Exception as e:
        logger.error(f"Error in callback_charts: {e}")
        
        try:
            await processing_msg.edit_text(
                "❌ <b>Ошибка при создании графиков</b>\n\n"
                f"Попробуйте позже. Ошибка: {str(e)[:100]}...",
                parse_mode="HTML"
            )
        except Exception:
            await callback_query.message.reply(
                "❌ Ошибка при создании графиков. Попробуйте позже."
            )


@router.callback_query(F.data.startswith("calculations_"))
async def callback_calculations(callback_query):
    """Показать расчеты"""
    
    # Extract analysis ID from callback data
    try:
        analysis_id = int(callback_query.data.split("_")[-1])
        user_id = callback_query.from_user.id
    except (ValueError, IndexError):
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    
    try:
        # Get analysis details from database
        from services.analysis_service import analysis_service
        analysis_details = await analysis_service.get_analysis_details(analysis_id, user_id)
        
        if not analysis_details:
            await callback_query.answer("Анализ не найден", show_alert=True)
            return
        
        # Generate calculations text based on actual data
        financial = analysis_details.get('financial_analysis', {})
        services = analysis_details.get('services', [])
        
        calculations_text = "💰 <b>Детальные расчеты переплат</b>\n\n"
        
        # Add service calculations
        if services:
            for service in services[:5]:  # Limit to first 5 services
                name = service.get('name', 'Неизвестная услуга')
                amount = service.get('amount_charged', service.get('amount', 0))
                is_violation = service.get('is_violation', False)
                
                # Format amount properly
                if isinstance(amount, (int, float)):
                    amount_str = f"{amount:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
                else:
                    amount_str = str(amount)
                
                if is_violation:
                    calculations_text += f"<b>{name}:</b>\n"
                    calculations_text += f"• Сумма по квитанции: {amount_str}\n"
                    # Детализируем отклонение: тарифы, расчет, переплата
                    t_act = service.get('tariff_actual')
                    t_std = service.get('tariff_standard')
                    cons = service.get('consumption')
                    unit = service.get('unit', '')
                    amt_should = service.get('amount_should_be')
                    overp = service.get('overpayment')
                    vtype = service.get('violation_type')

                    def _fmt(val):
                        if isinstance(val, (int, float)):
                            return f"{val:,.2f}".replace(",", " ").replace(".", ",")
                        return str(val)

                    calculations_text += "• Выявлено отклонение: ⚠️\n"
                    if t_act is not None or t_std is not None:
                        calculations_text += f"  • Тариф (факт/норма): {_fmt(t_act)} / {_fmt(t_std)}\n"
                    if cons is not None:
                        unit_str = f" {unit}" if unit else ""
                        calculations_text += f"  • Объем: {_fmt(cons)}{unit_str}\n"
                    if amt_should is not None:
                        calculations_text += f"  • Должно быть начислено: {_fmt(amt_should)} ₽\n"
                    if overp not in (None, 0, '0', '0.0'):
                        calculations_text += f"  • Переплата: {_fmt(overp)} ₽\n"
                    if vtype:
                        calculations_text += f"  • Тип отклонения: {vtype}\n"
                    calculations_text += "\n"
                else:
                    # Show all services, not just those with violations
                    calculations_text += f"<b>{name}:</b>\n"
                    calculations_text += f"• Сумма по квитанции: {amount_str}\n"
                    # Покажем параметры даже без отклонений
                    t_act = service.get('tariff_actual')
                    t_std = service.get('tariff_standard')
                    cons = service.get('consumption')
                    unit = service.get('unit', '')
                    if t_act is not None or t_std is not None:
                        calculations_text += f"  • Тариф (факт/норма): {t_act} / {t_std}\n"
                    if cons is not None:
                        unit_str = f" {unit}" if unit else ""
                        calculations_text += f"  • Объем: {cons}{unit_str}\n"
                    calculations_text += f"• Выявлено отклонение: ✅\n\n"
        
        # Add financial summary with proper formatting
        monthly_overpayment = financial.get('monthly_overpayment', 0)
        yearly_overpayment = financial.get('yearly_overpayment', 0)
        
        # Format the values properly to avoid duplicate currency symbols
        if isinstance(monthly_overpayment, str):
            # Remove any existing currency symbols and format properly
            monthly_clean = monthly_overpayment.replace(' ₽', '').replace('₽', '').replace(' ', '').replace(',', '.')
            try:
                monthly_value = float(monthly_clean)
                monthly_str = f"{monthly_value:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
            except (ValueError, TypeError):
                monthly_str = monthly_overpayment
        elif isinstance(monthly_overpayment, (int, float)):
            monthly_str = f"{monthly_overpayment:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
        else:
            monthly_str = str(monthly_overpayment)
            
        if isinstance(yearly_overpayment, str):
            # Remove any existing currency symbols and format properly
            yearly_clean = yearly_overpayment.replace(' ₽', '').replace('₽', '').replace(' ', '').replace(',', '.')
            try:
                yearly_value = float(yearly_clean)
                yearly_str = f"{yearly_value:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
            except (ValueError, TypeError):
                yearly_str = yearly_overpayment
        elif isinstance(yearly_overpayment, (int, float)):
            yearly_str = f"{yearly_overpayment:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
        else:
            yearly_str = str(yearly_overpayment)
        
        calculations_text += f"<b>🔢 Общая переплата за месяц: {monthly_str}</b>\n"
        calculations_text += f"<b>📅 Переплата за год: {yearly_str}</b>\n\n"
        
        calculations_text += "<i>Расчеты основаны на региональных нормативах и могут отличаться в зависимости от конкретной ситуации.</i>"
        
        await callback_query.message.edit_text(
            calculations_text,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="← Назад к результатам", callback_data="back_to_results")]
            ])
        )
        
        await callback_query.answer()
        
    except Exception as e:
        logger.error(f"Error in callback_calculations: {e}")
        await callback_query.answer("Ошибка при загрузке расчетов", show_alert=True)


@router.callback_query(F.data == "back_to_results")
async def callback_back_to_results(callback_query):
    """Возврат к результатам анализа"""
    
    await callback_query.answer()
    
    # Отправляем сообщение о том, что результаты были показаны ранее
    await callback_query.message.edit_text(
        "📋 <b>Результаты анализа</b>\n\n"
        "Результаты вашего последнего анализа были показаны выше.\n\n"
        "🔄 Для нового анализа отправьте новую квитанцию ЖКХ в формате PDF.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📄 Новый анализ",
                    callback_data="upload_receipt"
                )
            ],
            [
                InlineKeyboardButton(
                    text="📊 Мои анализы",
                    callback_data="my_analyses"
                ),
                InlineKeyboardButton(
                    text="← Главное меню",
                    callback_data="back_to_start"
                )
            ]
        ])
    )


@router.callback_query(F.data.startswith("enhanced_analysis_"))
async def callback_enhanced_analysis(callback_query):
    """Показать расширенный анализ"""
    
    await callback_query.answer("🔮 Генерация расширенного анализа...")
    
    # Extract analysis ID from callback data
    try:
        analysis_id = int(callback_query.data.split("_")[-1])
        user_id = callback_query.from_user.id
    except (ValueError, IndexError):
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    
    # Отправляем сообщение о начале генерации
    processing_msg = await callback_query.message.reply(
        "🔄 <b>Генерация расширенного анализа...</b>\n\n"
        "🔮 Создаем детальные финансовые прогнозы и рекомендации...",
        parse_mode="HTML"
    )
    
    try:
        # Получаем данные анализа из базы данных
        from services.analysis_service import analysis_service
        analysis_details = await analysis_service.get_analysis_details(analysis_id, user_id)
        
        if not analysis_details:
            await processing_msg.edit_text(
                "❌ <b>Ошибка получения данных анализа</b>\n\n"
                "Анализ не найден. Попробуйте позже или обратитесь к администратору.",
                parse_mode="HTML"
            )
            return
        
        # Информация о недвижимости для расширенного анализа (в реальном приложении можно брать из профиля пользователя)
        property_info = {
            'area': 65.5,  # Площадь в м²
            'region': 'moscow',
            'consumer_name': callback_query.from_user.full_name or callback_query.from_user.first_name,
            'property_address': 'г. Москва, ул. Примерная, д. 1, кв. 1',
            'phone': '+7 (XXX) XXX-XX-XX',
            'email': 'example@email.com'
        }
        
        # Генерируем расширенный отчет
        from services.report_service import ReportService
        report_service = ReportService()
        
        enhanced_report_data = await report_service.generate_enhanced_report(
            analysis_details, user_id, property_info)
        
        if not enhanced_report_data or not enhanced_report_data.get('charts'):
            await processing_msg.edit_text(
                "❌ <b>Ошибка генерации расширенного анализа</b>\n\n"
                "Попробуйте позже или обратитесь к администратору.",
                parse_mode="HTML"
            )
            return
        
        # Удаляем сообщение о процессе
        try:
            await processing_msg.delete()
        except Exception:
            pass
        
        # Отправляем расширенные графики по одному
        from aiogram.types import FSInputFile
        
        enhanced_charts_info = [
            ('annual_forecast', '📅 <b>Годовой прогноз расходов</b>\n\nПрогноз расходов на коммунальные услуги по месяцам с учетом сезонности.'),
            ('cost_per_m2', '📏 <b>Сравнение стоимости за м²</b>\n\nСравнение текущих расходов с региональными стандартами по каждой услуге.'),
            ('roi_analysis', '💰 <b>Экономическая эффективность улучшений</b>\n\nROI и окупаемость энергосберегающих улучшений.'),
            ('advanced_violations', '🔍 <b>Продвинутое выявление нарушений</b>\n\nДетальный анализ аномалий и потенциальных нарушений.')
        ]
        
        for chart_type, caption in enhanced_charts_info:
            chart_path = enhanced_report_data['charts'].get(chart_type)
            if chart_path and os.path.exists(chart_path):
                try:
                    chart_file = FSInputFile(chart_path)
                    await callback_query.message.reply_photo(
                        photo=chart_file,
                        caption=caption,
                        parse_mode="HTML"
                    )
                    await asyncio.sleep(0.5)  # Небольшая задержка между отправками
                except Exception as e:
                    logger.error(f"Error sending enhanced chart {chart_type}: {e}")
                    continue
        
        # Отправляем текстовое резюме расширенного анализа
        summary_text = enhanced_report_data.get('summary', 'Расширенный анализ завершен')
        await callback_query.message.reply(
            f"✅ <b>Расширенный анализ завершен!</b>\n\n"
            f"{summary_text}\n\n"
            "📊 Выше представлены детальные графики расширенного анализа:\n\n"
            "• Годовой прогноз расходов\n"
            "• Сравнение стоимости за м²\n"
            "• Экономическая эффективность улучшений\n"
            "• Продвинутое выявление нарушений\n\n"
            "📄 Для получения документации и шаблонов жалоб используйте соответствующие кнопки.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="📄 Документация и шаблоны",
                        callback_data=f"documentation_{analysis_id}"
                    )
                ],
                [
                    InlineKeyboardButton(
                        text="← Назад к результатам",
                        callback_data="back_to_results"
                    )
                ]
            ])
        )
        
    except Exception as e:
        logger.error(f"Error in callback_enhanced_analysis: {e}")
        
        try:
            await processing_msg.edit_text(
                "❌ <b>Ошибка при создании расширенного анализа</b>\n\n"
                f"Попробуйте позже. Ошибка: {str(e)[:100]}...",
                parse_mode="HTML"
            )
        except Exception:
            await callback_query.message.reply(
                "❌ Ошибка при создании расширенного анализа. Попробуйте позже."
            )


@router.callback_query(F.data.startswith("documentation_"))
async def callback_documentation(callback_query):
    """Показать документацию и шаблоны"""
    
    await callback_query.answer("📄 Генерация документации...")
    
    # Extract analysis ID from callback data
    try:
        analysis_id = int(callback_query.data.split("_")[-1])
        user_id = callback_query.from_user.id
    except (ValueError, IndexError):
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    
    try:
        # Получаем данные анализа из базы данных
        from services.analysis_service import analysis_service
        analysis_details = await analysis_service.get_analysis_details(analysis_id, user_id)
        
        if not analysis_details:
            await callback_query.answer("Анализ не найден", show_alert=True)
            return
        
        property_info = {
            'consumer_name': callback_query.from_user.full_name or callback_query.from_user.first_name,
            'property_address': 'г. Москва, ул. Примерная, д. 1, кв. 1',
            'phone': '+7 (XXX) XXX-XX-XX',
            'email': 'example@email.com',
            'management_company': 'УК "Примерная"'
        }
        
        # Генерируем пакет документации
        from services.advanced_analysis_service import AdvancedAnalysisService
        advanced_service = AdvancedAnalysisService()
        
        documentation_package = await advanced_service.generate_documentation_package(
            analysis_details, property_info)
        
        # Отправляем документацию
        documentation_text = """
📄 <b>Создание документов на основе анализа</b>

На основе вашего анализа квитанции вы можете создать следующие документы:

🔹 <b>Жалоба в УК</b> - готовый шаблон жалобы в управляющую компанию
🔹 <b>Заявление на перерасчет</b> - форма заявления с вашими данными
🔹 <b>Обращение в жилинспекцию</b> - жалоба в надзорные органы
🔹 <b>Претензия</b> - официальная претензия с расчетами

Все документы будут автоматически заполнены данными из вашего анализа.
        """
        
        await callback_query.message.reply(
            documentation_text,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="📋 Жалоба в УК",
                        callback_data=f"complaint_template_{analysis_id}"
                    ),
                    InlineKeyboardButton(
                        text="📝 Заявление на перерасчет",
                        callback_data=f"recalculation_template_{analysis_id}"
                    )
                ],
                [
                    InlineKeyboardButton(
                        text="🏛️ Обращение в жилинспекцию",
                        callback_data=f"housing_inspection_template_{analysis_id}"
                    ),
                    InlineKeyboardButton(
                        text="📄 Претензия",
                        callback_data=f"claim_template_{analysis_id}"
                    )
                ],
                [
                    InlineKeyboardButton(
                        text="← Назад к расширенному анализу",
                        callback_data=f"enhanced_analysis_{analysis_id}"
                    )
                ]
            ])
        )
        
    except Exception as e:
        logger.error(f"Error in callback_documentation: {e}")
        await callback_query.message.reply(
            "❌ Ошибка при генерации документации. Попробуйте позже."
        )


@router.callback_query(F.data.startswith("complaint_template_"))
async def callback_complaint_template(callback_query):
    """Показать шаблон жалобы"""
    
    await callback_query.answer()
    
    # Extract analysis ID from callback data
    try:
        analysis_id = int(callback_query.data.split("_")[-1])
        user_id = callback_query.from_user.id
    except (ValueError, IndexError):
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    
    try:
        # Получаем данные анализа из базы данных
        from services.analysis_service import analysis_service
        analysis_details = await analysis_service.get_analysis_details(analysis_id, user_id)
        
        if not analysis_details:
            await callback_query.answer("Анализ не найден", show_alert=True)
            return
        
        # Получаем данные пользователя из базы данных
        from database.connection import get_db
        from datetime import datetime
        db = await get_db()
        async with db as conn:
            cursor = await conn.execute("""
                SELECT full_name, address, phone_number 
                FROM users 
                WHERE telegram_id = ?
            """, (user_id,))
            user_data = await cursor.fetchone()
        
        # Извлекаем данные пользователя
        full_name = user_data[0] if user_data and user_data[0] else (callback_query.from_user.full_name or callback_query.from_user.first_name)
        address = user_data[1] if user_data and user_data[1] else "Адрес не указан"
        phone_number = user_data[2] if user_data and user_data[2] else "Телефон не указан"
        
        # Generate complaint template with actual data
        summary = analysis_details.get('summary', {})
        violations = analysis_details.get('violations', [])
        period = summary.get('period', 'период не указан')
        management_company = summary.get('management_company', 'Управляющая компания')
        total_overpayment = parse_currency_value(summary.get('total_overpayment', 0))
        
        # Create a more detailed complaint template based on actual violations
        violations_list = ""
        for i, violation in enumerate(violations[:5], 1):  # Limit to first 5 violations
            description = violation.get('description', 'Нарушение тарификации')
            violations_list += f"{i}. {description}\n"
        
        if not violations_list:
            violations_list = "1. Обнаружены отклонения в тарификации услуг ЖКХ\n"
        
        complaint_template = f"""
<b>ШАБЛОН ЖАЛОБЫ НА НЕПРАВОМЕРНЫЕ НАЧИСЛЕНИЯ</b>

В Государственную жилищную инспекцию
г. Москва

От: {full_name}
Адрес: {address}
Телефон: {phone_number}
Email: example@email.com

ЗАЯВЛЕНИЕ

Прошу провести проверку правомерности начислений по квитанциям за услуги ЖКХ по адресу: {address}
за период: {period}

<b>Управляющая организация:</b> {management_company}

<b>Суть нарушений:</b>
{violations_list}

<b>Сумма переплаты:</b> {total_overpayment:.2f} рублей

<b>Правовые основания:</b>
- Жилищный кодекс РФ, статья 154
- Постановление Правительства РФ № 354 от 06.05.2011
- Постановление РЭК Москвы от 15.12.2023 № 234-пп

<b>Требую:</b>
1. Провести проверку правомерности начислений
2. Устранить выявленные нарушения
3. Произвести перерасчет с возвратом переплаты в размере {total_overpayment:.2f} рублей

<b>Приложения:</b>
- Копии квитанций за {period}
- Расчеты переплат
- Копии нормативных документов

Дата: {datetime.now().strftime("%d.%m.%Y")}
Подпись: ________________
        """
        
        # Сохраняем документ в файловой системе и БД
        try:
            await document_service.save_generated_document(user_id, analysis_id, "complaint", complaint_template)
        except Exception as save_err:
            logger.error(f"Saving complaint document failed: {save_err}")

        await callback_query.message.reply(
            complaint_template,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="📋 Скачать как файл",
                        callback_data="download_complaint"
                    )
                ],
                [
                    InlineKeyboardButton(
                        text="← Назад к документации",
                        callback_data=f"documentation_{analysis_id}"
                    )
                ]
            ])
        )
        
    except Exception as e:
        logger.error(f"Error in callback_complaint_template: {e}")
        await callback_query.answer("Ошибка при генерации шаблона жалобы", show_alert=True)


@router.callback_query(F.data.startswith("recalculation_template_"))
async def callback_recalculation_template(callback_query):
    """Показать шаблон заявления на перерасчет"""
    
    await callback_query.answer()
    
    # Extract analysis ID from callback data
    try:
        analysis_id = int(callback_query.data.split("_")[-1])
        user_id = callback_query.from_user.id
    except (ValueError, IndexError):
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    
    try:
        # Получаем данные анализа из базы данных
        from services.analysis_service import analysis_service
        analysis_details = await analysis_service.get_analysis_details(analysis_id, user_id)
        
        if not analysis_details:
            await callback_query.answer("Анализ не найден", show_alert=True)
            return
        
        # Получаем данные пользователя из базы данных
        from database.connection import get_db
        from datetime import datetime
        db = await get_db()
        async with db as conn:
            cursor = await conn.execute("""
                SELECT full_name, address, phone_number 
                FROM users 
                WHERE telegram_id = ?
            """, (user_id,))
            user_data = await cursor.fetchone()
        
        # Извлекаем данные пользователя
        full_name = user_data[0] if user_data and user_data[0] else (callback_query.from_user.full_name or callback_query.from_user.first_name)
        address = user_data[1] if user_data and user_data[1] else "Адрес не указан"
        phone_number = user_data[2] if user_data and user_data[2] else "Телефон не указан"
        
        # Generate recalculation template with actual data
        summary = analysis_details.get('summary', {})
        violations = analysis_details.get('violations', [])
        period = summary.get('period', 'период не указан')
        management_company = summary.get('management_company', 'Управляющая компания')
        total_overpayment = parse_currency_value(summary.get('total_overpayment', 0))
        
        # Create violations details
        violations_details = ""
        for i, violation in enumerate(violations[:5], 1):
            description = violation.get('description', 'Нарушение тарификации')
            amount = parse_currency_value(violation.get('financial_impact', 0))
            violations_details += f"{i}. {description} - переплата {amount:.2f} руб.\n"
        
        if not violations_details:
            violations_details = "1. Обнаружены отклонения в тарификации услуг ЖКХ\n"
        
        recalculation_template = f"""
<b>ЗАЯВЛЕНИЕ НА ПЕРЕРАСЧЕТ</b>

В {management_company}

От: {full_name}
Адрес: {address}
Телефон: {phone_number}

ЗАЯВЛЕНИЕ
о перерасчете платы за коммунальные услуги

Прошу произвести перерасчет платы за коммунальные услуги по адресу: {address}
за период: {period}

<b>Основания для перерасчета:</b>
{violations_details}

<b>Общая сумма переплаты:</b> {total_overpayment:.2f} рублей

<b>Правовые основания:</b>
- Жилищный кодекс РФ, статья 157
- Постановление Правительства РФ № 354 от 06.05.2011
- Правила предоставления коммунальных услуг

<b>Прошу:</b>
1. Произвести перерасчет платы за коммунальные услуги
2. Возвратить переплату в размере {total_overpayment:.2f} рублей
3. Устранить выявленные нарушения в начислении

<b>Приложения:</b>
- Копии квитанций за {period}
- Расчеты переплат
- Документы, подтверждающие нарушения

Дата: {datetime.now().strftime("%d.%m.%Y")}
Подпись: ________________
        """
        
        # Сохраняем документ
        try:
            await document_service.save_generated_document(user_id, analysis_id, "recalculation", recalculation_template)
        except Exception as save_err:
            logger.error(f"Saving recalculation document failed: {save_err}")

        await callback_query.message.reply(
            recalculation_template,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="← Назад к документации",
                        callback_data=f"documentation_{analysis_id}"
                    )
                ]
            ])
        )
        
    except Exception as e:
        logger.error(f"Error in callback_recalculation_template: {e}")
        await callback_query.answer("Ошибка при генерации шаблона заявления", show_alert=True)


@router.callback_query(F.data.startswith("housing_inspection_template_"))
async def callback_housing_inspection_template(callback_query):
    """Показать шаблон обращения в жилинспекцию"""
    
    await callback_query.answer()
    
    # Extract analysis ID from callback data
    try:
        analysis_id = int(callback_query.data.split("_")[-1])
        user_id = callback_query.from_user.id
    except (ValueError, IndexError):
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    
    try:
        # Получаем данные анализа из базы данных
        from services.analysis_service import analysis_service
        analysis_details = await analysis_service.get_analysis_details(analysis_id, user_id)
        
        if not analysis_details:
            await callback_query.answer("Анализ не найден", show_alert=True)
            return
        
        # Получаем данные пользователя из базы данных
        from database.connection import get_db
        from datetime import datetime
        db = await get_db()
        async with db as conn:
            cursor = await conn.execute("""
                SELECT full_name, address, phone_number 
                FROM users 
                WHERE telegram_id = ?
            """, (user_id,))
            user_data = await cursor.fetchone()
        
        # Извлекаем данные пользователя
        full_name = user_data[0] if user_data and user_data[0] else (callback_query.from_user.full_name or callback_query.from_user.first_name)
        address = user_data[1] if user_data and user_data[1] else "Адрес не указан"
        phone_number = user_data[2] if user_data and user_data[2] else "Телефон не указан"
        
        # Generate housing inspection template with actual data
        summary = analysis_details.get('summary', {})
        violations = analysis_details.get('violations', [])
        period = summary.get('period', 'период не указан')
        management_company = summary.get('management_company', 'Управляющая компания')
        total_overpayment = parse_currency_value(summary.get('total_overpayment', 0))
        
        # Create violations details
        violations_details = ""
        for i, violation in enumerate(violations[:5], 1):
            description = violation.get('description', 'Нарушение тарификации')
            violations_details += f"{i}. {description}\n"
        
        if not violations_details:
            violations_details = "1. Обнаружены отклонения в тарификации услуг ЖКХ\n"
        
        housing_inspection_template = f"""
<b>ОБРАЩЕНИЕ В ЖИЛИЩНУЮ ИНСПЕКЦИЮ</b>

В Государственную жилищную инспекцию
г. Москва

От: {full_name}
Адрес: {address}
Телефон: {phone_number}

ОБРАЩЕНИЕ
о нарушении жилищного законодательства

Прошу провести проверку деятельности управляющей организации "{management_company}" 
по адресу: {address}

<b>Суть нарушений:</b>
{violations_details}

<b>Период нарушений:</b> {period}
<b>Сумма переплаты:</b> {total_overpayment:.2f} рублей

<b>Правовые основания:</b>
- Жилищный кодекс РФ, статья 20
- Постановление Правительства РФ № 354 от 06.05.2011
- Федеральный закон № 59-ФЗ "О порядке рассмотрения обращений граждан"

<b>Прошу:</b>
1. Провести внеплановую проверку деятельности УК
2. Привлечь к ответственности за нарушения
3. Обеспечить устранение выявленных нарушений
4. Произвести перерасчет с возвратом переплаты

<b>Приложения:</b>
- Копии квитанций за {period}
- Расчеты переплат
- Документы, подтверждающие нарушения

Дата: {datetime.now().strftime("%d.%m.%Y")}
Подпись: ________________
        """
        
        # Сохраняем документ
        try:
            await document_service.save_generated_document(user_id, analysis_id, "housing_inspection", housing_inspection_template)
        except Exception as save_err:
            logger.error(f"Saving housing_inspection document failed: {save_err}")

        await callback_query.message.reply(
            housing_inspection_template,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="← Назад к документации",
                        callback_data=f"documentation_{analysis_id}"
                    )
                ]
            ])
        )
        
    except Exception as e:
        logger.error(f"Error in callback_housing_inspection_template: {e}")
        await callback_query.answer("Ошибка при генерации шаблона обращения", show_alert=True)


@router.callback_query(F.data.startswith("claim_template_"))
async def callback_claim_template(callback_query):
    """Показать шаблон претензии"""
    
    await callback_query.answer()
    
    # Extract analysis ID from callback data
    try:
        analysis_id = int(callback_query.data.split("_")[-1])
        user_id = callback_query.from_user.id
    except (ValueError, IndexError):
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
        return
    
    try:
        # Получаем данные анализа из базы данных
        from services.analysis_service import analysis_service
        analysis_details = await analysis_service.get_analysis_details(analysis_id, user_id)
        
        if not analysis_details:
            await callback_query.answer("Анализ не найден", show_alert=True)
            return
        
        # Получаем данные пользователя из базы данных
        from database.connection import get_db
        from datetime import datetime
        db = await get_db()
        async with db as conn:
            cursor = await conn.execute("""
                SELECT full_name, address, phone_number 
                FROM users 
                WHERE telegram_id = ?
            """, (user_id,))
            user_data = await cursor.fetchone()
        
        # Извлекаем данные пользователя
        full_name = user_data[0] if user_data and user_data[0] else (callback_query.from_user.full_name or callback_query.from_user.first_name)
        address = user_data[1] if user_data and user_data[1] else "Адрес не указан"
        phone_number = user_data[2] if user_data and user_data[2] else "Телефон не указан"
        
        # Generate claim template with actual data
        summary = analysis_details.get('summary', {})
        violations = analysis_details.get('violations', [])
        period = summary.get('period', 'период не указан')
        management_company = summary.get('management_company', 'Управляющая компания')
        total_overpayment = parse_currency_value(summary.get('total_overpayment', 0))
        
        # Create violations details
        violations_details = ""
        for i, violation in enumerate(violations[:5], 1):
            description = violation.get('description', 'Нарушение тарификации')
            amount = parse_currency_value(violation.get('financial_impact', 0))
            violations_details += f"{i}. {description} - переплата {amount:.2f} руб.\n"
        
        if not violations_details:
            violations_details = "1. Обнаружены отклонения в тарификации услуг ЖКХ\n"
        
        claim_template = f"""
<b>ПРЕТЕНЗИЯ</b>

В {management_company}

От: {full_name}
Адрес: {address}
Телефон: {phone_number}

ПРЕТЕНЗИЯ
о неправомерном начислении коммунальных платежей

Настоящим выражаю претензию по поводу неправомерного начисления платы за коммунальные услуги
по адресу: {address} за период: {period}

<b>Суть претензии:</b>
{violations_details}

<b>Общая сумма переплаты:</b> {total_overpayment:.2f} рублей

<b>Правовые основания:</b>
- Гражданский кодекс РФ, статья 1102
- Жилищный кодекс РФ, статья 157
- Постановление Правительства РФ № 354 от 06.05.2011

<b>Требования:</b>
1. Произвести перерасчет платы за коммунальные услуги
2. Возвратить переплату в размере {total_overpayment:.2f} рублей
3. Устранить выявленные нарушения в начислении
4. Предоставить письменный ответ в течение 30 дней

<b>Приложения:</b>
- Копии квитанций за {period}
- Расчеты переплат
- Документы, подтверждающие нарушения

В случае неудовлетворения претензии в указанный срок, буду вынужден обратиться в суд.

Дата: {datetime.now().strftime("%d.%m.%Y")}
Подпись: ________________
        """
        
        # Сохраняем документ
        try:
            await document_service.save_generated_document(user_id, analysis_id, "claim", claim_template)
        except Exception as save_err:
            logger.error(f"Saving claim document failed: {save_err}")

        await callback_query.message.reply(
            claim_template,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="← Назад к документации",
                        callback_data=f"documentation_{analysis_id}"
                    )
                ]
            ])
        )
        
    except Exception as e:
        logger.error(f"Error in callback_claim_template: {e}")
        await callback_query.answer("Ошибка при генерации шаблона претензии", show_alert=True)


def register_document_handlers(dp):
    """Регистрация обработчиков документов"""
    dp.include_router(router)
