"""
Обработчики команды /start и приветствия
"""

from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.filters import Command, CommandStart
import logging
from datetime import datetime
from typing import Optional

from services.analysis_service import analysis_service
from database.connection import is_user_admin, get_user_subscription_info
from config import settings

logger = logging.getLogger(__name__)

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    """Обработка команды /start"""
    
    user = message.from_user
    if not user:
        return
    
    # Проверяем параметры команды start (например, для возврата с платежа)
    command_args = message.text.split()[1:] if len(message.text.split()) > 1 else []
    
    logger.info(f"👋 Пользователь: {user.id} (@{user.username if user.username else 'No username'})")
    
    # Если это возврат с платежа
    if command_args and command_args[0].startswith('payment_'):
        payment_id = command_args[0].replace('payment_', '')
        await handle_payment_return(message, payment_id)
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user.id) or user.id == 1043893977
    
    # Получаем информацию о подписке
    subscription_info = await get_user_subscription_info(user.id)
    analyses_count = subscription_info['analyses_count']
    subscription_type = subscription_info['subscription_type']
    
    # Создание клавиатуры с основными действиями
    keyboard_buttons = []
    
    # Проверяем, нужна ли аутентификация
    if not subscription_info or analyses_count == 0:
        keyboard_buttons.append([
            InlineKeyboardButton(
                text="🔐 Аутентификация",
                callback_data="start_auth"
            )
        ])
    
    keyboard_buttons.extend([
        [
            InlineKeyboardButton(
                text="📄 Загрузить квитанцию ЖКХ",
                callback_data="upload_receipt"
            )
        ],
        [
            InlineKeyboardButton(
                text="🧭 Мастер споров",
                callback_data="dispute_wizard"
            )
        ],
        [
            InlineKeyboardButton(
                text="💳 Подписка",
                callback_data="subscription_info"
            ),
            InlineKeyboardButton(
                text="📊 Мои анализы",
                callback_data="my_analyses"
            )
        ],
        [
            InlineKeyboardButton(
                text="👤 Личный кабинет",
                callback_data="cabinet"
            ),
            InlineKeyboardButton(
                text="📝 Мои документы",
                callback_data="my_documents"
            ),
            InlineKeyboardButton(
                text="❓ Помощь",
                callback_data="help"
            )
        ]
    ])
    
    # Добавляем кнопку админки для администраторов
    if is_admin:
        keyboard_buttons.append([
            InlineKeyboardButton(
                text="👑 Админка",
                callback_data="admin"
            )
        ])
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    # Формируем приветственное сообщение с информацией о подписке
    free_left = max(0, settings.free_analyses_limit - analyses_count)
    
    subscription_status = ""
    if subscription_type == 'free' or not subscription_info.get('subscription_expires_at'):
        if free_left > 0:
            subscription_status = f"\n🆓 <b>Бесплатных анализов осталось:</b> {free_left}"
        else:
            subscription_status = "\n⚠️ <b>Бесплатные анализы исчерпаны. Требуется подписка.</b>"
    else:
        subscription_status = "\n💎 <b>Премиум подписка активна</b>"
    
    welcome_text = f"""
🏠 <b>Добро пожаловать в ЖКХ Контроль!</b>

Привет, {user.first_name if user.first_name else 'пользователь'}! 👋

Я помогу вам проанализировать квитанции ЖКХ и выявить возможные нарушения в тарификации.{subscription_status}

<b>Что я умею:</b>
• 📋 Анализировать PDF квитанции ЖКХ
• 🔍 Проверять соответствие тарифов нормативам
• 📊 Создавать подробные отчеты с графиками  
• ⚠️ Выявлять переплаты и ошибки
• 💰 Рассчитывать потенциальную экономию
• 📝 Генерировать жалобы и заявления

<b>Для начала работы:</b>
Отправьте мне PDF файл с квитанцией ЖКХ! 🔎

<i>Анализ выполняется с помощью ИИ на базе современных нейросетей.</i>
"""
    
    await message.answer(
        welcome_text,
        reply_markup=keyboard,
        parse_mode="HTML"
    )


async def handle_payment_return(message: Message, payment_id: str):
    """Обработка возврата с платежной страницы"""
    
    user = message.from_user
    if not user:
        return
    
    try:
        from services.payment_service import payment_service
        
        # Проверяем статус платежа
        payment_status = await payment_service.check_payment_status(payment_id)
        
        if payment_status['status'] == 'succeeded':
            success_text = """
✅ <b>Платеж успешно завершен!</b>

Ваша подписка активирована! Теперь вы можете анализировать квитанции без ограничений.

Спасибо за покупку! 🎉
"""
            
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="📄 Загрузить квитанцию", callback_data="upload_receipt")],
                [InlineKeyboardButton(text="📊 Мои анализы", callback_data="my_analyses")]
            ])
            
            await message.answer(success_text, reply_markup=keyboard, parse_mode="HTML")
            
        elif payment_status['status'] in ['pending', 'waiting_for_capture']:
            await message.answer(
                "⏳ Ваш платеж обрабатывается. Уведомление придет автоматически.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="🏠 Главное меню", callback_data="back_to_start")]
                ])
            )
            
        else:
            await message.answer(
                "❌ Платеж не прошел. Попробуйте еще раз или обратитесь в поддержку.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="💳 Попробовать снова", callback_data="create_payment")],
                    [InlineKeyboardButton(text="🏠 Главное меню", callback_data="back_to_start")]
                ])
            )
    
    except Exception as e:
        logger.error(f"❌ Ошибка обработки возврата с платежа: {e}")
        await message.answer(
            "❌ Ошибка проверки платежа. Обратитесь в поддержку.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🏠 Главное меню", callback_data="back_to_start")]
            ])
        )


@router.callback_query(F.data == "start_auth")
async def callback_start_auth(callback_query: CallbackQuery):
    """Начать процесс аутентификации"""
    
    from aiogram.types import KeyboardButton, ReplyKeyboardMarkup
    
    # Создаем клавиатуру для запроса номера телефона
    phone_keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📞 Поделиться номером телефона", request_contact=True)]
        ],
        resize_keyboard=True,
        one_time_keyboard=True
    )
    
    auth_text = """
🔐 <b>Аутентификация в ЖКХ Контроль</b>

Для предотвращения злоупотреблений необходимо подтвердить номер телефона.

<b>Зачем это нужно:</b>
• Защита от создания множественных аккаунтов
• Безопасность вашего аккаунта
• Доступ ко всем функциям бота

Нажмите кнопку ниже для подтверждения.

🔒 <i>Номер используется только для аутентификации.</i>
"""
    
    await callback_query.message.answer(
        auth_text,
        reply_markup=phone_keyboard,
        parse_mode="HTML"
    )
    
    await callback_query.answer()


@router.callback_query(F.data.startswith("view_document_"))
async def callback_view_document(callback_query: CallbackQuery):
    """Открыть сохраненный документ по его ID из таблицы generated_documents."""
    from aiogram.types import FSInputFile
    from database.connection import get_db
    import os

    # Парсим ID
    try:
        doc_id = int(callback_query.data.split("_")[-1])
    except Exception:
        await callback_query.answer("Некорректный документ", show_alert=True)
        return

    # Достаем путь из БД
    db = await get_db()
    async with db as conn:
        cur = await conn.execute(
            """
            SELECT document_type, file_path, created_at
            FROM generated_documents
            WHERE id = ?
            """,
            (doc_id,)
        )
        row = await cur.fetchone()

    if not row:
        await callback_query.answer("Документ не найден", show_alert=True)
        return

    doc_type, file_path, created_at = row

    # Если файл существует — отправляем как файл
    if file_path and os.path.exists(file_path):
        try:
            await callback_query.message.answer_document(
                document=FSInputFile(file_path),
                caption=f"📄 {doc_type} — {created_at[:16]}"
            )
            await callback_query.answer()
            return
        except Exception as e:
            logger.warning(f"Send document file failed: {e}")

    # Иначе — читаем содержимое и отправляем как текст
    try:
        if file_path and os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        else:
            content = f"Документ ({doc_type}) от {created_at[:16]}\nФайл недоступен по пути: {file_path}"

        # Telegram ограничивает длину сообщений, поэтому обрежем при необходимости
        if len(content) > 3900:
            content = content[:3900] + "\n... (обрезано)"

        await callback_query.message.answer(
            content,
            parse_mode="HTML"
        )
        await callback_query.answer()
    except Exception as e:
        logger.error(f"Error sending document content: {e}")
        await callback_query.answer("Ошибка при открытии документа", show_alert=True)


@router.callback_query(F.data == "upload_receipt")
async def callback_upload_receipt(callback_query):
    """Обработка кнопки загрузки квитанции"""
    
    user = callback_query.from_user
    if not user:
        await callback_query.answer()
        return
    
    # Проверяем возможность анализа
    from handlers.auth_handler import check_analysis_permission
    
    can_analyze, limit_message, limit_keyboard = await check_analysis_permission(user.id)
    
    if not can_analyze:
        await callback_query.message.edit_text(
            limit_message,
            reply_markup=limit_keyboard,
            parse_mode="HTML"
        )
        await callback_query.answer()
        return
    
    await callback_query.message.edit_text(
        "📄 <b>Загрузка квитанции ЖКХ</b>\n\n"
        "Отправьте мне PDF файл с квитанцией ЖКХ для анализа.\n\n"
        "<b>Требования к файлу:</b>\n"
        "• Формат: PDF\n"
        "• Размер: до 50 МБ\n"
        "• Текст должен быть читаемым (не скан плохого качества)\n\n"
        "🔒 <i>Ваши данные обрабатываются конфиденциально.</i>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="← Назад", callback_data="back_to_start")]
        ])
    )
    
    await callback_query.answer()


@router.callback_query(F.data == "back_to_start")
async def callback_back_to_start(callback_query: CallbackQuery):
    """Возврат к главному меню"""
    
    user = callback_query.from_user
    if not user:
        await callback_query.answer()
        return
    
    # Получаем информацию о подписке
    subscription_info = await get_user_subscription_info(user.id)
    analyses_count = subscription_info['analyses_count']
    subscription_type = subscription_info['subscription_type']
    
    is_admin = await is_user_admin(user.id) or user.id == 1043893977
    
    # Создание клавиатуры с основными действиями
    keyboard_buttons = []
    
    # Проверяем, нужна ли аутентификация
    if not subscription_info or analyses_count == 0:
        keyboard_buttons.append([
            InlineKeyboardButton(
                text="🔐 Аутентификация",
                callback_data="start_auth"
            )
        ])
    
    keyboard_buttons.extend([
        [
            InlineKeyboardButton(
                text="📄 Загрузить квитанцию ЖКХ",
                callback_data="upload_receipt"
            )
        ],
        [
            InlineKeyboardButton(
                text="💳 Подписка",
                callback_data="subscription_info"
            ),
            InlineKeyboardButton(
                text="📊 Мои анализы",
                callback_data="my_analyses"
            )
        ],
        [
            InlineKeyboardButton(
                text="📝 Мои документы",
                callback_data="my_documents"
            ),
            InlineKeyboardButton(
                text="❓ Помощь",
                callback_data="help"
            )
        ]
    ])
    
    # Добавляем кнопку админки для администраторов
    if is_admin:
        keyboard_buttons.append([
            InlineKeyboardButton(
                text="👑 Админка",
                callback_data="admin"
            )
        ])
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    # Формируем приветственное сообщение с информацией о подписке
    free_left = max(0, settings.free_analyses_limit - analyses_count)
    
    subscription_status = ""
    if subscription_type == 'free' or not subscription_info.get('subscription_expires_at'):
        if free_left > 0:
            subscription_status = f"\n🆓 <b>Бесплатных анализов осталось:</b> {free_left}"
        else:
            subscription_status = "\n⚠️ <b>Бесплатные анализы исчерпаны. Требуется подписка.</b>"
    else:
        subscription_status = "\n💎 <b>Премиум подписка активна</b>"
    
    welcome_text = f"""
🏠 <b>ЖКХ Контроль - Главное меню</b>

Привет, {user.first_name if user.first_name else 'пользователь'}! 👋{subscription_status}

Выберите действие из меню ниже:
"""
    
    await callback_query.message.edit_text(
        welcome_text,
        reply_markup=keyboard,
        parse_mode="HTML"
    )
    
    await callback_query.answer()


@router.callback_query(F.data == "my_documents")
async def callback_my_documents(callback_query: CallbackQuery):
    """Показать документы пользователя"""
    
    user = callback_query.from_user
    if not user:
        await callback_query.answer()
        return
    
    try:
        from services.document_service import document_service
        
        # Получаем документы пользователя
        documents = await document_service.get_user_documents(user.id)
        
        if not documents:
            documents_text = """
📝 <b>Мои документы</b>

У вас пока нет сгенерированных документов.

После анализа квитанций вы сможете создавать:
• Жалобы на управляющую компанию
• Заявления на перерасчет
• Обращения в жилищную инспекцию

Для создания документов сначала загрузите и проанализируйте квитанции.
"""
            
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="📊 Мои анализы", callback_data="my_analyses")],
                [InlineKeyboardButton(text="📄 Загрузить квитанцию", callback_data="upload_receipt")],
                [InlineKeyboardButton(text="← Назад", callback_data="back_to_start")]
            ])
        else:
            documents_text = f"📝 <b>Мои документы</b>\n\nВсего документов: {len(documents)}\n\n"

            # Кнопки для открытия каждого документа
            doc_type_names = {
                'complaint': 'Жалоба',
                'recalculation': 'Заявление на перерасчет',
                'housing_inspection': 'Обращение в жилинспекцию',
                'claim': 'Претензия',
            }
            per_doc_rows = []
            for i, doc in enumerate(documents[:10], 1):
                doc_id = doc.get('id')
                doc_name = doc_type_names.get(doc.get('document_type'), doc.get('document_type', 'document'))
                created_date = (doc.get('created_at') or '')[:16]
                documents_text += f"{i}. {doc_name} ({created_date})\n"
                # Добавляем кнопку открытия файла
                if doc_id:
                    per_doc_rows.append([
                        InlineKeyboardButton(text=f"Открыть: {doc_name} ({created_date})", callback_data=f"view_document_{doc_id}")
                    ])

            if len(documents) > 10:
                documents_text += f"\n... и еще {len(documents) - 10} документов"

            base_rows = [
                [InlineKeyboardButton(text="📊 Мои анализы", callback_data="my_analyses")],
                [InlineKeyboardButton(text="📄 Создать новый документ", callback_data="upload_receipt")],
                [InlineKeyboardButton(text="← Назад", callback_data="back_to_start")]
            ]
            keyboard = InlineKeyboardMarkup(inline_keyboard=per_doc_rows + base_rows)
        
        await callback_query.message.edit_text(
            documents_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )
        
    except Exception as e:
        logger.error(f"❌ Ошибка получения документов для {user.id}: {e}")
        await callback_query.answer("❌ Ошибка получения документов")
    
    await callback_query.answer()
async def callback_upload_receipt(callback_query):
    """Обработка кнопки загрузки квитанции"""
    
    await callback_query.message.edit_text(
        "📄 <b>Загрузка квитанции ЖКХ</b>\n\n"
        "Отправьте мне PDF файл с квитанцией ЖКХ для анализа.\n\n"
        "<b>Требования к файлу:</b>\n"
        "• Формат: PDF\n"
        "• Размер: до 50 МБ\n"
        "• Текст должен быть читаемым (не скан плохого качества)\n\n"
        "🔒 <i>Ваши данные обрабатываются конфиденциально и не передаются третьим лицам.</i>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="← Назад", callback_data="back_to_start")]
        ])
    )
    
    await callback_query.answer()


@router.callback_query(F.data == "help")
async def callback_help(callback_query):
    """Обработка кнопки помощи"""
    
    help_text = """
❓ <b>Помощь по использованию бота</b>

<b>Как пользоваться:</b>
1️⃣ Отправьте PDF файл квитанции ЖКХ
2️⃣ Дождитесь завершения анализа (1-2 минуты)
3️⃣ Получите подробный отчет с выводами

<b>Что анализируется:</b>
• 💧 Водоснабжение (холодная/горячая вода)
• 🔥 Отопление и теплоснабжение
• ⚡ Электроэнергия
• 🏠 Содержание жилья
• 🔧 Капитальный ремонт
• 🚿 Водоотведение

<b>Результаты анализа:</b>
• ✅ Соответствие тарифов нормативам
• ⚠️ Выявленные нарушения
• 📊 Графики и сравнения
• 💰 Расчет переплат
• 📋 Рекомендации по действиям

<b>Поддерживаемые форматы:</b>
• PDF файлы с текстовым содержимым
• Размер до 50 МБ

Если у вас остались вопросы, обратитесь к администратору.
"""
    
    await callback_query.message.edit_text(
        help_text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="← Назад", callback_data="back_to_start")]
        ])
    )
    
    await callback_query.answer()


@router.callback_query(F.data == "about")
async def callback_about(callback_query):
    """Обработка кнопки о боте"""
    
    about_text = """
ℹ️ <b>О боте ЖКХ Контроль</b>

<b>Версия:</b> 1.0.0
<b>Разработчик:</b> ЖКХ Контроль Team

<b>Технологии:</b>
• 🤖 Python + aiogram 3.x
• 🧠 Yandex.Cloud для обработки PDF
• 🎯 Claude Sonnet-4 для анализа
• 📊 Matplotlib для графиков
• 💾 SQLite для хранения данных

<b>Возможности:</b>
• Анализ PDF квитанций ЖКХ
• Сравнение с региональными тарифами
• Выявление нарушений и переплат
• Генерация подробных отчетов
• Графическая визуализация данных

<b>Конфиденциальность:</b>
🔒 Все загружаемые данные обрабатываются в зашифрованном виде и не передаются третьим лицам. Личная информация автоматически удаляется после анализа.

<b>Поддержка:</b>
Если вы нашли ошибку или у вас есть предложения по улучшению, свяжитесь с нами через /feedback
"""
    
    await callback_query.message.edit_text(
        about_text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="← Назад", callback_data="back_to_start")]
        ])
    )
    
    await callback_query.answer()


@router.callback_query(F.data == "my_analyses")
async def callback_my_analyses(callback_query: CallbackQuery):
    """Обработка кнопки мои анализы"""
    
    if not callback_query.message:
        await callback_query.answer()
        return
        
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        await callback_query.answer("Ошибка идентификации пользователя")
        return
        
    await callback_query.answer("📊 Загрузка истории анализов...")
    
    try:
        # Получаем историю анализов пользователя
        history = await analysis_service.get_analysis_history(user_id, limit=10)
        
        if not history:
            analyses_text = "📊 <b>Ваши анализы</b>\n\n"
            analyses_text += "📭 История анализов пуста.\n\n"
            analyses_text += "Для начала работы отправьте PDF файл с квитанцией ЖКХ."
        else:
            analyses_text = "📊 <b>История ваших анализов</b>\n\n"
            analyses_text += f"Найдено анализов: {len(history)}\n\n"
            
            # Создаем клавиатуру с кнопками для каждого анализа
            keyboard_buttons = []
            
            for i, analysis in enumerate(history, 1):
                # Форматируем дату
                try:
                    started_at = datetime.fromisoformat(analysis['started_at']).strftime("%d.%m.%Y %H:%M")
                except:
                    started_at = analysis['started_at']
                
                # Определяем статус
                status_emoji = "🔄"
                if analysis['status'] == 'completed':
                    status_emoji = "✅"
                elif analysis['status'] == 'error':
                    status_emoji = "❌"
                
                # Формируем запись
                analyses_text += f"<b>{i}. {analysis['file_name']}</b>\n"
                analyses_text += f"   {status_emoji} {started_at}\n"
                
                if analysis['status'] == 'completed':
                    analyses_text += f"   ⚠️ Нарушений: {analysis['violations_count']}\n"
                    # Format the overpayment value properly
                    overpayment = analysis['total_overpayment']
                    if isinstance(overpayment, (int, float)):
                        overpayment_str = f"{overpayment:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
                    else:
                        overpayment_str = f"{overpayment} ₽"
                    analyses_text += f"   💰 Переплата: {overpayment_str}\n"
                    # Добавляем кнопку для просмотра
                    keyboard_buttons.append([
                        InlineKeyboardButton(
                            text=f"🔍 Просмотр #{analysis['id']}",
                            callback_data=f"view_analysis_{analysis['id']}"
                        )
                    ])
                elif analysis['status'] == 'error':
                    analyses_text += f"   ❌ Ошибка: {analysis['error_message'][:50]}...\n"
                else:
                    analyses_text += f"   🔄 В процессе...\n"
                
                analyses_text += "\n"
        
        # Добавляем общие кнопки
        keyboard_buttons.append([InlineKeyboardButton(text="📄 Новый анализ", callback_data="upload_receipt")])
        keyboard_buttons.append([InlineKeyboardButton(text="← Назад", callback_data="back_to_start")])
        
        try:
            await callback_query.message.edit_text(
                analyses_text,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
            )
        except Exception as edit_error:
            logger.warning(f"Could not edit message: {edit_error}")
            # Если не можем отредактировать сообщение, отправляем новое
            await callback_query.message.reply(
                analyses_text,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
            )
        
    except Exception as e:
        logger.error(f"Ошибка при получении истории анализов: {e}")
        try:
            await callback_query.message.edit_text(
                "📊 <b>Ваши анализы</b>\n\n"
                "❌ Произошла ошибка при загрузке истории анализов.\n\n"
                "Попробуйте позже или обратитесь к администратору.",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="← Назад", callback_data="back_to_start")]
                ])
            )
        except Exception as edit_error:
            logger.warning(f"Could not edit error message: {edit_error}")
            await callback_query.message.reply(
                "📊 <b>Ваши анализы</b>\n\n"
                "❌ Произошла ошибка при загрузке истории анализов.\n\n"
                "Попробуйте позже или обратитесь к администратору.",
                parse_mode="HTML"
            )


@router.callback_query(F.data.startswith("view_analysis_"))
async def callback_view_analysis(callback_query: CallbackQuery):
    """Просмотр деталей анализа"""
    
    if not callback_query.message or not callback_query.data or not callback_query.from_user:
        await callback_query.answer()
        return
    
    try:
        # Debug information
        logger.info(f"🔍 View analysis callback received: {callback_query.data}")
        logger.info(f"👤 User ID: {callback_query.from_user.id if callback_query.from_user else 'Unknown'}")
        
        analysis_id = int(callback_query.data.split("_")[-1])
        user_id = callback_query.from_user.id
        
        logger.info(f"📊 Requesting analysis {analysis_id} for user {user_id}")
        
        # Получаем детали анализа
        analysis_details = await analysis_service.get_analysis_details(analysis_id, user_id)
        
        logger.info(f"📄 Analysis details result: {analysis_details is not None}")
        
        if not analysis_details:
            logger.warning(f"❌ Analysis {analysis_id} not found for user {user_id}")
            await callback_query.answer("Анализ не найден", show_alert=True)
            return
        
        # Формируем текст отчета
        summary = analysis_details.get('summary', {})
        violations = analysis_details.get('violations', [])
        
        # Определяем общий статус
        if violations:
            status_emoji = "⚠️"
            status_text = "Обнаружены нарушения"
            status_color = "🔴"
        else:
            status_emoji = "✅"
            status_text = "Нарушений не обнаружено"
            status_color = "🟢"
        
        # Создаем основное сообщение
        report_text = f"""
{status_emoji} <b>Анализ квитанции ЖКХ</b>

{status_color} <b>Общий статус:</b> {status_text}

<b>📊 Краткий обзор:</b>
• Проанализировано услуг: {len(analysis_details.get('services', []))}
• Общая сумма: {summary.get('total_amount', 'Н/Д')} ₽
"""
        
        # Format overpayment properly
        overpayment = summary.get('overpayment', 0)
        if isinstance(overpayment, (int, float)):
            overpayment_str = f"{overpayment:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
        else:
            overpayment_str = f"{overpayment} ₽"
            
        report_text += f"• Потенциальная переплата: {overpayment_str}\n\n"
        
        if violations:
            report_text += "<b>⚠️ Обнаруженные нарушения:</b>\n"
            for i, violation in enumerate(violations[:3], 1):  # Показываем первые 3
                report_text += f"{i}. {violation.get('description', 'Нарушение тарификации')}\n"
            
            if len(violations) > 3:
                report_text += f"• И еще {len(violations) - 3} нарушений...\n"
        
        report_text += "\n<i>Для получения подробного отчета используйте кнопки ниже.</i>"
        
        # Создаем клавиатуру с действиями
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📋 Подробный отчет",
                    callback_data=f"detailed_report_{analysis_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    text="📊 Графики", 
                    callback_data=f"charts_{analysis_id}"
                ),
                InlineKeyboardButton(
                    text="💰 Расчеты",
                    callback_data=f"calculations_{analysis_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    text="📄 Создать документы",
                    callback_data=f"documentation_{analysis_id}"
                ),
                InlineKeyboardButton(
                    text="🔮 Расширенный анализ",
                    callback_data=f"enhanced_analysis_{analysis_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    text="← Назад к истории",
                    callback_data="my_analyses"
                )
            ]
        ])
        
        try:
            await callback_query.message.edit_text(
                report_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
        except Exception as edit_error:
            logger.warning(f"Could not edit analysis view message: {edit_error}")
            await callback_query.message.reply(
                report_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
        
        await callback_query.answer()
        
    except ValueError as e:
        logger.error(f"ValueError in callback_view_analysis: {e}")
        await callback_query.answer("Некорректный ID анализа", show_alert=True)
    except Exception as e:
        logger.error(f"Ошибка при просмотре анализа: {e}")
        await callback_query.answer("Ошибка при загрузке анализа", show_alert=True)


@router.callback_query(F.data == "back_to_start")
async def callback_back_to_start(callback_query):
    """Возврат к стартовому меню"""
    
    user = callback_query.from_user
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user.id) if user else False
    if user and (is_admin or user.id == 1043893977):
        # Для администраторов добавляем кнопку админки
        keyboard_buttons = [
            [
                InlineKeyboardButton(
                    text="📄 Загрузить квитанцию ЖКХ",
                    callback_data="upload_receipt"
                )
            ],
            [
                InlineKeyboardButton(
                    text="❓ Помощь",
                    callback_data="help"
                ),
                InlineKeyboardButton(
                    text="ℹ️ О боте", 
                    callback_data="about"
                )
            ],
            [
                InlineKeyboardButton(
                    text="📊 Мои анализы",
                    callback_data="my_analyses"
                )
            ],
            [
                InlineKeyboardButton(
                    text="👑 Админка",
                    callback_data="admin"
                )
            ]
        ]
    else:
        # Для обычных пользователей стандартная клавиатура
        keyboard_buttons = [
            [
                InlineKeyboardButton(
                    text="📄 Загрузить квитанцию ЖКХ",
                    callback_data="upload_receipt"
                )
            ],
            [
                InlineKeyboardButton(
                    text="❓ Помощь",
                    callback_data="help"
                ),
                InlineKeyboardButton(
                    text="ℹ️ О боте", 
                    callback_data="about"
                )
            ],
            [
                InlineKeyboardButton(
                    text="📊 Мои анализы",
                    callback_data="my_analyses"
                )
            ]
        ]
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    welcome_text = f"""
🏠 <b>ЖКХ Контроль</b>

Привет, {user.first_name if user and user.first_name else 'пользователь'}! 👋

Я помогу вам проанализировать квитанции ЖКХ и выявить возможные нарушения в тарификации.

<b>Что я умею:</b>
• 📋 Анализировать PDF квитанции ЖКХ
• 🔍 Проверять соответствие тарифов нормативам
• 📊 Создавать подробные отчеты с графиками  
• ⚠️ Выявлять переплаты и ошибки
• 💰 Рассчитывать потенциальную экономию

<b>Для начала работы:</b>
Просто отправьте мне PDF файл с квитанцией ЖКХ, и я проведу полный аудит! 🔎
"""
    
    await callback_query.message.edit_text(
        welcome_text,
        reply_markup=keyboard,
        parse_mode="HTML"
    )
    
    await callback_query.answer()


@router.callback_query(F.data == "admin")
async def callback_admin(callback_query: CallbackQuery):
    """Обработка кнопки админки"""
    
    user = callback_query.from_user
    if not user:
        await callback_query.answer()
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user.id) or user.id == 1043893977
    
    if not is_admin:
        await callback_query.answer("❌ У вас нет прав администратора", show_alert=True)
        return
    
    # Создание клавиатуры с админскими действиями
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="📢 Отправить рассылку",
                callback_data="admin_broadcast"
            )
        ],
        [
            InlineKeyboardButton(
                text="📊 Статистика",
                callback_data="admin_stats"
            )
        ],
        [
            InlineKeyboardButton(
                text="👥 Все пользователи",
                callback_data="admin_all_users"
            )
        ],
        [
            InlineKeyboardButton(
                text="🏠 Главное меню",
                callback_data="back_to_start"
            )
        ]
    ])
    
    admin_text = f"""
👑 <b>Панель администратора</b>

Добро пожаловать в панель управления ботом!

<b>Доступные функции:</b>
• 📢 Отправка сообщений всем пользователям
• 📊 Просмотр статистики использования
• 👥 Просмотр списка всех пользователей

<b>Ваш ID:</b> {user.id}
"""
    
    await callback_query.message.edit_text(
        admin_text,
        reply_markup=keyboard,
        parse_mode="HTML"
    )
    
    await callback_query.answer()


def register_start_handlers(dp):
    """Регистрация обработчиков команды start"""
    dp.include_router(router)