"""
Обработчики для администраторов бота
"""

from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.filters import Command
import logging
import time

from database.connection import is_user_admin, get_all_users, save_broadcast_message, grant_subscription
from services.analysis_service import analysis_service
from bot.rate_limiting_middleware import rate_limiter
from services.cache_service import cache_service

logger = logging.getLogger(__name__)

router = Router()

# ID администратора (пользователь 1043893977)
ADMIN_ID = 1043893977

# Хранилище для текста рассылки
broadcast_storage = {}


@router.message(Command("admin"))
async def cmd_admin(message: Message):
    """Обработка команды /admin"""
    
    user_id = message.from_user.id if message.from_user else 0
    if not user_id:
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        await message.answer("❌ У вас нет прав администратора")
        return
    
    # Создание клавиатуры с админскими действиями
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="📢 Отправить рассылку",
                callback_data="admin_broadcast"
            )
        ],
        [
            InlineKeyboardButton(
                text="📊 Статистика",
                callback_data="admin_stats"
            )
        ],
        [
            InlineKeyboardButton(
                text="👥 Все пользователи",
                callback_data="admin_all_users"
            )
        ],
        [
            InlineKeyboardButton(
                text="🎁 Выдать подписку",
                callback_data="admin_grant_subscription"
            )
        ],
        [
            InlineKeyboardButton(
                text="🏠 Главное меню",
                callback_data="back_to_start"
            )
        ]
    ])
    
    admin_text = f"""
👑 <b>Панель администратора</b>

Добро пожаловать в панель управления ботом!

<b>Доступные функции:</b>
• 📢 Отправка сообщений всем пользователям
• 📊 Просмотр статистики использования
• 👥 Просмотр списка всех пользователей

<b>Ваш ID:</b> {user_id}
"""
    
    await message.answer(
        admin_text,
        reply_markup=keyboard,
        parse_mode="HTML"
    )


@router.callback_query(F.data == "admin_broadcast")
async def callback_admin_broadcast(callback_query: CallbackQuery):
    """Обработка кнопки рассылки"""
    
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        await callback_query.answer()
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        await callback_query.answer("❌ У вас нет прав администратора", show_alert=True)
        return
    
    await callback_query.message.edit_text(
        "📢 <b>Отправка рассылки</b>\n\n"
        "Введите текст сообщения, который будет отправлен всем пользователям бота.\n\n"
        "<i>Поддерживаются HTML-теги: b, i, u, s, a, code, pre</i>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❌ Отмена", callback_data="admin_cancel_broadcast")]
        ])
    )
    
    # Сохраняем состояние ожидания текста рассылки
    broadcast_storage[user_id] = {"state": "waiting_for_text"}
    
    await callback_query.answer()


@router.message(F.text)
async def handle_broadcast_text(message: Message):
    """Обработка текста для рассылки"""
    
    user_id = message.from_user.id if message.from_user else 0
    if not user_id:
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        return
    
    # Проверяем, ожидаем ли мы текст для рассылки
    if user_id in broadcast_storage and broadcast_storage[user_id].get("state") == "waiting_for_text":
        # Сохраняем текст рассылки
        broadcast_storage[user_id]["text"] = message.text
        broadcast_storage[user_id]["state"] = "waiting_for_confirmation"
        
        # Отправляем подтверждение
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Отправить", callback_data="admin_send_broadcast"),
                InlineKeyboardButton(text="✏️ Редактировать", callback_data="admin_edit_broadcast")
            ],
            [
                InlineKeyboardButton(text="❌ Отмена", callback_data="admin_cancel_broadcast")
            ]
        ])
        
        await message.answer(
            f"📢 <b>Подтверждение рассылки</b>\n\n"
            f"<b>Текст сообщения:</b>\n{message.text}\n\n"
            f"Вы уверены, что хотите отправить это сообщение всем пользователям?",
            parse_mode="HTML",
            reply_markup=keyboard
        )


@router.callback_query(F.data == "admin_send_broadcast")
async def callback_admin_send_broadcast(callback_query: CallbackQuery):
    """Отправка рассылки всем пользователям"""
    
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        await callback_query.answer()
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        await callback_query.answer("❌ У вас нет прав администратора", show_alert=True)
        return
    
    # Проверяем, есть ли текст для рассылки
    if user_id not in broadcast_storage or "text" not in broadcast_storage[user_id]:
        await callback_query.answer("❌ Нет текста для рассылки", show_alert=True)
        return
    
    broadcast_text = broadcast_storage[user_id]["text"]
    
    # Получаем всех пользователей
    all_users = await get_all_users()
    
    if not all_users:
        await callback_query.message.edit_text(
            "📢 <b>Рассылка</b>\n\n"
            "❌ Нет пользователей для отправки сообщения",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="⬅️ Назад", callback_data="admin")]
            ])
        )
        return
    
    # Отправляем сообщение всем пользователям
    successful_sends = 0
    failed_sends = 0
    
    for telegram_id in all_users:
        try:
            # Отправляем сообщение каждому пользователю
            await callback_query.bot.send_message(
                chat_id=telegram_id,
                text=f"📢 <b>Сообщение от администратора:</b>\n\n{broadcast_text}",
                parse_mode="HTML"
            )
            successful_sends += 1
        except Exception as e:
            logger.error(f"Ошибка отправки сообщения пользователю {telegram_id}: {e}")
            failed_sends += 1
    
    # Сохраняем информацию о рассылке в базе данных
    await save_broadcast_message(user_id, broadcast_text, len(all_users))
    
    # Очищаем хранилище
    if user_id in broadcast_storage:
        del broadcast_storage[user_id]
    
    # Отправляем отчет об отправке
    report_text = f"""
📢 <b>Рассылка отправлена</b>

<b>Статистика отправки:</b>
• Всего пользователей: {len(all_users)}
• Успешно отправлено: {successful_sends}
• Ошибок: {failed_sends}

<b>Текст сообщения:</b>
{broadcast_text}
"""
    
    await callback_query.message.edit_text(
        report_text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ Назад в админку", callback_data="admin")]
        ])
    )
    
    await callback_query.answer("✅ Рассылка отправлена!")


@router.callback_query(F.data == "admin_edit_broadcast")
async def callback_admin_edit_broadcast(callback_query: CallbackQuery):
    """Редактирование текста рассылки"""
    
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        await callback_query.answer()
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        await callback_query.answer("❌ У вас нет прав администратора", show_alert=True)
        return
    
    # Проверяем, есть ли текст для редактирования
    if user_id in broadcast_storage and "text" in broadcast_storage[user_id]:
        broadcast_storage[user_id]["state"] = "waiting_for_text"
        
        await callback_query.message.edit_text(
            "📢 <b>Отправка рассылки</b>\n\n"
            "Введите новый текст сообщения, который будет отправлен всем пользователям бота.\n\n"
            f"<i>Текущий текст:</i>\n{broadcast_storage[user_id]['text']}",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="❌ Отмена", callback_data="admin_cancel_broadcast")]
            ])
        )
    else:
        await callback_query.message.edit_text(
            "📢 <b>Отправка рассылки</b>\n\n"
            "Введите текст сообщения, который будет отправлен всем пользователям бота.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="❌ Отмена", callback_data="admin_cancel_broadcast")]
            ])
        )
    
    await callback_query.answer()


@router.callback_query(F.data == "admin_cancel_broadcast")
async def callback_admin_cancel_broadcast(callback_query: CallbackQuery):
    """Отмена рассылки"""
    
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        await callback_query.answer()
        return
    
    # Очищаем хранилище
    if user_id in broadcast_storage:
        del broadcast_storage[user_id]
    
    # Возвращаемся в админку
    await callback_admin(callback_query)
    await callback_query.answer("❌ Рассылка отменена")


@router.callback_query(F.data == "admin_stats")
async def callback_admin_stats(callback_query: CallbackQuery):
    """Просмотр статистики"""
    
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        await callback_query.answer()
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        await callback_query.answer("❌ У вас нет прав администратора", show_alert=True)
        return
    
    # Получаем статистику
    all_users = await get_all_users()
    total_users = len(all_users)
    
    # Получаем количество анализов
    db = await analysis_service.get_db()
    async with db as conn:
        cursor = await conn.execute("SELECT COUNT(*) FROM analyses")
        total_analyses = (await cursor.fetchone())[0]
        
        cursor = await conn.execute("SELECT COUNT(*) FROM analyses WHERE status = 'completed'")
        completed_analyses = (await cursor.fetchone())[0]
        
        cursor = await conn.execute("SELECT COUNT(*) FROM analyses WHERE status = 'error'")
        error_analyses = (await cursor.fetchone())[0]
    
    stats_text = f"""
📊 <b>Статистика бота</b>

<b>Пользователи:</b>
• Всего пользователей: {total_users}

<b>Анализы:</b>
• Всего анализов: {total_analyses}
• Успешно завершено: {completed_analyses}
• С ошибками: {error_analyses}
"""
    
    await callback_query.message.edit_text(
        stats_text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="admin")]
        ])
    )
    
    await callback_query.answer()


@router.callback_query(F.data == "admin_all_users")
async def callback_admin_all_users(callback_query: CallbackQuery):
    """Просмотр всех пользователей"""
    
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        await callback_query.answer()
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        await callback_query.answer("❌ У вас нет прав администратора", show_alert=True)
        return
    
    # Получаем всех пользователей
    all_users = await get_all_users()
    
    if not all_users:
        users_text = "👥 <b>Все пользователи</b>\n\nСписок пользователей пуст."
    else:
        users_text = f"👥 <b>Все пользователи</b>\n\nВсего пользователей: {len(all_users)}\n\n"
        
        # Показываем первые 50 пользователей
        for i, telegram_id in enumerate(all_users[:50], 1):
            users_text += f"{i}. {telegram_id}\n"
        
        if len(all_users) > 50:
            users_text += f"\n... и еще {len(all_users) - 50} пользователей"
    
    await callback_query.message.edit_text(
        users_text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="admin")]
        ])
    )
    
    await callback_query.answer()


async def callback_admin(callback_query: CallbackQuery):
    """Возврат в админку"""
    
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        return
    
    # Создание клавиатуры с админскими действиями
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="📢 Отправить рассылку",
                callback_data="admin_broadcast"
            )
        ],
        [
            InlineKeyboardButton(
                text="📊 Статистика",
                callback_data="admin_stats"
            )
        ],
        [
            InlineKeyboardButton(
                text="👥 Все пользователи",
                callback_data="admin_all_users"
            )
        ],
        [
            InlineKeyboardButton(
                text="🎁 Выдать подписку",
                callback_data="admin_grant_subscription"
            )
        ],
        [
            InlineKeyboardButton(
                text="🏠 Главное меню",
                callback_data="back_to_start"
            )
        ]
    ])
    
    admin_text = f"""
👑 <b>Панель администратора</b>

Добро пожаловать в панель управления ботом!

<b>Доступные функции:</b>
• 📢 Отправка сообщений всем пользователям
• 📊 Просмотр статистики использования
• 👥 Просмотр списка всех пользователей

<b>Ваш ID:</b> {user_id}
"""
    
    await callback_query.message.edit_text(
        admin_text,
        reply_markup=keyboard,
        parse_mode="HTML"
    )


@router.callback_query(F.data == "admin_rate_limiting")
async def callback_admin_rate_limiting(callback_query: CallbackQuery):
    """Просмотр статистики Rate Limiting"""
    
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        await callback_query.answer()
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        await callback_query.answer("❌ У вас нет прав администратора", show_alert=True)
        return
    
    # Получаем статистику rate limiting
    stats_text = "🚦 <b>Статистика Rate Limiting</b>\n\n"
    
    # Получаем общую статистику
    total_users = len(rate_limiter.user_requests)
    blocked_users = len(rate_limiter.blocked_users)
    
    stats_text += f"<b>Общая статистика:</b>\n"
    stats_text += f"• 👥 Активных пользователей: {total_users}\n"
    stats_text += f"• 🚫 Заблокированных: {blocked_users}\n\n"
    
    # Показываем лимиты
    stats_text += f"<b>Текущие лимиты:</b>\n"
    for req_type, limit in rate_limiter.limits.items():
        stats_text += f"• {req_type}: {limit} запросов/мин\n"
    
    stats_text += f"\n<b>Время блокировки:</b> {rate_limiter.block_duration // 60} минут\n"
    
    # Показываем топ заблокированных пользователей
    if blocked_users > 0:
        stats_text += f"\n<b>Заблокированные пользователи:</b>\n"
        for user_id, block_time in list(rate_limiter.blocked_users.items())[:5]:
            remaining = int(rate_limiter.block_duration - (time.time() - block_time))
            stats_text += f"• ID {user_id}: {remaining}с до разблокировки\n"
    
    await callback_query.message.edit_text(
        stats_text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ Назад в админку", callback_data="admin")]
        ])
    )
    
    await callback_query.answer()


@router.callback_query(F.data == "admin_cache_stats")
async def callback_admin_cache_stats(callback_query: CallbackQuery):
    """Просмотр статистики кэша"""
    
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        await callback_query.answer()
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        await callback_query.answer("❌ У вас нет прав администратора", show_alert=True)
        return
    
    # Получаем статистику кэша
    cache_stats = cache_service.get_cache_stats()
    
    stats_text = "💾 <b>Статистика кэша анализа</b>\n\n"
    
    stats_text += f"<b>Общая статистика:</b>\n"
    stats_text += f"• 🎯 Попаданий в кэш: {cache_stats['hits']}\n"
    stats_text += f"• ❌ Промахов кэша: {cache_stats['misses']}\n"
    stats_text += f"• 📊 Всего запросов: {cache_stats['total_requests']}\n"
    stats_text += f"• 📈 Эффективность: {cache_stats['hit_rate']}%\n\n"
    
    stats_text += f"<b>Размер кэша:</b>\n"
    stats_text += f"• 💾 В памяти: {cache_stats['memory_cache_size']}/{cache_stats['max_memory_cache_size']}\n"
    stats_text += f"• ⏰ Время жизни: {cache_stats['cache_ttl_hours']} часов\n"
    
    # Показываем экономию
    if cache_stats['hits'] > 0:
        estimated_savings = cache_stats['hits'] * 0.5  # Примерно 0.5$ за анализ
        stats_text += f"\n<b>💰 Примерная экономия:</b> ${estimated_savings:.2f}\n"
    
    await callback_query.message.edit_text(
        stats_text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ Назад в админку", callback_data="admin")]
        ])
    )
    
    await callback_query.answer()


def register_admin_handlers(dp):
    """Регистрация обработчиков администратора"""
    dp.include_router(router)

# Добавить перед последними функциями:

# Хранилище для выдачи подписки
grant_subscription_storage = {}


@router.callback_query(F.data == "admin_grant_subscription")
async def callback_admin_grant_subscription(callback_query: CallbackQuery):
    """Обработка кнопки выдачи подписки"""
    
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        await callback_query.answer()
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        await callback_query.answer("❌ У вас нет прав администратора", show_alert=True)
        return
    
    await callback_query.message.edit_text(
        "🎁 <b>Выдача подписки пользователю</b>\n\n"
        "Введите Telegram ID пользователя, которому хотите выдать бесплатную подписку на месяц.\n\n"
        "<i>Например: 123456789</i>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❌ Отмена", callback_data="admin")]
        ])
    )
    
    # Сохраняем состояние ожидания ID пользователя
    grant_subscription_storage[user_id] = {"state": "waiting_for_user_id"}
    
    await callback_query.answer()


@router.message(F.text.regexp(r'^\d+$'))
async def handle_grant_subscription_user_id(message: Message):
    """Обработка ID пользователя для выдачи подписки"""
    
    user_id = message.from_user.id if message.from_user else 0
    if not user_id:
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        return
    
    # Проверяем, ожидаем ли мы ID пользователя для выдачи подписки
    if user_id in grant_subscription_storage and grant_subscription_storage[user_id].get("state") == "waiting_for_user_id":
        target_user_id = int(message.text)
        
        # Сохраняем ID целевого пользователя
        grant_subscription_storage[user_id]["target_user_id"] = target_user_id
        grant_subscription_storage[user_id]["state"] = "waiting_for_confirmation"
        
        # Отправляем подтверждение
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Подтвердить", callback_data="admin_confirm_grant"),
                InlineKeyboardButton(text="❌ Отмена", callback_data="admin")
            ]
        ])
        
        await message.answer(
            f"🎁 <b>Подтверждение выдачи подписки</b>\n\n"
            f"<b>Пользователь ID:</b> {target_user_id}\n"
            f"<b>Подписка:</b> 1 месяц (бесплатно)\n\n"
            f"Вы уверены, что хотите выдать подписку этому пользователю?",
            parse_mode="HTML",
            reply_markup=keyboard
        )


@router.callback_query(F.data == "admin_confirm_grant")
async def callback_admin_confirm_grant(callback_query: CallbackQuery):
    """Подтверждение выдачи подписки"""
    
    user_id = callback_query.from_user.id if callback_query.from_user else 0
    if not user_id:
        await callback_query.answer()
        return
    
    # Проверяем, является ли пользователь администратором
    is_admin = await is_user_admin(user_id) or user_id == ADMIN_ID
    
    if not is_admin:
        await callback_query.answer("❌ У вас нет прав администратора", show_alert=True)
        return
    
    # Проверяем, есть ли данные для выдачи подписки
    if (user_id not in grant_subscription_storage or 
        "target_user_id" not in grant_subscription_storage[user_id]):
        await callback_query.answer("❌ Нет данных для выдачи подписки", show_alert=True)
        return
    
    target_user_id = grant_subscription_storage[user_id]["target_user_id"]
    
    try:
        # Выдаем подписку
        await grant_subscription(target_user_id, "monthly", 30)
        
        # Очищаем хранилище
        if user_id in grant_subscription_storage:
            del grant_subscription_storage[user_id]
        
        # Уведомляем администратора об успехе
        await callback_query.message.edit_text(
            f"✅ <b>Подписка успешно выдана!</b>\n\n"
            f"<b>Пользователь ID:</b> {target_user_id}\n"
            f"<b>Подписка:</b> 1 месяц\n"
            f"<b>Выдано администратором:</b> {user_id}",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="⬅️ Назад в админку", callback_data="admin")]
            ])
        )
        
        # Уведомляем пользователя о получении подписки
        try:
            await callback_query.bot.send_message(
                chat_id=target_user_id,
                text="🎁 <b>Поздравляем!</b>\n\n"
                     "Вам была выдана бесплатная подписка на 1 месяц администратором бота!\n\n"
                     "Теперь вы можете анализировать квитанции без ограничений.\n\n"
                     "Спасибо за использование ЖКХ Контроль! 🏠",
                parse_mode="HTML"
            )
        except Exception as e:
            logger.warning(f"Не удалось уведомить пользователя {target_user_id}: {e}")
        
    except Exception as e:
        logger.error(f"Ошибка выдачи подписки пользователю {target_user_id}: {e}")
        
        # Очищаем хранилище
        if user_id in grant_subscription_storage:
            del grant_subscription_storage[user_id]
        
        await callback_query.message.edit_text(
            f"❌ <b>Ошибка выдачи подписки</b>\n\n"
            f"Не удалось выдать подписку пользователю {target_user_id}.\n\n"
            f"Ошибка: {str(e)}",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="⬅️ Назад в админку", callback_data="admin")]
            ])
        )
    
    await callback_query.answer()
