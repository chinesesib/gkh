"""
Регистрация обработчиков для Telegram Bot ЖКХ Контроль
"""

from aiogram import Dispatcher
import logging

from handlers.start_handler import register_start_handlers
from handlers.document_handler import register_document_handlers
from handlers.help_handler import register_help_handlers
from handlers.admin_handler import register_admin_handlers
from handlers.auth_handler import router as auth_router
from handlers.cabinet_handler import router as cabinet_router
from handlers.onboarding_handler import router as onboarding_router
from handlers.dispute_wizard_handler import router as dispute_router

logger = logging.getLogger(__name__)


def register_handlers(dp: Dispatcher):
    """Регистрация всех обработчиков"""
    
    logger.info("📋 Регистрация обработчиков...")
    
    # Регистрируем обработчики в определенном порядке
    # Более специфичные обработчики должны быть зарегистрированы первыми
    
    register_start_handlers(dp)
    register_document_handlers(dp)  
    register_help_handlers(dp)
    register_admin_handlers(dp)
    
    # Регистрируем роутер аутентификации
    dp.include_router(auth_router)
    dp.include_router(cabinet_router)
    dp.include_router(onboarding_router)
    dp.include_router(dispute_router)
    
    logger.info("✅ Все обработчики зарегистрированы успешно")