# -*- coding: utf-8 -*-
"""
Сервис прогресс-бара для анализа квитанций ЖКХ
"""

import asyncio
from typing import Dict, Any, Optional, Callable
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class ProgressBarService:
    """Сервис для отображения прогресса анализа"""
    
    def __init__(self):
        self.active_progress = {}  # Активные прогресс-бары
        self.progress_steps = [
            {"id": "file_check", "name": "📄 Проверка файла", "weight": 5},
            {"id": "pdf_extract", "name": "📖 Извлечение текста", "weight": 15},
            {"id": "cache_check", "name": "💾 Проверка кэша", "weight": 5},
            {"id": "ai_analysis", "name": "🧠 AI анализ", "weight": 60},
            {"id": "data_extract", "name": "👤 Извлечение данных", "weight": 10},
            {"id": "save_results", "name": "💾 Сохранение", "weight": 5}
        ]
    
    async def start_progress(
        self, 
        analysis_id: str, 
        user_id: int, 
        file_name: str,
        update_callback: Callable[[str, int, str], None]
    ) -> None:
        """Запускает прогресс-бар для анализа"""
        
        self.active_progress[analysis_id] = {
            "user_id": user_id,
            "file_name": file_name,
            "current_step": 0,
            "total_steps": len(self.progress_steps),
            "progress_percent": 0,
            "started_at": datetime.now(),
            "update_callback": update_callback,
            "last_update": None
        }
        
        # Отправляем начальное сообщение
        await self._send_progress_update(analysis_id, 0, "🚀 Начинаем анализ...")
        
        logger.info(f"📊 Запущен прогресс-бар для анализа {analysis_id}")
    
    async def update_progress(
        self, 
        analysis_id: str, 
        step_id: str, 
        message: Optional[str] = None
    ) -> None:
        """Обновляет прогресс анализа"""
        
        if analysis_id not in self.active_progress:
            return
        
        progress_data = self.active_progress[analysis_id]
        
        # Находим индекс шага
        step_index = next(
            (i for i, step in enumerate(self.progress_steps) if step["id"] == step_id),
            None
        )
        
        if step_index is None:
            logger.warning(f"Unknown step ID: {step_id}")
            return
        
        # Обновляем прогресс
        progress_data["current_step"] = step_index + 1
        
        # Вычисляем процент выполнения
        total_weight = sum(step["weight"] for step in self.progress_steps)
        completed_weight = sum(
            step["weight"] for i, step in enumerate(self.progress_steps) 
            if i < progress_data["current_step"]
        )
        
        progress_percent = int((completed_weight / total_weight) * 100)
        progress_data["progress_percent"] = progress_percent
        
        # Формируем сообщение
        if message is None:
            step_info = self.progress_steps[step_index]
            message = step_info["name"]
        
        # Отправляем обновление
        await self._send_progress_update(analysis_id, progress_percent, message)
        
        logger.info(f"📊 Прогресс {analysis_id}: {progress_percent}% - {message}")
    
    async def complete_progress(
        self, 
        analysis_id: str, 
        success: bool = True,
        message: Optional[str] = None
    ) -> None:
        """Завершает прогресс-бар"""
        
        if analysis_id not in self.active_progress:
            return
        
        progress_data = self.active_progress[analysis_id]
        
        if success:
            final_message = message or "✅ Анализ завершен успешно!"
            await self._send_progress_update(analysis_id, 100, final_message)
        else:
            final_message = message or "❌ Анализ завершен с ошибкой"
            await self._send_progress_update(analysis_id, progress_data["progress_percent"], final_message)
        
        # Удаляем из активных
        del self.active_progress[analysis_id]
        
        logger.info(f"📊 Прогресс-бар завершен для {analysis_id}: {'успешно' if success else 'с ошибкой'}")
    
    async def _send_progress_update(
        self, 
        analysis_id: str, 
        progress_percent: int, 
        message: str
    ) -> None:
        """Отправляет обновление прогресса пользователю"""
        
        if analysis_id not in self.active_progress:
            return
        
        progress_data = self.active_progress[analysis_id]
        
        # Проверяем, нужно ли обновлять (не чаще чем раз в 2 секунды)
        now = datetime.now()
        if (progress_data["last_update"] and 
            (now - progress_data["last_update"]).total_seconds() < 2):
            return
        
        progress_data["last_update"] = now
        
        # Формируем прогресс-бар
        progress_bar = self._create_progress_bar(progress_percent)
        
        # Формируем сообщение
        progress_text = f"""
{progress_bar}

<b>Анализ квитанции:</b> {progress_data["file_name"]}
<b>Прогресс:</b> {progress_percent}%

{message}
"""
        
        try:
            await progress_data["update_callback"](analysis_id, progress_percent, progress_text)
        except Exception as e:
            logger.error(f"Ошибка отправки прогресса: {e}")
    
    def _create_progress_bar(self, progress_percent: int) -> str:
        """Создает визуальный прогресс-бар"""
        
        # Определяем количество блоков
        total_blocks = 10
        filled_blocks = int((progress_percent / 100) * total_blocks)
        empty_blocks = total_blocks - filled_blocks
        
        # Создаем прогресс-бар
        progress_bar = "█" * filled_blocks + "░" * empty_blocks
        
        return f"[{progress_bar}] {progress_percent}%"
    
    def get_active_progress(self) -> Dict[str, Any]:
        """Возвращает информацию об активных прогресс-барах"""
        
        return {
            analysis_id: {
                "user_id": data["user_id"],
                "file_name": data["file_name"],
                "progress_percent": data["progress_percent"],
                "current_step": data["current_step"],
                "total_steps": data["total_steps"],
                "started_at": data["started_at"].isoformat(),
                "duration": (datetime.now() - data["started_at"]).total_seconds()
            }
            for analysis_id, data in self.active_progress.items()
        }
    
    async def cleanup_stale_progress(self) -> None:
        """Очищает устаревшие прогресс-бары"""
        
        now = datetime.now()
        stale_threshold = 300  # 5 минут
        
        stale_analyses = [
            analysis_id for analysis_id, data in self.active_progress.items()
            if (now - data["started_at"]).total_seconds() > stale_threshold
        ]
        
        for analysis_id in stale_analyses:
            await self.complete_progress(analysis_id, False, "⏰ Анализ прерван по таймауту")
            logger.warning(f"Очищен устаревший прогресс-бар: {analysis_id}")


# Глобальный экземпляр сервиса прогресс-бара
progress_service = ProgressBarService()


async def start_progress_cleanup():
    """Запускает периодическую очистку устаревших прогресс-баров"""
    
    while True:
        try:
            await asyncio.sleep(60)  # Каждую минуту
            await progress_service.cleanup_stale_progress()
        except Exception as e:
            logger.error(f"Error in progress cleanup: {e}")

