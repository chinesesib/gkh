"""
Сервис анализа квитанций ЖКХ
Основная логика обработки и анализа коммунальных платежей
"""

import asyncio
import json
from datetime import datetime
from typing import Dict, Any, List, Optional
import logging

from services.pdf_service import pdf_service
from services.claude_service import claude_service
from services.yandex_cloud_service import yandex_service
from services.user_data_extractor import user_data_extractor
from services.cache_service import cache_service
from services.progress_service import progress_service
from database.connection import get_db, update_user_profile_from_receipt
from utils.logger import PerformanceLogger, log_analysis_start, log_analysis_complete

logger = logging.getLogger(__name__)


class AnalysisService:
    """Сервис для комплексного анализа квитанций ЖКХ"""
    
    def __init__(self):
        self.active_analyses = {}  # Отслеживание активных анализов
        self.progress_callbacks = {}  # Callback функции для обновления прогресса
    
    async def get_db(self):
        """Получение соединения с базой данных"""
        return await get_db()
    
    def set_progress_callback(self, analysis_id: str, callback):
        """Устанавливает callback для обновления прогресса"""
        self.progress_callbacks[analysis_id] = callback
    
    async def _update_progress(self, analysis_id: str, step_id: str, message: str = None):
        """Обновляет прогресс анализа"""
        try:
            await progress_service.update_progress(analysis_id, step_id, message)
        except Exception as e:
            logger.warning(f"Ошибка обновления прогресса: {e}")
    
    async def _send_progress_message(self, analysis_id: str, progress_percent: int, message: str):
        """Отправляет сообщение о прогрессе пользователю"""
        try:
            if analysis_id in self.progress_callbacks:
                await self.progress_callbacks[analysis_id](analysis_id, progress_percent, message)
        except Exception as e:
            logger.warning(f"Ошибка отправки прогресса: {e}")
    
    async def analyze_document(
        self, 
        file_path: str, 
        user_id: int, 
        file_name: str,
        file_size: int
    ) -> Dict[str, Any]:
        """Полный анализ документа"""
        
        analysis_id = f"{user_id}_{datetime.now().timestamp()}"
        db_analysis_id = None  # Initialize the variable
        
        logger.info(f"🔍 Начало анализа документа: {file_name} (пользователь: {user_id})")
        log_analysis_start(user_id, file_name, file_size)
        
        # Запускаем прогресс-бар
        await progress_service.start_progress(
            analysis_id, user_id, file_name, 
            self._send_progress_message
        )
        
        # Проверяем кэш перед началом анализа
        try:
            await self._update_progress(analysis_id, "file_check", "📄 Проверка файла...")
            
            with open(file_path, 'rb') as f:
                file_content = f.read()
            
            await self._update_progress(analysis_id, "cache_check", "💾 Проверка кэша...")
            
            cache_key = await cache_service.get_cache_key(file_content, file_name)
            cached_result = await cache_service.get_cached_analysis(cache_key)
            
            if cached_result:
                logger.info(f"⚡ Использован кэшированный результат для {file_name}")
                
                # Сохраняем анализ в БД с пометкой о кэше
                db_analysis_id = await self._create_analysis_record(
                    user_id, file_name, file_size, cached=True
                )
                
                # Обновляем результат с ID анализа
                cached_result['analysis_id'] = db_analysis_id
                cached_result['cached'] = True
                
                await self._update_progress(analysis_id, "save_results", "💾 Сохранение результатов...")
                
                log_analysis_complete(user_id, file_name, 0.1)  # Быстрое завершение
                await progress_service.complete_progress(analysis_id, True, "⚡ Анализ завершен (из кэша)")
                return cached_result
                
        except Exception as e:
            logger.warning(f"Ошибка при проверке кэша: {e}")
        
        # Добавляем в активные анализы
        self.active_analyses[analysis_id] = {
            "user_id": user_id,
            "file_name": file_name,
            "status": "processing",
            "started_at": datetime.now()
        }
        
        start_time = datetime.now()
        
        try:
            # Сохраняем анализ в БД
            db_analysis_id = await self._create_analysis_record(
                user_id, file_name, file_size
            )
            
            with PerformanceLogger("full_document_analysis", user_id):
                # Этап 1: Валидация PDF
                logger.info("📋 Этап 1: Валидация PDF...")
                validation_result = await pdf_service.validate_pdf(file_path)
                
                if not validation_result["is_valid"]:
                    error_msg = f"Невалидный PDF: {', '.join(validation_result['errors'])}"
                    await self._update_analysis_status(db_analysis_id, "error", error_msg)
                    raise ValueError(error_msg)
                
                # Этап 2: Извлечение текста
                logger.info("📄 Этап 2: Извлечение текста...")
                await self._update_progress(analysis_id, "pdf_extract", "📖 Извлечение текста из PDF...")
                
                extracted_text = await pdf_service.extract_text(file_path)
                
                if not extracted_text or len(extracted_text.strip()) < 50:
                    error_msg = "Не удалось извлечь достаточно текста из PDF"
                    await self._update_analysis_status(db_analysis_id, "error", error_msg)
                    raise ValueError(error_msg)
                
                # Этап 2.5: Извлечение данных пользователя (ФИО, адрес)
                logger.info("👤 Этап 2.5: Извлечение данных пользователя...")
                try:
                    await self._update_progress(analysis_id, "data_extract", "👤 Извлечение данных пользователя...")
                    
                    user_data = await user_data_extractor.extract_user_data(extracted_text)
                    if user_data.get('full_name') or user_data.get('address'):
                        await update_user_profile_from_receipt(
                            user_id,
                            user_data.get('full_name'),
                            user_data.get('address')
                        )
                        logger.info(f"📝 Обновлен профиль пользователя: ФИО={bool(user_data.get('full_name'))}, Адрес={bool(user_data.get('address'))}")
                except Exception as e:
                    logger.warning(f"⚠️ Ошибка извлечения данных пользователя: {e}")
                
                # Этап 3: Анализ с помощью AI
                logger.info("🧠 Этап 3: Анализ с помощью ИИ...")
                await self._update_progress(analysis_id, "ai_analysis", "🧠 Анализ с помощью ИИ...")
                
                analysis_result = await claude_service.analyze_utility_bill(
                    extracted_text, user_id
                )
                
                # Этап 4: Сохранение результатов
                logger.info("💾 Этап 4: Сохранение результатов...")
                await self._update_progress(analysis_id, "save_results", "💾 Сохранение результатов...")
                
                await self._save_analysis_results(db_analysis_id, analysis_result)
                
                # Этап 5: Подготовка финального ответа
                duration = (datetime.now() - start_time).total_seconds()
                violations_count = len(analysis_result.get('violations', []))
                
                log_analysis_complete(user_id, file_name, duration, violations_count)
                
                await self._update_analysis_status(
                    db_analysis_id, "completed", "", duration, violations_count
                )
                
                # Добавляем метаданные
                analysis_result['meta'] = {
                    'analysis_id': db_analysis_id,
                    'user_id': user_id,
                    'file_name': file_name,
                    'duration': round(duration, 2),
                    'completed_at': datetime.now().isoformat()
                }
                
                # Кэшируем результат анализа
                try:
                    file_info = {
                        'file_name': file_name,
                        'file_size': file_size,
                        'user_id': user_id,
                        'violations_count': violations_count,
                        'duration': duration
                    }
                    await cache_service.cache_analysis_result(
                        cache_key, analysis_result, file_info
                    )
                except Exception as e:
                    logger.warning(f"Ошибка при кэшировании результата: {e}")
                
                logger.info(f"✅ Анализ завершен успешно: {violations_count} нарушений за {duration:.1f}с")
                
                # Завершаем прогресс-бар
                await progress_service.complete_progress(analysis_id, True, f"✅ Анализ завершен: {violations_count} нарушений")
                
                return analysis_result
                
        except Exception as e:
            duration = (datetime.now() - start_time).total_seconds()
            error_msg = str(e)
            
            logger.error(f"❌ Ошибка анализа: {error_msg}")
            
            # Завершаем прогресс-бар с ошибкой
            await progress_service.complete_progress(analysis_id, False, f"❌ Ошибка: {error_msg}")
            
            # Обновляем статус в БД
            if db_analysis_id is not None:
                await self._update_analysis_status(db_analysis_id, "error", error_msg, duration)
            
            # Возвращаем ошибку в структурированном виде
            return {
                'summary': {
                    'total_amount': 'Н/Д',
                    'violations_found': 0,
                    'total_overpayment': '0',
                    'analysis_error': error_msg
                },
                'services': [],
                'violations': [],
                'financial_analysis': {
                    'monthly_overpayment': '0',
                    'yearly_overpayment': '0'
                },
                'recommendations': [
                    'Проверьте качество PDF файла',
                    'Убедитесь, что текст читаемый',
                    'Попробуйте загрузить файл повторно'
                ],
                'meta': {
                    'analysis_id': db_analysis_id,
                    'user_id': user_id,
                    'file_name': file_name,
                    'duration': round(duration, 2),
                    'error': error_msg
                }
            }
        finally:
            # Убираем из активных анализов
            if analysis_id in self.active_analyses:
                del self.active_analyses[analysis_id]
    
    async def _create_analysis_record(
        self, 
        user_id: int, 
        file_name: str, 
        file_size: int,
        cached: bool = False
    ) -> int:
        """Создание записи анализа в БД"""
        
        db = await get_db()
        async with db as conn:
            # Сначала убедимся, что пользователь существует
            await conn.execute("""
                INSERT OR IGNORE INTO users (telegram_id, last_activity) 
                VALUES (?, ?)
            """, (user_id, datetime.now()))
            
            # Создаем запись анализа
            cursor = await conn.execute("""
                INSERT INTO analyses (
                    user_id, file_name, file_size, status, cached
                ) VALUES (?, ?, ?, ?, ?)
            """, (user_id, file_name, file_size, "processing", cached))
            
            await conn.commit()
            analysis_id = cursor.lastrowid
            if analysis_id is None:
                raise RuntimeError("Failed to create analysis record")
            return analysis_id

    async def _update_analysis_status(
        self,
        analysis_id: int,
        status: str,
        error_message: Optional[str] = None,
        duration: Optional[float] = None,
        violations_count: Optional[int] = None
    ):
        """Обновление статуса анализа"""
        
        db = await get_db()
        async with db as conn:
            await conn.execute("""
                UPDATE analyses SET 
                    status = ?,
                    analysis_completed_at = ?,
                    analysis_duration = ?,
                    violations_count = ?,
                    error_message = ?
                WHERE id = ?
            """, (
                status,
                datetime.now() if status in ['completed', 'error'] else None,
                duration,
                violations_count,
                error_message,
                analysis_id
            ))
            await conn.commit()

    async def _save_analysis_results(self, analysis_id: int, results: Dict[str, Any]):
        """Сохранение результатов анализа в БД"""
        
        db = await get_db()
        async with db as conn:
            # Сохраняем полный результат как JSON
            total_overpayment = 0
            
            # Извлекаем общую переплату
            financial_analysis = results.get('financial_analysis', {})
            if 'monthly_overpayment' in financial_analysis:
                try:
                    overpayment_str = str(financial_analysis['monthly_overpayment']).replace(' ₽', '').replace(',', '.')
                    total_overpayment = float(overpayment_str)
                except (ValueError, TypeError):
                    total_overpayment = 0
            
            await conn.execute("""
                UPDATE analyses SET 
                    result_json = ?,
                    total_overpayment = ?
                WHERE id = ?
            """, (json.dumps(results, ensure_ascii=False), total_overpayment, analysis_id))
            
            # Сохраняем услуги
            services = results.get('services', [])
            for service in services:
                await conn.execute("""
                    INSERT INTO services (
                        analysis_id, service_name, tariff_actual, tariff_standard,
                        consumption, unit, amount_charged, amount_should_be,
                        overpayment, is_violation
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    analysis_id,
                    service.get('name', ''),
                    self._safe_float(service.get('tariff_actual')),
                    self._safe_float(service.get('tariff_standard')),
                    self._safe_float(service.get('consumption')),
                    service.get('unit', ''),
                    self._safe_float(service.get('amount_charged')),
                    self._safe_float(service.get('amount_should_be')),
                    self._safe_float(service.get('overpayment')),
                    service.get('is_violation', False)
                ))
            
            # Сохраняем нарушения
            violations = results.get('violations', [])
            for violation in violations:
                await conn.execute("""
                    INSERT INTO violations (
                        analysis_id, service_name, violation_type,
                        description, financial_impact, recommendation
                    ) VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    analysis_id,
                    violation.get('service', ''),
                    violation.get('type', ''),
                    violation.get('description', ''),
                    self._safe_float(violation.get('financial_impact')),
                    violation.get('recommendation', '')
                ))
            
            await conn.commit()

    async def get_analysis_history(self, user_id: int, limit: int = 10) -> List[Dict[str, Any]]:
        """Получение истории анализов пользователя"""
        
        logger.info(f"🔍 Getting analysis history for user {user_id} with limit {limit}")
        
        db = await get_db()
        async with db as conn:
            cursor = await conn.execute("""
                SELECT 
                    id, file_name, analysis_started_at, analysis_completed_at,
                    status, violations_count, total_overpayment, error_message
                FROM analyses 
                WHERE user_id = ? 
                ORDER BY analysis_started_at DESC 
                LIMIT ?
            """, (user_id, limit))
            
            rows = await cursor.fetchall()
            
            logger.info(f"📄 Found {len(rows)} analyses in history")
            
            history = []
            for row in rows:
                history.append({
                    'id': row[0],
                    'file_name': row[1],
                    'started_at': row[2],
                    'completed_at': row[3],
                    'status': row[4],
                    'violations_count': row[5] or 0,
                    'total_overpayment': row[6] or 0,
                    'error_message': row[7]
                })
            
            return history

    async def get_analysis_details(self, analysis_id: int, user_id: int) -> Optional[Dict[str, Any]]:
        """Получение детальной информации об анализе"""
        
        logger.info(f"🔍 Getting analysis details for ID {analysis_id}, user {user_id}")
        
        db = await get_db()
        async with db as conn:
            cursor = await conn.execute("""
                SELECT result_json FROM analyses 
                WHERE id = ? AND user_id = ?
            """, (analysis_id, user_id))
            
            row = await cursor.fetchone()
            
            logger.info(f"📄 Database query result: {row is not None}")
            
            if row and row[0]:
                try:
                    result = json.loads(row[0])
                    logger.info(f"✅ Successfully parsed analysis details")
                    return result
                except json.JSONDecodeError as e:
                    logger.error(f"❌ JSON decode error: {e}")
                    return None
            
            logger.warning(f"❌ No analysis found for ID {analysis_id} and user {user_id}")
            return None

    def _safe_float(self, value) -> float:
        """Безопасное преобразование в float"""
        
        if value is None:
            return 0.0
        
        try:
            # Убираем валютные символы и пробелы
            if isinstance(value, str):
                value = value.replace(' ₽', '').replace('₽', '').replace(',', '.').strip()
            
            return float(value)
        except (ValueError, TypeError):
            return 0.0

    def get_active_analyses(self) -> Dict[str, Any]:
        """Получение информации об активных анализах"""
        
        return {
            'total_active': len(self.active_analyses),
            'analyses': list(self.active_analyses.values())
        }


# Глобальный экземпляр сервиса
analysis_service = AnalysisService()