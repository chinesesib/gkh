"""
Сервис для работы с Yandex.Cloud API
Обработка PDF документов и получение IAM токенов
"""

import json
import asyncio
import aiohttp
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import logging

from config import settings, YandexCloudEndpoints
from utils.logger import PerformanceLogger, log_error

logger = logging.getLogger(__name__)


class YandexCloudService:
    """Сервис для работы с Yandex.Cloud"""
    
    def __init__(self):
        self.iam_token: Optional[str] = None
        self.token_expires_at: Optional[datetime] = None
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def __aenter__(self):
        """Инициализация асинхронного контекста"""
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Очистка ресурсов"""
        if self.session:
            await self.session.close()
    
    async def get_iam_token(self) -> str:
        """Получение IAM токена"""
        
        # Проверяем, не истек ли токен
        if (self.iam_token and self.token_expires_at and 
            datetime.now() < self.token_expires_at - timedelta(minutes=5)):
            return self.iam_token
        
        logger.info("🔑 Получение нового IAM токена...")
        
        with PerformanceLogger("get_iam_token"):
            try:
                async with self.session.post(
                    YandexCloudEndpoints.IAM_TOKEN_URL,
                    json={"yandexPassportOauthToken": settings.yandex_oauth_token},
                    headers={"Content-Type": "application/json"}
                ) as response:
                    
                    if response.status != 200:
                        error_text = await response.text()
                        raise Exception(f"Ошибка получения IAM токена: {response.status} - {error_text}")
                    
                    data = await response.json()
                    
                    self.iam_token = data["iamToken"]
                    
                    # Токен действителен 12 часов
                    expires_in = data.get("expiresAt", "")
                    if expires_in:
                        # Парсим время истечения из ISO формата
                        self.token_expires_at = datetime.fromisoformat(
                            expires_in.replace('Z', '+00:00')
                        ).replace(tzinfo=None)
                    else:
                        # Если время не указано, считаем что токен действует 12 часов
                        self.token_expires_at = datetime.now() + timedelta(hours=12)
                    
                    logger.info(f"✅ IAM токен получен, действителен до: {self.token_expires_at}")
                    return self.iam_token
                    
            except Exception as e:
                logger.error(f"❌ Ошибка получения IAM токена: {e}")
                raise
    
    async def extract_text_from_pdf(self, pdf_content: bytes) -> str:
        """Извлечение текста из PDF с помощью Yandex.Cloud"""
        
        logger.info("📄 Извлечение текста из PDF через Yandex.Cloud...")
        
        iam_token = await self.get_iam_token()
        
        with PerformanceLogger("extract_text_from_pdf"):
            try:
                # Подготавливаем запрос к Foundation Models API
                url = f"{YandexCloudEndpoints.FOUNDATION_MODELS_URL}completion"
                
                headers = {
                    "Authorization": f"Bearer {iam_token}",
                    "Content-Type": "application/json",
                    "x-folder-id": settings.yandex_folder_id
                }
                
                # Создаем запрос для извлечения текста из PDF
                # Используем base64 кодирование для передачи PDF
                import base64
                pdf_base64 = base64.b64encode(pdf_content).decode('utf-8')
                
                payload = {
                    "modelUri": f"gpt://{settings.yandex_folder_id}/yandexgpt-lite",
                    "completionOptions": {
                        "stream": False,
                        "temperature": 0.1,
                        "maxTokens": 8000
                    },
                    "messages": [
                        {
                            "role": "system",
                            "text": "Ты помощник для извлечения и структурирования текста из PDF квитанций ЖКХ. Извлеки весь читаемый текст из документа, сохраняя структуру и форматирование."
                        },
                        {
                            "role": "user", 
                            "text": f"Извлеки текст из этого PDF документа. PDF в base64: {pdf_base64[:1000]}..."  # Ограничиваем размер для примера
                        }
                    ]
                }
                
                async with self.session.post(url, json=payload, headers=headers) as response:
                    
                    if response.status != 200:
                        error_text = await response.text()
                        raise Exception(f"Ошибка API Yandex.Cloud: {response.status} - {error_text}")
                    
                    data = await response.json()
                    
                    # Извлекаем текст из ответа
                    if "result" in data and "alternatives" in data["result"]:
                        extracted_text = data["result"]["alternatives"][0]["message"]["text"]
                        
                        logger.info(f"✅ Текст извлечен, длина: {len(extracted_text)} символов")
                        return extracted_text
                    else:
                        raise Exception("Неожиданный формат ответа от Yandex.Cloud API")
                        
            except Exception as e:
                logger.error(f"❌ Ошибка извлечения текста: {e}")
                # Возвращаем пустую строку при ошибке, чтобы можно было попробовать другие методы
                return ""
    
    async def analyze_text_structure(self, text: str) -> Dict[str, Any]:
        """Анализ структуры текста квитанции с помощью Yandex.Cloud"""
        
        logger.info("🔍 Анализ структуры текста квитанции...")
        
        iam_token = await self.get_iam_token()
        
        with PerformanceLogger("analyze_text_structure"):
            try:
                url = f"{YandexCloudEndpoints.FOUNDATION_MODELS_URL}completion"
                
                headers = {
                    "Authorization": f"Bearer {iam_token}",
                    "Content-Type": "application/json",
                    "x-folder-id": settings.yandex_folder_id
                }
                
                payload = {
                    "modelUri": f"gpt://{settings.yandex_folder_id}/yandexgpt",
                    "completionOptions": {
                        "stream": False,
                        "temperature": 0.1,
                        "maxTokens": 4000
                    },
                    "messages": [
                        {
                            "role": "system",
                            "text": """Ты эксперт по анализу квитанций ЖКХ. 
                            Проанализируй текст квитанции и извлеки структурированную информацию в JSON формате.
                            
                            Верни результат в следующем формате:
                            {
                                "general_info": {
                                    "period": "период оплаты",
                                    "account_number": "лицевой счет",
                                    "address": "адрес",
                                    "total_amount": "общая сумма"
                                },
                                "services": [
                                    {
                                        "name": "название услуги",
                                        "tariff": "тариф",
                                        "consumption": "объем потребления",
                                        "unit": "единица измерения",
                                        "amount": "сумма к оплате"
                                    }
                                ]
                            }"""
                        },
                        {
                            "role": "user",
                            "text": f"Проанализируй эту квитанцию ЖКХ и извлеки данные:\n\n{text}"
                        }
                    ]
                }
                
                async with self.session.post(url, json=payload, headers=headers) as response:
                    
                    if response.status != 200:
                        error_text = await response.text()
                        raise Exception(f"Ошибка анализа структуры: {response.status} - {error_text}")
                    
                    data = await response.json()
                    
                    if "result" in data and "alternatives" in data["result"]:
                        analysis_text = data["result"]["alternatives"][0]["message"]["text"]
                        
                        # Пытаемся парсить JSON из ответа
                        try:
                            # Ищем JSON в тексте ответа
                            json_start = analysis_text.find('{')
                            json_end = analysis_text.rfind('}') + 1
                            
                            if json_start >= 0 and json_end > json_start:
                                json_str = analysis_text[json_start:json_end]
                                result = json.loads(json_str)
                                
                                logger.info("✅ Структура квитанции проанализирована")
                                return result
                            else:
                                # Если JSON не найден, возвращаем сырой текст
                                logger.warning("⚠️ Не удалось извлечь JSON, возвращаем текст")
                                return {"raw_analysis": analysis_text}
                                
                        except json.JSONDecodeError as e:
                            logger.warning(f"⚠️ Ошибка парсинга JSON: {e}")
                            return {"raw_analysis": analysis_text}
                    else:
                        raise Exception("Неожиданный формат ответа")
                        
            except Exception as e:
                logger.error(f"❌ Ошибка анализа структуры: {e}")
                return {"error": str(e)}
    
    async def health_check(self) -> Dict[str, Any]:
        """Проверка состояния Yandex.Cloud сервисов"""
        
        logger.info("🏥 Проверка состояния Yandex.Cloud...")
        
        try:
            # Пробуем получить IAM токен
            start_time = datetime.now()
            await self.get_iam_token()
            token_time = (datetime.now() - start_time).total_seconds()
            
            # Пробуем простой запрос к API
            start_time = datetime.now()
            headers = {
                "Authorization": f"Bearer {self.iam_token}",
                "Content-Type": "application/json",
                "x-folder-id": settings.yandex_folder_id
            }
            
            test_payload = {
                "modelUri": f"gpt://{settings.yandex_folder_id}/yandexgpt-lite",
                "completionOptions": {
                    "stream": False,
                    "temperature": 0.1,
                    "maxTokens": 10
                },
                "messages": [
                    {
                        "role": "user",
                        "text": "Тест"
                    }
                ]
            }
            
            url = f"{YandexCloudEndpoints.FOUNDATION_MODELS_URL}completion"
            async with self.session.post(url, json=test_payload, headers=headers) as response:
                api_time = (datetime.now() - start_time).total_seconds()
                
                return {
                    "status": "healthy" if response.status == 200 else "degraded",
                    "iam_token_time": round(token_time, 3),
                    "api_response_time": round(api_time, 3),
                    "api_status": response.status,
                    "timestamp": datetime.now().isoformat()
                }
                
        except Exception as e:
            logger.error(f"❌ Проблема с Yandex.Cloud: {e}")
            return {
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }


# Глобальный экземпляр сервиса
yandex_service = YandexCloudService()