"""
Webhook обработчик для YooKassa платежей
Автоматическое уведомление о статусе платежей
"""

import json
import logging
from typing import Dict, Any

from aiogram import Bot
from aiogram.types import Update

from services.payment_service import payment_service
from services.notification_service import NotificationService
from database.connection import get_payment_info

logger = logging.getLogger(__name__)


class WebhookHandler:
    """Обработчик webhook уведомлений от YooKassa"""
    
    def __init__(self, bot: Bot):
        self.bot = bot
        self.notification_service = NotificationService(bot)
    
    async def handle_yookassa_webhook(self, webhook_data: Dict[str, Any]) -> Dict[str, Any]:
        """Обработать webhook от YooKassa"""
        
        try:
            logger.info(f"📨 Получен webhook от YooKassa: {webhook_data.get('event', 'unknown')}")
            
            # Обрабатываем webhook через payment_service
            result = await payment_service.process_webhook(webhook_data)
            
            if result:
                # Если webhook обработан успешно, отправляем уведомления
                await self._send_payment_notifications(webhook_data)
                
                return {
                    "status": "success", 
                    "message": "Webhook обработан успешно"
                }
            else:
                return {
                    "status": "ignored", 
                    "message": "Webhook проигнорирован"
                }
                
        except Exception as e:
            logger.error(f"❌ Ошибка обработки webhook YooKassa: {e}")
            return {
                "status": "error", 
                "message": f"Ошибка обработки: {str(e)}"
            }
    
    async def _send_payment_notifications(self, webhook_data: Dict[str, Any]):
        """Отправить уведомления о платеже пользователю"""
        
        try:
            event_type = webhook_data.get("event")
            payment_object = webhook_data.get("object")
            
            if not payment_object:
                return
            
            # Извлекаем internal_payment_id из metadata
            metadata = payment_object.get("metadata", {})
            internal_payment_id = metadata.get("internal_payment_id")
            
            if not internal_payment_id:
                logger.warning("Webhook без internal_payment_id в metadata")
                return
            
            # Получаем информацию о платеже
            payment_info = await get_payment_info(internal_payment_id)
            if not payment_info:
                logger.warning(f"Платеж {internal_payment_id} не найден в базе данных")
                return
            
            user_id = payment_info["user_id"]
            
            if event_type == "payment.succeeded":
                # Платеж успешен
                from datetime import datetime, timedelta
                expires_date = datetime.now() + timedelta(days=30)
                
                await self.notification_service.send_payment_success_notification(
                    user_id, expires_date
                )
                
                logger.info(f"✅ Отправлено уведомление об успешном платеже пользователю {user_id}")
                
            elif event_type == "payment.canceled":
                # Платеж отменен
                await self.notification_service.send_payment_failed_notification(
                    user_id, "Платеж был отменен"
                )
                
                logger.info(f"❌ Отправлено уведомление об отмене платежа пользователю {user_id}")
                
            elif event_type == "payment.failed":
                # Платеж не прошел
                error_message = payment_object.get("cancellation_details", {}).get("reason", "Платеж не прошел")
                
                await self.notification_service.send_payment_failed_notification(
                    user_id, error_message
                )
                
                logger.info(f"❌ Отправлено уведомление о неуспешном платеже пользователю {user_id}")
                
        except Exception as e:
            logger.error(f"❌ Ошибка отправки уведомлений о платеже: {e}")
    
    async def handle_start_payment_command(self, payment_id: str, user_id: int):
        """Обработать команду /start с параметром платежа"""
        
        try:
            logger.info(f"🔍 Обработка возврата из оплаты: payment_id={payment_id}, user_id={user_id}")
            
            # Проверяем статус платежа
            payment_status = await payment_service.check_payment_status(payment_id)
            
            if payment_status.get('status') == 'succeeded':
                # Платеж успешен
                message_text = """
✅ <b>Платеж успешно завершен!</b>

Спасибо за оплату! Ваша подписка активирована.

Теперь вы можете анализировать квитанции без ограничений! 📄
"""
                
                keyboard_markup = None  # Можно добавить кнопки для перехода к функциям
                
            elif payment_status.get('status') in ['pending', 'waiting_for_capture']:
                # Платеж в обработке
                message_text = """
⏳ <b>Платеж в обработке</b>

Ваш платеж обрабатывается. Это может занять несколько минут.

Мы уведомим вас, как только платеж будет завершен.
"""
                
                keyboard_markup = None
                
            elif payment_status.get('status') in ['canceled', 'failed']:
                # Платеж не прошел
                error_msg = payment_status.get('error', 'Платеж не прошел')
                message_text = f"""
❌ <b>Платеж не прошел</b>

Причина: {error_msg}

Вы можете попробовать оплатить еще раз или обратиться в службу поддержки.
"""
                
                keyboard_markup = None
                
            else:
                # Неизвестный статус
                message_text = """
❓ <b>Статус платежа неизвестен</b>

Проверьте статус платежа позже или обратитесь в службу поддержки.
"""
                
                keyboard_markup = None
            
            # Отправляем сообщение пользователю
            await self.bot.send_message(
                chat_id=user_id,
                text=message_text,
                parse_mode="HTML",
                reply_markup=keyboard_markup
            )
            
            logger.info(f"📨 Отправлено сообщение о статусе платежа пользователю {user_id}")
            
        except Exception as e:
            logger.error(f"❌ Ошибка обработки возврата из оплаты: {e}")
            
            # Отправляем сообщение об ошибке
            try:
                await self.bot.send_message(
                    chat_id=user_id,
                    text="❌ Произошла ошибка при проверке статуса платежа. "
                         "Обратитесь в службу поддержки.",
                    parse_mode="HTML"
                )
            except Exception:
                pass


# Глобальная переменная для webhook обработчика
webhook_handler = None


def init_webhook_handler(bot: Bot) -> WebhookHandler:
    """Инициализировать webhook обработчик"""
    global webhook_handler
    webhook_handler = WebhookHandler(bot)
    return webhook_handler


def get_webhook_handler() -> WebhookHandler:
    """Получить экземпляр webhook обработчика"""
    return webhook_handler