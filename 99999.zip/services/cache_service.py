# -*- coding: utf-8 -*-
"""
Сервис кэширования результатов анализа квитанций ЖКХ
"""

import hashlib
import json
import time
import asyncio
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import logging

from database.connection import get_db

logger = logging.getLogger(__name__)


class AnalysisCacheService:
    """Сервис кэширования результатов анализа"""
    
    def __init__(self):
        self.memory_cache = {}  # Быстрый кэш в памяти
        self.cache_stats = {
            'hits': 0,
            'misses': 0,
            'total_requests': 0,
            'cache_size': 0
        }
        
        # Настройки кэша
        self.memory_cache_size = 100  # Максимум записей в памяти
        self.cache_ttl_hours = 24     # Время жизни кэша в часах
        self.similarity_threshold = 0.85  # Порог схожести для поиска похожих анализов
    
    async def get_cache_key(self, file_content: bytes, file_name: str) -> str:
        """Генерирует ключ кэша на основе содержимого файла"""
        
        # Создаем хэш от содержимого файла
        content_hash = hashlib.md5(file_content).hexdigest()
        
        # Добавляем информацию о файле
        file_info = f"{file_name}_{len(file_content)}"
        
        # Комбинированный ключ
        cache_key = f"{content_hash}_{file_info}"
        
        return cache_key
    
    async def get_cached_analysis(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """Получает кэшированный результат анализа"""
        
        self.cache_stats['total_requests'] += 1
        
        # Проверяем кэш в памяти
        if cache_key in self.memory_cache:
            cached_data = self.memory_cache[cache_key]
            
            # Проверяем время жизни
            if self._is_cache_valid(cached_data):
                self.cache_stats['hits'] += 1
                logger.info(f"🎯 Cache HIT: {cache_key[:16]}...")
                return cached_data['result']
            else:
                # Удаляем устаревший кэш
                del self.memory_cache[cache_key]
        
        # Проверяем кэш в базе данных
        db_cached = await self._get_from_database_cache(cache_key)
        if db_cached and self._is_cache_valid(db_cached):
            # Загружаем в память для быстрого доступа
            self.memory_cache[cache_key] = db_cached
            self.cache_stats['hits'] += 1
            logger.info(f"🎯 Cache HIT (DB): {cache_key[:16]}...")
            return db_cached['result']
        
        self.cache_stats['misses'] += 1
        logger.info(f"❌ Cache MISS: {cache_key[:16]}...")
        return None
    
    async def cache_analysis_result(
        self, 
        cache_key: str, 
        analysis_result: Dict[str, Any],
        file_info: Dict[str, Any]
    ) -> None:
        """Сохраняет результат анализа в кэш"""
        
        cache_data = {
            'result': analysis_result,
            'file_info': file_info,
            'cached_at': datetime.now().isoformat(),
            'cache_key': cache_key
        }
        
        # Сохраняем в память
        self.memory_cache[cache_key] = cache_data
        
        # Ограничиваем размер кэша в памяти
        if len(self.memory_cache) > self.memory_cache_size:
            await self._cleanup_memory_cache()
        
        # Сохраняем в базу данных
        await self._save_to_database_cache(cache_data)
        
        self.cache_stats['cache_size'] = len(self.memory_cache)
        logger.info(f"💾 Cached analysis: {cache_key[:16]}...")
    
    async def find_similar_analyses(
        self, 
        analysis_result: Dict[str, Any], 
        limit: int = 5
    ) -> List[Dict[str, Any]]:
        """Находит похожие анализы в кэше"""
        
        similar_analyses = []
        
        # Получаем ключевые характеристики текущего анализа
        current_features = self._extract_analysis_features(analysis_result)
        
        # Проверяем все кэшированные анализы
        for cache_key, cached_data in self.memory_cache.items():
            if not self._is_cache_valid(cached_data):
                continue
            
            cached_result = cached_data['result']
            cached_features = self._extract_analysis_features(cached_result)
            
            # Вычисляем схожесть
            similarity = self._calculate_similarity(current_features, cached_features)
            
            if similarity >= self.similarity_threshold:
                similar_analyses.append({
                    'cache_key': cache_key,
                    'similarity': similarity,
                    'result': cached_result,
                    'file_info': cached_data['file_info'],
                    'cached_at': cached_data['cached_at']
                })
        
        # Сортируем по схожести
        similar_analyses.sort(key=lambda x: x['similarity'], reverse=True)
        
        return similar_analyses[:limit]
    
    def _is_cache_valid(self, cached_data: Dict[str, Any]) -> bool:
        """Проверяет, действителен ли кэш"""
        
        cached_at = datetime.fromisoformat(cached_data['cached_at'])
        expiry_time = cached_at + timedelta(hours=self.cache_ttl_hours)
        
        return datetime.now() < expiry_time
    
    def _extract_analysis_features(self, analysis_result: Dict[str, Any]) -> Dict[str, Any]:
        """Извлекает ключевые характеристики анализа для сравнения"""
        
        features = {
            'services_count': len(analysis_result.get('services', [])),
            'violations_count': len(analysis_result.get('violations', [])),
            'total_amount': analysis_result.get('summary', {}).get('total_amount', ''),
            'period': analysis_result.get('summary', {}).get('period', ''),
            'services_types': []
        }
        
        # Извлекаем типы услуг
        for service in analysis_result.get('services', []):
            service_name = service.get('name', '').lower()
            if 'вода' in service_name:
                features['services_types'].append('water')
            elif 'отопление' in service_name or 'тепло' in service_name:
                features['services_types'].append('heating')
            elif 'электр' in service_name:
                features['services_types'].append('electricity')
            elif 'содержание' in service_name:
                features['services_types'].append('maintenance')
            elif 'кап' in service_name or 'ремонт' in service_name:
                features['services_types'].append('capital_repair')
        
        features['services_types'] = sorted(features['services_types'])
        
        return features
    
    def _calculate_similarity(self, features1: Dict[str, Any], features2: Dict[str, Any]) -> float:
        """Вычисляет схожесть между двумя анализами"""
        
        similarity_score = 0.0
        total_weight = 0.0
        
        # Сравниваем количество услуг
        if features1['services_count'] == features2['services_count']:
            similarity_score += 0.3
        total_weight += 0.3
        
        # Сравниваем количество нарушений
        if features1['violations_count'] == features2['violations_count']:
            similarity_score += 0.2
        total_weight += 0.2
        
        # Сравниваем типы услуг
        services1 = set(features1['services_types'])
        services2 = set(features2['services_types'])
        
        if services1 == services2:
            similarity_score += 0.4
        elif services1.intersection(services2):
            # Частичное совпадение
            intersection_size = len(services1.intersection(services2))
            union_size = len(services1.union(services2))
            similarity_score += 0.4 * (intersection_size / union_size)
        
        total_weight += 0.4
        
        # Сравниваем период (если указан)
        if features1['period'] and features2['period']:
            if features1['period'] == features2['period']:
                similarity_score += 0.1
            total_weight += 0.1
        
        return similarity_score / total_weight if total_weight > 0 else 0.0
    
    async def _get_from_database_cache(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """Получает кэш из базы данных"""
        
        try:
            db = await get_db()
            async with db as conn:
                cursor = await conn.execute(
                    "SELECT data FROM analysis_cache WHERE cache_key = ?",
                    (cache_key,)
                )
                row = await cursor.fetchone()
                
                if row:
                    return json.loads(row[0])
        except Exception as e:
            logger.error(f"Error getting cache from database: {e}")
        
        return None
    
    async def _save_to_database_cache(self, cache_data: Dict[str, Any]) -> None:
        """Сохраняет кэш в базу данных"""
        
        try:
            db = await get_db()
            async with db as conn:
                await conn.execute(
                    """INSERT OR REPLACE INTO analysis_cache 
                       (cache_key, data, cached_at, file_info) 
                       VALUES (?, ?, ?, ?)""",
                    (
                        cache_data['cache_key'],
                        json.dumps(cache_data),
                        cache_data['cached_at'],
                        json.dumps(cache_data['file_info'])
                    )
                )
                await conn.commit()
        except Exception as e:
            logger.error(f"Error saving cache to database: {e}")
    
    async def _cleanup_memory_cache(self) -> None:
        """Очищает старые записи из кэша в памяти"""
        
        # Удаляем самые старые записи
        sorted_items = sorted(
            self.memory_cache.items(),
            key=lambda x: x[1]['cached_at']
        )
        
        # Удаляем 20% самых старых записей
        items_to_remove = len(sorted_items) // 5
        for cache_key, _ in sorted_items[:items_to_remove]:
            del self.memory_cache[cache_key]
        
        logger.info(f"🧹 Cleaned up {items_to_remove} cache entries")
    
    async def cleanup_expired_cache(self) -> None:
        """Очищает устаревший кэш из базы данных"""
        
        try:
            db = await get_db()
            async with db as conn:
                # Удаляем записи старше TTL
                expiry_time = datetime.now() - timedelta(hours=self.cache_ttl_hours)
                
                cursor = await conn.execute(
                    "DELETE FROM analysis_cache WHERE cached_at < ?",
                    (expiry_time.isoformat(),)
                )
                
                deleted_count = cursor.rowcount
                await conn.commit()
                
                if deleted_count > 0:
                    logger.info(f"🧹 Cleaned up {deleted_count} expired cache entries")
        except Exception as e:
            logger.error(f"Error cleaning up expired cache: {e}")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Возвращает статистику кэша"""
        
        hit_rate = 0.0
        if self.cache_stats['total_requests'] > 0:
            hit_rate = self.cache_stats['hits'] / self.cache_stats['total_requests']
        
        return {
            'hits': self.cache_stats['hits'],
            'misses': self.cache_stats['misses'],
            'total_requests': self.cache_stats['total_requests'],
            'hit_rate': round(hit_rate * 100, 2),
            'memory_cache_size': len(self.memory_cache),
            'max_memory_cache_size': self.memory_cache_size,
            'cache_ttl_hours': self.cache_ttl_hours
        }
    
    async def init_cache_table(self) -> None:
        """Инициализирует таблицу кэша в базе данных"""
        
        try:
            db = await get_db()
            async with db as conn:
                await conn.execute("""
                    CREATE TABLE IF NOT EXISTS analysis_cache (
                        cache_key TEXT PRIMARY KEY,
                        data TEXT NOT NULL,
                        cached_at TEXT NOT NULL,
                        file_info TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Создаем индекс для быстрого поиска по времени
                await conn.execute("""
                    CREATE INDEX IF NOT EXISTS idx_cache_cached_at 
                    ON analysis_cache(cached_at)
                """)
                
                await conn.commit()
                logger.info("✅ Analysis cache table initialized")
        except Exception as e:
            logger.error(f"Error initializing cache table: {e}")


# Глобальный экземпляр сервиса кэширования
cache_service = AnalysisCacheService()


async def start_cache_cleanup():
    """Запускает периодическую очистку кэша"""
    
    while True:
        try:
            await asyncio.sleep(3600)  # Каждый час
            await cache_service.cleanup_expired_cache()
        except Exception as e:
            logger.error(f"Error in cache cleanup: {e}")

