"""
Сервис для создания и заполнения шаблонов документов (жалобы, заявления)
"""

import logging
import json
from typing import Dict, Any, List, Optional
import re
from html import unescape
from pathlib import Path
from datetime import datetime

import aiosqlite
from database.connection import get_db

logger = logging.getLogger(__name__)


class DocumentTemplateService:
    """Сервис для работы с шаблонами документов"""
    
    def __init__(self):
        self.templates_dir = Path("templates")
        self.templates_dir.mkdir(exist_ok=True)
        
        # Инициализируем базовые шаблоны
        self._init_default_templates()
    
    def _init_default_templates(self):
        """Инициализация базовых шаблонов документов"""
        
        # Шаблон жалобы на управляющую компанию
        complaint_template = """
ЖАЛОБА
на неправомерные действия управляющей организации

В {organization_name}
От: {full_name}
Адрес: {address}
Телефон: {phone_number}
Дата: {current_date}

УВАЖАЕМЫЙ(АЯ) {director_title}!

Обращаюсь к Вам с жалобой на неправомерные действия управляющей организации "{management_company}" в отношении начисления платы за коммунальные услуги по адресу: {address}.

На основании проведенного анализа квитанции за {receipt_period} были выявлены следующие нарушения:

{violations_list}

ОБЩАЯ СУММА ПЕРЕПЛАТЫ СОСТАВЛЯЕТ: {total_overpayment} руб.

Данные нарушения противоречат:
- Жилищному кодексу Российской Федерации;
- Правилам предоставления коммунальных услуг собственникам и пользователям помещений в многоквартирных домах и жилых домах, утвержденным Постановлением Правительства РФ от 06.05.2011 № 354;
- Региональным тарифам на коммунальные услуги.

На основании изложенного прошу:

1. Провести проверку правомерности начислений за коммунальные услуги по указанному адресу;
2. Произвести перерасчет платы за коммунальные услуги с исключением выявленных нарушений;
3. Вернуть переплаченную сумму в размере {total_overpayment} руб.;
4. Принять меры по устранению нарушений и недопущению их в дальнейшем.

О результатах рассмотрения жалобы прошу уведомить в письменном виде в течение 30 дней с момента получения данного обращения.

Приложения:
1. Копия квитанции за {receipt_period}
2. Результаты анализа начислений
3. Справочная информация о региональных тарифах

С уважением,
{full_name}
{phone_number}

Дата: {current_date}                    Подпись: _______________
"""

        # Шаблон заявления на перерасчет
        recalculation_template = """
ЗАЯВЛЕНИЕ
о перерасчете платы за коммунальные услуги

Кому: {management_company}
От кого: {full_name}
Адрес: {address}
Телефон: {phone_number}

ЗАЯВЛЕНИЕ

Прошу произвести перерасчет платы за коммунальные услуги за период {receipt_period} по адресу: {address}.

Основание для перерасчета:
На основании проведенного анализа квитанции выявлены следующие нарушения в начислениях:

{violations_list}

Детальная информация о нарушениях:
{detailed_violations}

Сумма к доплате/переплаты: {total_overpayment} руб.

Прошу:
1. Произвести перерасчет платы за коммунальные услуги;
2. При наличии переплаты - зачесть ее в счет будущих платежей или вернуть денежными средствами;
3. При наличии доплаты - предоставить документы, подтверждающие правомерность начислений.

Приложения:
1. Копия квитанции
2. Результаты анализа тарифов
3. Копия паспорта

Дата: {current_date}                    Подпись: _______________

{full_name}
"""

        # Шаблон претензии (упрощенный)
        claim_template = """
ПРЕТЕНЗИЯ

Кому: {management_company}
От: {full_name}
Адрес: {address}
Телефон: {phone_number}
Дата: {current_date}

Предъявляю претензию по начислению платы за коммунальные услуги по адресу: {address} за период {receipt_period}.

Основание претензии:
{violations_list}

Требую:
1. Устранить нарушения и произвести перерасчет.
2. Вернуть переплату в размере {total_overpayment} руб.

В случае неудовлетворения требований в установленный срок, оставляю за собой право обратиться в контролирующие органы и суд.

Подпись: ______________________
{full_name}
"""

        # Шаблон заявления в жилищную инспекцию
        housing_inspection_template = """
ЗАЯВЛЕНИЕ
в государственную жилищную инспекцию

В Государственную жилищную инспекцию
{region_name}

От: {full_name}
Адрес: {address}
Телефон: {phone_number}
Электронная почта: {email}

ЗАЯВЛЕНИЕ
о нарушении жилищного законодательства

Прошу провести проверку деятельности управляющей организации "{management_company}" в связи с нарушением требований жилищного законодательства при начислении платы за коммунальные услуги.

Суть нарушений:
По адресу {address} управляющей организацией производятся неправомерные начисления за коммунальные услуги, что подтверждается результатами анализа квитанции за {receipt_period}:

{violations_list}

Общая сумма неправомерных начислений составляет {total_overpayment} руб.

Указанные действия нарушают:
- статьи 157-159 Жилищного кодекса РФ;
- Правила предоставления коммунальных услуг (Постановление Правительства РФ № 354);
- права потребителей коммунальных услуг.

Прошу:
1. Провести проверку деятельности управляющей организации;
2. Выдать предписание об устранении нарушений;
3. Привлечь виновных лиц к административной ответственности;
4. Обеспечить возврат неправомерно взысканных денежных средств.

Приложения:
1. Копии квитанций
2. Результаты анализа тарифов
3. Копия документов на жилое помещение

Дата: {current_date}                    Подпись: _______________

{full_name}
"""

        self.default_templates = {
            "complaint": {
                "name": "Жалоба на управляющую компанию",
                "content": complaint_template,
                "variables": ["organization_name", "full_name", "address", "phone_number", "current_date", 
                            "director_title", "management_company", "receipt_period", "violations_list", 
                            "total_overpayment"]
            },
            "recalculation": {
                "name": "Заявление на перерасчет",
                "content": recalculation_template,
                "variables": ["management_company", "full_name", "address", "phone_number", "receipt_period",
                            "violations_list", "detailed_violations", "total_overpayment", "current_date"]
            },
            "housing_inspection": {
                "name": "Заявление в жилищную инспекцию",
                "content": housing_inspection_template,
                "variables": ["region_name", "full_name", "address", "phone_number", "email",
                            "management_company", "receipt_period", "violations_list", "total_overpayment", "current_date"]
            },
            "claim": {
                "name": "Претензия",
                "content": claim_template,
                "variables": ["management_company", "full_name", "address", "phone_number", "receipt_period",
                            "violations_list", "total_overpayment", "current_date"]
            }
        }
    
    async def get_template(self, template_type: str) -> Optional[Dict[str, Any]]:
        """Получить шаблон по типу"""
        return self.default_templates.get(template_type)
    
    async def generate_document(self, template_type: str, user_data: Dict[str, Any], 
                              analysis_data: Dict[str, Any]) -> str:
        """Сгенерировать документ на основе шаблона и данных"""
        
        template = await self.get_template(template_type)
        if not template:
            raise ValueError(f"Шаблон {template_type} не найден")
        
        # Подготавливаем данные для заполнения
        fill_data = await self._prepare_fill_data(user_data, analysis_data)
        
        # Заполняем шаблон
        try:
            filled_content = template["content"].format(**fill_data)
            logger.info(f"📄 Сгенерирован документ типа {template_type} для пользователя {user_data.get('telegram_id')}")
            return filled_content
        except KeyError as e:
            logger.error(f"❌ Ошибка заполнения шаблона - отсутствует переменная: {e}")
            raise ValueError(f"Не хватает данных для заполнения: {e}")
    
    async def _prepare_fill_data(self, user_data: Dict[str, Any], analysis_data: Dict[str, Any]) -> Dict[str, Any]:
        """Подготовить данные для заполнения шаблона"""
        
        # Базовые данные пользователя
        fill_data = {
            "full_name": user_data.get("full_name", "Ф.И.О. не указано"),
            "address": user_data.get("address", "Адрес не указан"),
            "phone_number": user_data.get("phone_number", "Телефон не указан"),
            "current_date": datetime.now().strftime("%d.%m.%Y"),
            "email": user_data.get("email", "email@example.com"),
        }
        
        # Данные из анализа
        if analysis_data:
            summary = analysis_data.get("summary", {}) or {}
            financial = analysis_data.get("financial_analysis", {}) or {}

            # Период
            receipt_period = summary.get("period") or analysis_data.get("period") or "период не указан"

            # Адрес: пытаемся взять из summary.address или из поля 'Адрес помещения', иначе из analysis_data/address, иначе из профиля
            address_candidates = [
                summary.get("address"),
                summary.get("Адрес помещения"),
                analysis_data.get("address"),
                user_data.get("address"),
            ]
            address_val = next((v for v in address_candidates if v), "Адрес не указан")

            # Управляющая компания: из summary или analysis_data, иначе дефолт
            mgmt_candidates = [
                summary.get("management_company"),
                analysis_data.get("management_company"),
            ]
            management_company = next((v for v in mgmt_candidates if v), "Управляющая компания")

            # Переплата: пытаемся брать из summary.total_overpayment, затем из financial.monthly_overpayment
            def _to_amount(v):
                if v is None:
                    return 0.0
                if isinstance(v, (int, float)):
                    return float(v)
                try:
                    cleaned = str(v).replace(' ₽', '').replace('₽', '').replace(' ', '').replace(',', '.')
                    return float(cleaned)
                except Exception:
                    return 0.0

            overpayment_val = summary.get("total_overpayment")
            if overpayment_val in (None, "", 0, "0"):
                overpayment_val = financial.get("monthly_overpayment")
            total_overpayment_fmt = f"{_to_amount(overpayment_val):.2f}"

            fill_data.update({
                "receipt_period": receipt_period,
                "management_company": management_company,
                "total_overpayment": total_overpayment_fmt,
            })

            # Обновляем адрес, если из анализа найден корректный
            if address_val and address_val != "Адрес не указан":
                fill_data["address"] = address_val
            
            # Формируем список нарушений
            violations = analysis_data.get("violations", [])
            violations_text = self._format_violations_list(violations)
            fill_data["violations_list"] = violations_text
            
            # Подробная информация о нарушениях
            detailed_violations = self._format_detailed_violations(violations)
            fill_data["detailed_violations"] = detailed_violations
        
        # Дополнительные данные
        fill_data.update({
            "organization_name": "Управление Роспотребнадзора",
            "director_title": "Руководитель",
            # Пытаемся определить регион из адреса
            "region_name": ("г. Москва" if "москва" in str(fill_data.get("address", "")).lower() else "Региональная жилищная инспекция"),
        })
        
        return fill_data
    
    def _format_violations_list(self, violations: List[Dict[str, Any]]) -> str:
        """Форматировать список нарушений для документа"""
        
        if not violations:
            return "Нарушения не обнаружены"
        
        formatted_violations = []
        for i, violation in enumerate(violations, 1):
            service_name = violation.get("service_name", "Неизвестная услуга")
            violation_type = violation.get("violation_type", "Нарушение тарифа")
            financial_impact = violation.get("financial_impact", 0)
            
            violation_text = (
                f"{i}. {service_name}: {violation_type}. "
                f"Сумма нарушения: {financial_impact:.2f} руб."
            )
            formatted_violations.append(violation_text)
        
        return "\n".join(formatted_violations)
    
    def _format_detailed_violations(self, violations: List[Dict[str, Any]]) -> str:
        """Форматировать подробную информацию о нарушениях"""
        
        if not violations:
            return "Подробная информация о нарушениях отсутствует"
        
        detailed_info = []
        for violation in violations:
            service_name = violation.get("service_name", "Неизвестная услуга")
            description = violation.get("description", "Описание отсутствует")
            recommendation = violation.get("recommendation", "Рекомендации отсутствуют")
            
            detail_text = f"""
{service_name}:
Описание нарушения: {description}
Рекомендации: {recommendation}
"""
            detailed_info.append(detail_text)
        
        return "\n".join(detailed_info)
    
    async def save_generated_document(self, user_id: int, analysis_id: int, 
                                    template_type: str, content: str) -> str:
        """Сохранить сгенерированный документ в файл"""
        
        # Создаем директорию для документов пользователя
        user_docs_dir = Path("generated_documents") / str(user_id)
        user_docs_dir.mkdir(parents=True, exist_ok=True)
        
        # Генерируем имя файла
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{template_type}_{timestamp}.txt"
        file_path = user_docs_dir / filename
        
        # Сохраняем файл
        # Удаляем HTML-теги и декодируем сущности, чтобы сохранить чистый текст
        try:
            text_only = re.sub(r"<[^>]+>", "", content or "")
            text_only = unescape(text_only)
        except Exception:
            text_only = content or ""
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(text_only)
        
        # Сохраняем информацию в базе данных (единый путь из config)
        db = await get_db()
        async with db as conn:
            await conn.execute(
                """
                INSERT INTO generated_documents (user_id, analysis_id, template_id, document_type, file_path)
                VALUES (?, ?, ?, ?, ?)
                """,
                (user_id, analysis_id, 1, template_type, str(file_path))
            )
            await conn.commit()
        
        logger.info(f"📄 Документ сохранен: {file_path}")
        return str(file_path)
    
    async def get_user_documents(self, user_id: int) -> List[Dict[str, Any]]:
        """Получить список документов пользователя"""
        
        db = await get_db()
        async with db as conn:
            async def _fetch(conn_ref) -> List[Dict[str, Any]]:
                cursor_local = await conn_ref.execute(
                    """
                    SELECT id, document_type, file_path, created_at
                    FROM generated_documents
                    WHERE user_id = ?
                    ORDER BY created_at DESC
                    """,
                    (user_id,)
                )
                rows_local = await cursor_local.fetchall()
                docs: List[Dict[str, Any]] = []
                for row in rows_local:
                    docs.append({
                        "id": row[0],
                        "document_type": row[1],
                        "file_path": row[2],
                        "created_at": row[3]
                    })
                return docs

            # 1) Пытаемся получить из текущей БД
            documents = await _fetch(conn)
            if documents:
                return documents

            # 2) Фолбэк на старую БД в корне проекта и миграция записей
            try:
                legacy_path = "zhkh_control.db"
                from pathlib import Path as _Path
                if _Path(legacy_path).exists():
                    async with aiosqlite.connect(legacy_path) as legacy_db:
                        # Убедимся, что таблица существует в старой БД
                        cur = await legacy_db.execute(
                            "SELECT name FROM sqlite_master WHERE type='table' AND name='generated_documents'"
                        )
                        if await cur.fetchone():
                            cur_docs = await legacy_db.execute(
                                """
                                SELECT user_id, analysis_id, document_type, file_path, created_at
                                FROM generated_documents
                                WHERE user_id = ?
                                ORDER BY created_at DESC
                                """,
                                (user_id,)
                            )
                            rows_legacy = await cur_docs.fetchall()
                            # Переносим в текущую БД
                            for u_id, analysis_id, doc_type, file_path, created_at in rows_legacy:
                                await conn.execute(
                                    """
                                    INSERT INTO generated_documents (user_id, analysis_id, template_id, document_type, file_path, created_at)
                                    VALUES (?, ?, ?, ?, ?, COALESCE(?, CURRENT_TIMESTAMP))
                                    """,
                                    (u_id, analysis_id, 1, doc_type, file_path, created_at)
                                )
                            await conn.commit()
                            # Повторный запрос уже из текущей БД
                            documents = await _fetch(conn)
                            if documents:
                                return documents
            except Exception as migrate_err:
                logger.warning(f"⚠️ Ошибка миграции документов из legacy БД: {migrate_err}")

            # 3) Фолбэк на файловую систему: каталог generated_documents/<user_id>
            try:
                user_docs_dir = Path("generated_documents") / str(user_id)
                fs_docs: List[Dict[str, Any]] = []
                if user_docs_dir.exists():
                    for p in sorted(user_docs_dir.glob("*"), key=lambda x: x.stat().st_mtime, reverse=True):
                        if p.is_file():
                            created_ts = datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
                            # Определяем тип по имени файла до первого подчеркивания
                            fname = p.name
                            doc_type = fname.split("_", 1)[0] if "_" in fname else "document"
                            fs_docs.append({
                                "id": None,
                                "document_type": doc_type,
                                "file_path": str(p),
                                "created_at": created_ts,
                            })
                    # Пытаемся бэкофисно сохранить в БД, чтобы в дальнейшем брать из БД
                    for d in fs_docs:
                        try:
                            await conn.execute(
                                """
                                INSERT INTO generated_documents (user_id, analysis_id, template_id, document_type, file_path, created_at)
                                VALUES (?, NULL, 1, ?, ?, ?)
                                """,
                                (user_id, d["document_type"], d["file_path"], d["created_at"]) 
                            )
                        except Exception:
                            pass
                    await conn.commit()
                    if fs_docs:
                        # Повторный запрос из БД, чтобы вернуть элементы с ID
                        documents = await _fetch(conn)
                        return documents
            except Exception as fs_err:
                logger.warning(f"⚠️ Ошибка чтения документов из ФС: {fs_err}")

            # Если ничего не нашли
            return []


# Глобальный экземпляр сервиса
document_service = DocumentTemplateService()