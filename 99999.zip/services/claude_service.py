"""
Сервис для работы с Claude Sonnet-4 AI
Анализ текста квитанций ЖКХ и выявление нарушений
"""

import json
import asyncio
from datetime import datetime
from typing import Dict, Any, List, Optional
import logging

from openai import AsyncOpenAI
from config import settings
from utils.logger import PerformanceLogger, log_error

logger = logging.getLogger(__name__)


class ClaudeService:
    """Сервис для работы с Claude Sonnet-4"""
    
    def __init__(self):
        self.client = AsyncOpenAI(
            api_key=settings.claude_api_key,
            base_url=settings.claude_base_url
        )
    
    async def analyze_utility_bill(self, text: str, user_id: int = None) -> Dict[str, Any]:
        """Комплексный анализ квитанции ЖКХ"""
        
        logger.info(f"🧠 Анализ квитанции с помощью Claude Sonnet-4 (пользователь: {user_id})")
        
        with PerformanceLogger("claude_analysis", user_id):
            try:
                # Системный промпт для анализа ЖКХ квитанций
                system_prompt = self._get_system_prompt()
                
                # Пользовательский промпт с текстом квитанции
                user_prompt = self._get_analysis_prompt(text)
                
                response = await self.client.chat.completions.create(
                    model="claude-sonnet-4",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    max_tokens=10000,
                    temperature=0.1
                )
                
                # Извлекаем результат анализа
                analysis_text = response.choices[0].message.content
                
                # Парсим JSON результат
                result = self._parse_analysis_result(analysis_text)
                
                logger.info(f"✅ Анализ завершен: найдено {len(result.get('violations', []))} нарушений")
                
                return result
                
            except Exception as e:
                logger.error(f"❌ Ошибка анализа Claude: {e}")
                if user_id:
                    log_error(user_id, "claude_analysis_error", str(e))
                raise
    
    def _get_system_prompt(self) -> str:
        """Системный промпт для Claude"""
        
        return """
Ты эксперт по анализу квитанций ЖКХ и тарификации коммунальных услуг в России.

Твоя задача - проанализировать текст квитанции ЖКХ и выявить:
1. Нарушения тарификации (завышенные тарифы)
2. Ошибки в начислениях
3. Несоответствия региональным нормативам
4. Потенциальные переплаты

ВАЖНЫЕ ПРИНЦИПЫ АНАЛИЗА:
• Сравнивай тарифы с региональными нормативами 2024 года
• Проверяй правильность расчетов (тариф × объем = сумма)
• Обращай внимание на необоснованные доплаты и комиссии
• Учитывай сезонные изменения тарифов
• Проверяй корректность льгот и субсидий

РЕГИОНАЛЬНЫЕ ТАРИФЫ (примерные значения для справки):
• Холодная вода: 20-35 ₽/м³
• Горячая вода: 120-200 ₽/м³  
• Отопление: 1800-3500 ₽/Гкал
• Электроэнергия: 4-8 ₽/кВт·ч
• Водоотведение: 15-30 ₽/м³
• Содержание жилья: 15-60 ₽/м²

Результат должен быть в строгом JSON формате:
{
    "summary": {
        "total_amount": "общая сумма к оплате",
        "period": "расчетный период",
        "address": "адрес объекта",
        "account": "лицевой счет",
        "services_count": количество услуг,
        "violations_found": количество нарушений,
        "total_overpayment": "сумма переплаты"
    },
    "services": [
        {
            "name": "название услуги",
            "tariff_actual": "фактический тариф",
            "tariff_standard": "нормативный тариф", 
            "consumption": "объем потребления",
            "unit": "единица измерения",
            "amount_charged": "начислено",
            "amount_should_be": "должно быть начислено",
            "overpayment": "переплата",
            "violation_type": "тип нарушения или null",
            "is_violation": true/false
        }
    ],
    "violations": [
        {
            "service": "название услуги",
            "type": "тип нарушения",
            "description": "подробное описание",
            "financial_impact": "финансовое влияние",
            "recommendation": "рекомендации"
        }
    ],
    "financial_analysis": {
        "monthly_overpayment": "переплата за месяц",
        "yearly_overpayment": "переплата за год",
        "largest_violation": "крупнейшее нарушение",
        "savings_potential": "потенциал экономии"
    },
    "recommendations": [
        "конкретные рекомендации по действиям"
    ]
}

ВАЖНО: Отвечай ТОЛЬКО JSON, без дополнительного текста!
"""
    
    def _get_analysis_prompt(self, text: str) -> str:
        """Промпт для анализа конкретной квитанции"""
        
        return f"""
Проанализируй эту квитанцию ЖКХ и выяви все нарушения тарификации:

ТЕКСТ КВИТАНЦИИ:
{text}

Проведи тщательный анализ:
1. Извлеки все услуги с тарифами и суммами
2. Сравни с региональными нормативами
3. Проверь правильность расчетов
4. Выяви переплаты и ошибки
5. Рассчитай финансовое влияние
6. Сформулируй конкретные рекомендации

Будь особенно внимателен к:
• Завышенным тарифам на воду и отопление
• Неправомерным комиссиям и доплатам
• Ошибкам в показаниях счетчиков
• Неучтенным льготам

Результат верни в указанном JSON формате!
"""
    
    def _parse_analysis_result(self, analysis_text: str) -> Dict[str, Any]:
        """Парсинг результата анализа из текста"""
        
        try:
            # Ищем JSON в тексте ответа
            json_start = analysis_text.find('{')
            json_end = analysis_text.rfind('}') + 1
            
            if json_start >= 0 and json_end > json_start:
                json_str = analysis_text[json_start:json_end]
                result = json.loads(json_str)
                
                # Валидируем структуру результата
                self._validate_analysis_result(result)
                
                return result
            else:
                raise ValueError("JSON не найден в ответе")
                
        except json.JSONDecodeError as e:
            logger.warning(f"⚠️ Ошибка парсинга JSON: {e}")
            # Возвращаем базовую структуру с сырым текстом
            return self._create_fallback_result(analysis_text)
        except Exception as e:
            logger.error(f"❌ Ошибка обработки результата: {e}")
            return self._create_fallback_result(analysis_text)
    
    def _validate_analysis_result(self, result: Dict[str, Any]) -> None:
        """Валидация структуры результата анализа"""
        
        required_keys = ['summary', 'services', 'violations', 'financial_analysis', 'recommendations']
        
        for key in required_keys:
            if key not in result:
                logger.warning(f"⚠️ Отсутствует ключ в результате анализа: {key}")
                result[key] = self._get_default_section(key)
    
    def _get_default_section(self, section: str) -> Any:
        """Получение значения по умолчанию для секции"""
        
        defaults = {
            'summary': {
                'total_amount': 'Н/Д',
                'period': 'Н/Д',
                'violations_found': 0,
                'total_overpayment': '0'
            },
            'services': [],
            'violations': [],
            'financial_analysis': {
                'monthly_overpayment': '0',
                'yearly_overpayment': '0',
                'savings_potential': '0'
            },
            'recommendations': ['Требуется дополнительный анализ квитанции']
        }
        
        return defaults.get(section, {})
    
    def _create_fallback_result(self, raw_text: str) -> Dict[str, Any]:
        """Создание резервного результата при ошибке парсинга"""
        
        return {
            'summary': {
                'total_amount': 'Не удалось определить',
                'period': 'Н/Д',
                'violations_found': 0,
                'total_overpayment': '0',
                'analysis_error': 'Ошибка парсинга результата'
            },
            'services': [],
            'violations': [{
                'service': 'Общий анализ',
                'type': 'analysis_error',
                'description': 'Не удалось корректно проанализировать квитанцию',
                'recommendation': 'Попробуйте загрузить квитанцию лучшего качества'
            }],
            'financial_analysis': {
                'monthly_overpayment': '0',
                'yearly_overpayment': '0',
                'savings_potential': '0'
            },
            'recommendations': [
                'Проверьте качество PDF файла',
                'Убедитесь, что текст в квитанции читаемый',
                'При необходимости обратитесь к администратору'
            ],
            'raw_analysis': raw_text[:500] + ('...' if len(raw_text) > 500 else '')
        }
    
    async def get_regional_tariffs(self, region: str = None) -> Dict[str, Any]:
        """Получение актуальных региональных тарифов"""
        
        logger.info(f"📊 Получение региональных тарифов для региона: {region or 'Москва'}")
        
        try:
            prompt = f"""
Предоставь актуальные тарифы ЖКХ на 2024 год для региона: {region or 'Москва'}.

Верни в JSON формате:
{{
    "region": "название региона",
    "year": 2024,
    "tariffs": {{
        "cold_water": {{"min": минимум, "max": максимум, "average": среднее}},
        "hot_water": {{"min": минимум, "max": максимум, "average": среднее}}, 
        "heating": {{"min": минимум, "max": максимум, "average": среднее}},
        "electricity": {{"min": минимум, "max": максимум, "average": среднее}},
        "sewerage": {{"min": минимум, "max": максимум, "average": среднее}},
        "maintenance": {{"min": минимум, "max": максимум, "average": среднее}}
    }},
    "updated": "дата обновления"
}}

Используй только официальные данные регулирующих органов.
"""
            
            response = await self.client.chat.completions.create(
                model="claude-sonnet-4",
                messages=[
                    {"role": "user", "content": prompt}
                ],
                max_tokens=2000,
                temperature=0.1
            )
            
            result_text = response.choices[0].message.content
            
            # Парсим JSON
            json_start = result_text.find('{')
            json_end = result_text.rfind('}') + 1
            
            if json_start >= 0 and json_end > json_start:
                return json.loads(result_text[json_start:json_end])
            else:
                raise ValueError("Не удалось извлечь тарифы")
                
        except Exception as e:
            logger.error(f"❌ Ошибка получения тарифов: {e}")
            return self._get_default_tariffs(region)
    
    def _get_default_tariffs(self, region: str = None) -> Dict[str, Any]:
        """Тарифы по умолчанию (средние по России)"""
        
        return {
            "region": region or "Средние по России",
            "year": 2024,
            "tariffs": {
                "cold_water": {"min": 20, "max": 35, "average": 27.5},
                "hot_water": {"min": 120, "max": 200, "average": 160},
                "heating": {"min": 1800, "max": 3500, "average": 2650},
                "electricity": {"min": 4, "max": 8, "average": 6},
                "sewerage": {"min": 15, "max": 30, "average": 22.5},
                "maintenance": {"min": 15, "max": 60, "average": 37.5}
            },
            "updated": datetime.now().strftime("%Y-%m-%d"),
            "note": "Примерные значения, требуют уточнения для конкретного региона"
        }
    
    async def health_check(self) -> Dict[str, Any]:
        """Проверка работоспособности Claude API"""
        
        try:
            start_time = datetime.now()
            
            response = await self.client.chat.completions.create(
                model="claude-sonnet-4",
                messages=[
                    {"role": "user", "content": "Тест соединения. Ответь 'OK'"}
                ],
                max_tokens=10,
                temperature=0.1
            )
            
            response_time = (datetime.now() - start_time).total_seconds()
            
            return {
                "status": "healthy",
                "response_time": round(response_time, 3),
                "model": "claude-sonnet-4",
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ Проблема с Claude API: {e}")
            return {
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }


# Глобальный экземпляр сервиса
claude_service = ClaudeService()