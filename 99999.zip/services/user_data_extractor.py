"""
Сервис для извлечения данных пользователя из квитанций ЖКХ
Автоматическое извлечение ФИО и адреса для автозаполнения документов
"""

import re
import logging
from typing import Dict, Any, Optional, Tuple

logger = logging.getLogger(__name__)


class UserDataExtractor:
    """Сервис для извлечения персональных данных из квитанций"""
    
    def __init__(self):
        # Паттерны для поиска ФИО
        self.name_patterns = [
            r'(?:Ф\.?И\.?О\.?|ФИО|Собственник|Плательщик)\s*:?\s*([А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+(?:\s+[А-ЯЁ][а-яё]+)?)',
            r'(?:гражданин|гр\.)\s+([А-ЯЁ][а-яё]+\s+[А-ЯЁ]\.[А-ЯЁ]\.)',  # Иванов И.И.
            r'([А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+)(?:\s+(?:г\.р\.|год рождения))',  # ФИО + год рождения
            r'(?:Лицевой счет|л/с|ЛС).*?([А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+(?:\s+[А-ЯЁ][а-яё]+)?)',
        ]
        
        # Паттерны для поиска адреса
        self.address_patterns = [
            r'(?:Адрес|адрес)\s*:?\s*([^,\n]+(?:ул\.|улица|пр\.|проспект|пер\.|переулок|д\.|дом|кв\.|квартира)[^,\n]*)',
            r'(г\.\s*[А-ЯЁ][а-яё]+[^,\n]*(?:ул\.|улица|пр\.|проспект)[^,\n]*д\.[^,\n]*)',  # г. Город, ул. Улица, д. X
            r'([А-ЯЁ][а-яё]+\s+(?:обл\.|область)[^,\n]*(?:ул\.|улица|пр\.|проспект)[^,\n]*)',  # Область + улица
            r'(\d{6}[^,\n]*(?:ул\.|улица|пр\.|проспект)[^,\n]*д\.[^,\n]*)',  # Индекс + адрес
            r'(?:Место жительства|проживания)\s*:?\s*([^,\n]+)',
        ]
        
        # Паттерны для очистки адреса
        self.address_cleanup_patterns = [
            r'кв\.\s*\d+.*$',  # Убираем номер квартиры из конца
            r'^\s*-\s*',       # Убираем тире в начале
            r'\s+', ' ',       # Заменяем множественные пробелы
        ]

    async def extract_user_data(self, text: str) -> Dict[str, Optional[str]]:
        """Извлечь ФИО и адрес из текста квитанции"""
        
        logger.info("🔍 Извлечение данных пользователя из квитанции")
        
        # Извлекаем ФИО
        full_name = await self._extract_full_name(text)
        
        # Извлекаем адрес
        address = await self._extract_address(text)
        
        result = {
            'full_name': full_name,
            'address': address
        }
        
        logger.info(f"📋 Извлечены данные: ФИО={bool(full_name)}, Адрес={bool(address)}")
        
        return result

    async def _extract_full_name(self, text: str) -> Optional[str]:
        """Извлечь ФИО из текста"""
        
        # Нормализуем текст
        text = re.sub(r'\s+', ' ', text.strip())
        
        for pattern in self.name_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE | re.MULTILINE)
            
            for match in matches:
                potential_name = match.group(1).strip()
                
                # Валидируем найденное ФИО
                if await self._validate_full_name(potential_name):
                    logger.info(f"✅ Найдено ФИО: {potential_name}")
                    return potential_name
        
        logger.warning("⚠️ ФИО не найдено в квитанции")
        return None

    async def _extract_address(self, text: str) -> Optional[str]:
        """Извлечь адрес из текста"""
        
        # Нормализуем текст
        text = re.sub(r'\s+', ' ', text.strip())
        
        for pattern in self.address_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE | re.MULTILINE)
            
            for match in matches:
                potential_address = match.group(1).strip()
                
                # Очищаем и валидируем адрес
                cleaned_address = await self._clean_address(potential_address)
                
                if await self._validate_address(cleaned_address):
                    logger.info(f"✅ Найден адрес: {cleaned_address}")
                    return cleaned_address
        
        logger.warning("⚠️ Адрес не найден в квитанции")
        return None

    async def _validate_full_name(self, name: str) -> bool:
        """Валидация ФИО"""
        
        if not name or len(name) < 5:
            return False
        
        # Проверяем, что есть хотя бы 2 слова
        words = name.split()
        if len(words) < 2:
            return False
        
        # Проверяем, что все слова начинаются с заглавной буквы
        for word in words:
            if not word[0].isupper() or not word.isalpha():
                return False
        
        # Проверяем длину слов (обычно имена не короче 2 символов)
        for word in words:
            if len(word) < 2:
                return False
        
        # Исключаем очевидно неподходящие значения
        excluded_patterns = [
            r'МОСКВА|САНКТ|ПЕТЕРБУРГ|ЕКАТЕРИНБУРГ',  # Названия городов
            r'АДМИНИСТРАЦИЯ|УПРАВЛЕНИЕ|ОРГАНИЗАЦИЯ',   # Организации
            r'ОБЩЕСТВО|ТОВАРИЩЕСТВО|КОМПАНИЯ',        # Юридические лица
        ]
        
        for pattern in excluded_patterns:
            if re.search(pattern, name.upper()):
                return False
        
        return True

    async def _validate_address(self, address: str) -> bool:
        """Валидация адреса"""
        
        if not address or len(address) < 10:
            return False
        
        # Должны присутствовать ключевые элементы адреса
        address_keywords = [
            r'ул\.|улица|пр\.|проспект|пер\.|переулок|бул\.|бульвар',
            r'д\.|дом|стр\.|строение',
        ]
        
        has_street = any(re.search(pattern, address, re.IGNORECASE) for pattern in address_keywords[:1])
        has_building = any(re.search(pattern, address, re.IGNORECASE) for pattern in address_keywords[1:])
        
        if not (has_street or has_building):
            return False
        
        # Исключаем нежелательные значения
        excluded_patterns = [
            r'СБЕРБАНК|АЛЬФА|ТИНЬКОФФ',  # Банки
            r'ПОЧТА|ТЕЛЕФОН|EMAIL',       # Контактная информация
            r'HTTP|WWW\.',                # Веб-адреса
        ]
        
        for pattern in excluded_patterns:
            if re.search(pattern, address.upper()):
                return False
        
        return True

    async def _clean_address(self, address: str) -> str:
        """Очистка адреса от лишних данных"""
        
        # Применяем паттерны очистки
        for pattern, replacement in [(self.address_cleanup_patterns[0], ''), 
                                   (self.address_cleanup_patterns[1], ''),
                                   (self.address_cleanup_patterns[2], ' ')]:
            address = re.sub(pattern, replacement, address)
        
        # Убираем лишние символы в конце
        address = address.rstrip('.,;: ')
        
        # Убираем номер квартиры для шаблонов (оставляем только до дома)
        address = re.sub(r',?\s*кв\.?\s*\d+.*$', '', address, flags=re.IGNORECASE)
        
        return address.strip()


# Глобальный экземпляр сервиса
user_data_extractor = UserDataExtractor()