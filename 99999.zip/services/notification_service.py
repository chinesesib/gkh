"""
Сервис для отправки уведомлений пользователям
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Any

from aiogram import Bot
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from config import settings
from database.connection import (
    get_users_with_expiring_subscriptions, 
    update_notification_sent,
    get_user_subscription_info
)

logger = logging.getLogger(__name__)


class NotificationService:
    """Сервис для отправки уведомлений"""
    
    def __init__(self, bot: Bot):
        self.bot = bot
    
    async def send_subscription_expiry_reminders(self):
        """Отправить напоминания о истечении подписки"""
        
        try:
            # Получаем пользователей с истекающими подписками
            expiring_users = await get_users_with_expiring_subscriptions()
            
            if not expiring_users:
                logger.info("📊 Нет пользователей с истекающими подписками")
                return
            
            sent_count = 0
            
            for user_data in expiring_users:
                telegram_id = user_data[0]
                expires_at = user_data[1]
                
                try:
                    # Вычисляем дни до истечения
                    expires_date = datetime.fromisoformat(expires_at.replace('Z', '+00:00'))
                    days_left = (expires_date - datetime.now()).days
                    
                    # Отправляем уведомление
                    await self._send_expiry_notification(telegram_id, days_left, expires_date)
                    
                    # Отмечаем, что уведомление отправлено
                    await update_notification_sent(telegram_id)
                    
                    sent_count += 1
                    
                    # Небольшая задержка между отправками
                    await asyncio.sleep(0.5)
                    
                except Exception as e:
                    logger.error(f"❌ Ошибка отправки уведомления пользователю {telegram_id}: {e}")
            
            logger.info(f"📨 Отправлено {sent_count} уведомлений о истечении подписки")
            
        except Exception as e:
            logger.error(f"❌ Ошибка отправки напоминаний: {e}")
    
    async def _send_expiry_notification(self, telegram_id: int, days_left: int, expires_date: datetime):
        """Отправить уведомление о истечении подписки"""
        
        if days_left <= 0:
            # Подписка уже истекла
            message_text = """
⚠️ <b>Ваша подписка истекла</b>

Ваша месячная подписка на ЖКХ Контроль истекла {expires_date}.

Чтобы продолжить анализировать квитанции без ограничений, продлите подписку.

💰 <b>Стоимость:</b> {price} руб/месяц
🎯 <b>Преимущества:</b>
• Безлимитный анализ квитанций
• Генерация жалоб и заявлений
• Приоритетная поддержка
""".format(
                expires_date=expires_date.strftime("%d.%m.%Y"),
                price=int(settings.subscription_price)
            )
        elif days_left <= 7:
            # Подписка истекает в течение недели
            message_text = """
⏰ <b>Ваша подписка истекает через {days_left} дн.</b>

Ваша месячная подписка на ЖКХ Контроль истекает {expires_date}.

Не забудьте продлить подписку, чтобы продолжить пользоваться всеми возможностями бота!

💰 <b>Стоимость продления:</b> {price} руб/месяц
🎯 <b>Преимущества:</b>
• Безлимитный анализ квитанций
• Автоматическая генерация документов
• Техническая поддержка
""".format(
                days_left=days_left,
                expires_date=expires_date.strftime("%d.%m.%Y"),
                price=int(settings.subscription_price)
            )
        else:
            return  # Слишком рано для напоминания
        
        # Создаем кнопку продления
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💳 Продлить подписку",
                    callback_data="extend_subscription"
                )
            ],
            [
                InlineKeyboardButton(
                    text="ℹ️ Подробнее о подписке",
                    callback_data="subscription_info"
                )
            ]
        ])
        
        try:
            await self.bot.send_message(
                chat_id=telegram_id,
                text=message_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
            
            logger.info(f"📨 Отправлено напоминание пользователю {telegram_id} (дней осталось: {days_left})")
            
        except Exception as e:
            logger.error(f"❌ Не удалось отправить уведомление пользователю {telegram_id}: {e}")
    
    async def send_payment_success_notification(self, telegram_id: int, expires_date: datetime):
        """Отправить уведомление об успешной оплате"""
        
        message_text = f"""
✅ <b>Подписка успешно оплачена!</b>

Спасибо за оплату! Ваша подписка на ЖКХ Контроль активна до {expires_date.strftime("%d.%m.%Y")}.

🎯 <b>Теперь вам доступно:</b>
• Безлимитный анализ квитанций ЖКХ
• Автоматическая генерация жалоб и заявлений
• Подробные отчеты с графиками
• Расчет переплат и рекомендации
• Приоритетная техническая поддержка

Можете загружать квитанции без ограничений! 📄
"""
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📄 Загрузить квитанцию",
                    callback_data="upload_receipt"
                )
            ],
            [
                InlineKeyboardButton(
                    text="📊 Мои анализы",
                    callback_data="my_analyses"
                )
            ]
        ])
        
        try:
            await self.bot.send_message(
                chat_id=telegram_id,
                text=message_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
            
            logger.info(f"✅ Отправлено уведомление об успешной оплате пользователю {telegram_id}")
            
        except Exception as e:
            logger.error(f"❌ Не удалось отправить уведомление об оплате пользователю {telegram_id}: {e}")
    
    async def send_payment_failed_notification(self, telegram_id: int, error_message: str = None):
        """Отправить уведомление о неуспешном платеже"""
        
        reason_text = ""
        if error_message:
            reason_text = f"\n\n<b>Причина:</b> {error_message}"
        
        message_text = f"""
❌ <b>Платеж не прошел</b>

К сожалению, ваш платеж за подписку не был завершен.{reason_text}

Возможные причины:
• Недостаточно средств на карте
• Платеж был отменен
• Технические проблемы банка
• Истек срок ожидания платежа

Вы можете попробовать оплатить еще раз.
"""
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💳 Попробовать снова",
                    callback_data="create_payment"
                )
            ],
            [
                InlineKeyboardButton(
                    text="❓ Связаться с поддержкой",
                    callback_data="contact_support"
                )
            ]
        ])
        
        try:
            await self.bot.send_message(
                chat_id=telegram_id,
                text=message_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
            
            logger.info(f"❌ Отправлено уведомление о неуспешном платеже пользователю {telegram_id}")
            
        except Exception as e:
            logger.error(f"❌ Не удалось отправить уведомление о неуспешном платеже пользователю {telegram_id}: {e}")
    
    async def send_subscription_granted_notification(self, telegram_id: int, expires_date: datetime, granted_by_admin: bool = False):
        """Отправить уведомление о выданной подписке"""
        
        if granted_by_admin:
            message_text = f"""
🎁 <b>Вам предоставлена бесплатная подписка!</b>

Администратор выдал вам бесплатную подписку на ЖКХ Контроль.

📅 <b>Действует до:</b> {expires_date.strftime("%d.%m.%Y")}

🎯 <b>Доступные возможности:</b>
• Безлимитный анализ квитанций ЖКХ
• Генерация жалоб и заявлений
• Подробные отчеты с рекомендациями
• Техническая поддержка
"""
        else:
            message_text = f"""
✅ <b>Подписка активирована!</b>

Ваша подписка на ЖКХ Контроль активна до {expires_date.strftime("%d.%m.%Y")}.

🎯 <b>Теперь вам доступно:</b>
• Безлимитный анализ квитанций
• Автоматическая генерация документов
• Расширенная аналитика
• Приоритетная поддержка
"""
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📄 Загрузить квитанцию",
                    callback_data="upload_receipt"
                )
            ]
        ])
        
        try:
            await self.bot.send_message(
                chat_id=telegram_id,
                text=message_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
            
        except Exception as e:
            logger.error(f"❌ Не удалось отправить уведомление о подписке пользователю {telegram_id}: {e}")


# Функция для запуска планировщика уведомлений
async def start_notification_scheduler(bot: Bot):
    """Запустить планировщик уведомлений"""
    
    notification_service = NotificationService(bot)
    
    async def notification_loop():
        while True:
            try:
                # Отправляем напоминания каждые 24 часа
                await notification_service.send_subscription_expiry_reminders()
                
                # Ждем 24 часа
                await asyncio.sleep(24 * 60 * 60)  # 24 часа
                
            except Exception as e:
                logger.error(f"❌ Ошибка в планировщике уведомлений: {e}")
                # Ждем час перед повторной попыткой
                await asyncio.sleep(60 * 60)
    
    # Запускаем в фоне
    asyncio.create_task(notification_loop())
    logger.info("📨 Планировщик уведомлений запущен")