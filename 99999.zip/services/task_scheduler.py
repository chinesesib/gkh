"""
Планировщик задач для ЖКХ Контроль бота
Отправка периодических уведомлений о подписке
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional

from aiogram import Bot
from services.notification_service import NotificationService
from utils.logger import setup_logging

logger = logging.getLogger(__name__)


class TaskScheduler:
    """Планировщик периодических задач"""
    
    def __init__(self, bot: Bot):
        self.bot = bot
        self.notification_service = NotificationService(bot)
        self.is_running = False
        self.tasks = {}
    
    async def start(self):
        """Запуск планировщика"""
        
        if self.is_running:
            logger.warning("⚠️ Планировщик уже запущен")
            return
        
        self.is_running = True
        logger.info("🕒 Запуск планировщика задач")
        
        # Запускаем основной цикл планировщика
        asyncio.create_task(self._scheduler_loop())
        
        # Запускаем задачу уведомлений о подписке
        asyncio.create_task(self._subscription_notifications_task())
    
    async def stop(self):
        """Остановка планировщика"""
        
        self.is_running = False
        logger.info("🛑 Остановка планировщика задач")
        
        # Отменяем все активные задачи
        for task_name, task in self.tasks.items():
            if not task.done():
                task.cancel()
                logger.info(f"❌ Отменена задача: {task_name}")
    
    async def _scheduler_loop(self):
        """Основной цикл планировщика"""
        
        logger.info("🔄 Основной цикл планировщика запущен")
        
        while self.is_running:
            try:
                # Проверяем каждую минуту
                await asyncio.sleep(60)
                
                current_time = datetime.now()
                
                # Логируем активность каждые 10 минут
                if current_time.minute % 10 == 0:
                    logger.debug(f"⏰ Планировщик активен: {current_time.strftime('%H:%M')}")
                
            except asyncio.CancelledError:
                logger.info("🛑 Основной цикл планировщика остановлен")
                break
            except Exception as e:
                logger.error(f"❌ Ошибка в основном цикле планировщика: {e}")
                await asyncio.sleep(300)  # Ждем 5 минут при ошибке
    
    async def _subscription_notifications_task(self):
        """Задача отправки уведомлений о подписке"""
        
        logger.info("📨 Запуск задачи уведомлений о подписке")
        
        while self.is_running:
            try:
                current_time = datetime.now()
                
                # Отправляем уведомления каждую неделю в воскресенье в 10:00
                if (current_time.weekday() == 6 and  # Воскресенье
                    current_time.hour == 10 and
                    current_time.minute == 0):
                    
                    logger.info("📅 Время еженедельных уведомлений о подписке")
                    await self.notification_service.send_subscription_expiry_reminders()
                
                # Также отправляем уведомления ежедневно в 10:00 для истекающих подписок
                elif (current_time.hour == 10 and current_time.minute == 0):
                    logger.info("📅 Ежедневная проверка истекающих подписок")
                    await self.notification_service.send_subscription_expiry_reminders()
                
                # Ждем минуту до следующей проверки
                await asyncio.sleep(60)
                
            except asyncio.CancelledError:
                logger.info("🛑 Задача уведомлений о подписке остановлена")
                break
            except Exception as e:
                logger.error(f"❌ Ошибка в задаче уведомлений о подписке: {e}")
                await asyncio.sleep(300)  # Ждем 5 минут при ошибке
    
    async def schedule_one_time_task(self, task_name: str, delay_seconds: int, coro):
        """Запланировать одноразовую задачу"""
        
        async def delayed_task():
            try:
                await asyncio.sleep(delay_seconds)
                await coro
                logger.info(f"✅ Выполнена одноразовая задача: {task_name}")
            except asyncio.CancelledError:
                logger.info(f"❌ Отменена одноразовая задача: {task_name}")
            except Exception as e:
                logger.error(f"❌ Ошибка в одноразовой задаче {task_name}: {e}")
            finally:
                if task_name in self.tasks:
                    del self.tasks[task_name]
        
        task = asyncio.create_task(delayed_task())
        self.tasks[task_name] = task
        
        logger.info(f"⏰ Запланирована задача '{task_name}' через {delay_seconds} секунд")
        
        return task
    
    async def schedule_payment_check(self, payment_id: str, delay_minutes: int = 30):
        """Запланировать проверку статуса платежа"""
        
        async def check_payment():
            try:
                from services.payment_service import payment_service
                
                logger.info(f"🔍 Проверка статуса платежа: {payment_id}")
                payment_status = await payment_service.check_payment_status(payment_id)
                
                if payment_status.get('status') == 'succeeded':
                    logger.info(f"✅ Платеж {payment_id} успешно завершен (отложенная проверка)")
                elif payment_status.get('status') in ['pending', 'waiting_for_capture']:
                    # Планируем еще одну проверку через час
                    await self.schedule_payment_check(payment_id, 60)
                    logger.info(f"⏳ Платеж {payment_id} все еще в обработке, запланирована повторная проверка")
                else:
                    logger.warning(f"❌ Платеж {payment_id} не прошел: {payment_status.get('status')}")
                    
            except Exception as e:
                logger.error(f"❌ Ошибка проверки платежа {payment_id}: {e}")
        
        task_name = f"payment_check_{payment_id}"
        await self.schedule_one_time_task(task_name, delay_minutes * 60, check_payment())
    
    def get_status(self) -> dict:
        """Получить статус планировщика"""
        
        return {
            'is_running': self.is_running,
            'active_tasks': len(self.tasks),
            'task_names': list(self.tasks.keys()),
            'current_time': datetime.now().isoformat()
        }


# Глобальная переменная для планировщика (будет инициализирована в main.py)
task_scheduler: Optional[TaskScheduler] = None


def get_scheduler() -> Optional[TaskScheduler]:
    """Получить экземпляр планировщика"""
    return task_scheduler


def init_scheduler(bot: Bot) -> TaskScheduler:
    """Инициализировать планировщик"""
    global task_scheduler
    task_scheduler = TaskScheduler(bot)
    return task_scheduler