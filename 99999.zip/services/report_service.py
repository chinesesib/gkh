"""
Сервис генерации отчетов и графиков
Создание визуальных представлений результатов анализа
"""

import asyncio
import os
import io
import base64
from datetime import datetime
from typing import Dict, Any, List, Optional
import logging

import matplotlib
matplotlib.use('Agg')  # Для работы без GUI
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from PIL import Image, ImageDraw, ImageFont
import warnings

# Подавляем предупреждения о шрифтах
warnings.filterwarnings('ignore', category=UserWarning, module='matplotlib.font_manager')

from config import ReportSettings
from utils.logger import PerformanceLogger

logger = logging.getLogger(__name__)

# Настройка стилей для графиков
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

# Настройка шрифтов для поддержки кириллицы в Windows
plt.rcParams['font.family'] = ['Arial', 'DejaVu Sans', 'Segoe UI', 'Tahoma', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False

# Дополнительные настройки для Windows
plt.rcParams['font.size'] = 10
plt.rcParams['figure.dpi'] = 100


class ReportService:
    """Сервис для создания отчетов и графиков"""
    
    def __init__(self):
        self.reports_dir = "reports"
        os.makedirs(self.reports_dir, exist_ok=True)
    
    async def generate_report(self, analysis_result: Dict[str, Any], user_id: int) -> Dict[str, Any]:
        """Генерация полного отчета с графиками"""
        
        logger.info(f"📊 Генерация отчета для пользователя {user_id}")
        
        with PerformanceLogger("report_generation", user_id):
            
            report_id = f"report_{user_id}_{int(datetime.now().timestamp())}"
            
            try:
                # Создаем сводный график
                summary_chart = await self._create_summary_chart(analysis_result, report_id)
                
                # Создаем график сравнения тарифов
                tariff_chart = await self._create_tariff_comparison_chart(analysis_result, report_id)
                
                # Создаем финансовый график
                financial_chart = await self._create_financial_chart(analysis_result, report_id)
                
                report_data = {
                    'report_id': report_id,
                    'user_id': user_id,
                    'created_at': datetime.now().isoformat(),
                    'charts': {
                        'summary_chart': summary_chart,
                        'tariff_chart': tariff_chart,
                        'financial_chart': financial_chart
                    },
                    'summary': self._generate_text_summary(analysis_result)
                }
                
                logger.info(f"✅ Отчет {report_id} создан успешно")
                return report_data
                
            except Exception as e:
                logger.error(f"❌ Ошибка генерации отчета: {e}")
                # Возвращаем базовый отчет без графиков
                return {
                    'report_id': report_id,
                    'user_id': user_id,
                    'created_at': datetime.now().isoformat(),
                    'charts': {},
                    'summary': self._generate_text_summary(analysis_result),
                    'error': str(e)
                }
    
    async def _create_summary_chart(self, analysis_result: Dict[str, Any], report_id: str) -> str:
        """Создание сводного графика анализа"""
        
        def create_chart():
            services = analysis_result.get('services', [])
            
            if not services:
                # Создаем заглушку
                fig, ax = plt.subplots(figsize=ReportSettings.CHART_SIZE)
                ax.text(0.5, 0.5, 'Нет данных для отображения', 
                       ha='center', va='center', fontsize=16)
                ax.set_xlim(0, 1)
                ax.set_ylim(0, 1)
                ax.axis('off')
            else:
                # Подготавливаем данные
                service_names = []
                actual_tariffs = []
                standard_tariffs = []
                violations = []
                
                for service in services[:8]:  # Ограничиваем количество услуг
                    name = service.get('name', 'Неизвестно')[:15]  # Обрезаем длинные названия
                    service_names.append(name)
                    
                    actual = self._safe_float(service.get('tariff_actual', 0))
                    standard = self._safe_float(service.get('tariff_standard', 0))
                    
                    actual_tariffs.append(actual)
                    standard_tariffs.append(standard)
                    violations.append(service.get('is_violation', False))
                
                # Создаем график
                fig, ax = plt.subplots(figsize=ReportSettings.CHART_SIZE)
                
                x = range(len(service_names))
                width = 0.35
                
                # Столбцы для фактических и нормативных тарифов
                bars1 = ax.bar([i - width/2 for i in x], actual_tariffs, width, 
                              label='Фактический тариф', alpha=0.8)
                bars2 = ax.bar([i + width/2 for i in x], standard_tariffs, width,
                              label='Нормативный тариф', alpha=0.8)
                
                # Выделяем нарушения красным цветом
                for i, (bar, is_violation) in enumerate(zip(bars1, violations)):
                    if is_violation:
                        bar.set_color(ReportSettings.CHART_COLORS['danger'])
                    else:
                        bar.set_color(ReportSettings.CHART_COLORS['normal'])
                
                ax.set_xlabel('Услуги ЖКХ', fontsize=12)
                ax.set_ylabel('Тариф (руб.)', fontsize=12)
                ax.set_title('Сравнение тарифов с нормативами', fontsize=14, fontweight='bold')
                ax.set_xticks(x)
                ax.set_xticklabels(service_names, rotation=45, ha='right')
                ax.legend()
                ax.grid(True, alpha=0.3)
                
                # Добавляем подпись о нарушениях
                violations_count = sum(violations)
                if violations_count > 0:
                    ax.text(0.02, 0.98, f'⚠️ Нарушений: {violations_count}', 
                           transform=ax.transAxes, va='top',
                           bbox=dict(boxstyle='round', facecolor='orange', alpha=0.7))
            
            plt.tight_layout()
            
            # Сохраняем в файл
            chart_path = os.path.join(self.reports_dir, f"{report_id}_summary.png")
            plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
            plt.close()
            
            return chart_path
        
        # Выполняем в отдельном потоке
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, create_chart)
    
    async def _create_tariff_comparison_chart(self, analysis_result: Dict[str, Any], report_id: str) -> str:
        """График детального сравнения тарифов"""
        
        def create_chart():
            services = analysis_result.get('services', [])
            
            if not services:
                return self._create_placeholder_chart(report_id, "tariff_comparison", "Нет данных о тарифах")
            
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
            
            # График 1: Переплаты по услугам
            service_names = []
            overpayments = []
            
            for service in services:
                if service.get('is_violation', False):
                    name = service.get('name', 'Неизвестно')[:12]
                    overpay = self._safe_float(service.get('overpayment', 0))
                    if overpay > 0:
                        service_names.append(name)
                        overpayments.append(overpay)
            
            if overpayments:
                colors = [ReportSettings.CHART_COLORS['danger'] if x > 0 else ReportSettings.CHART_COLORS['normal'] for x in overpayments]
                bars = ax1.bar(service_names, overpayments, color=colors, alpha=0.8)
                ax1.set_title('Переплаты по услугам', fontsize=14, fontweight='bold')
                ax1.set_ylabel('Переплата (руб.)', fontsize=12)
                ax1.tick_params(axis='x', rotation=45)
                
                # Добавляем значения на столбцы
                for bar, value in zip(bars, overpayments):
                    if value > 0:
                        ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1, 
                                f'{value:.0f}₽', ha='center', va='bottom', fontsize=10)
            else:
                ax1.text(0.5, 0.5, 'Переплат не обнаружено', ha='center', va='center', fontsize=14)
                ax1.set_xlim(0, 1)
                ax1.set_ylim(0, 1)
            
            # График 2: Круговая диаграмма нарушений
            violation_types = {}
            for violation in analysis_result.get('violations', []):
                vtype = violation.get('type', 'Другое')
                violation_types[vtype] = violation_types.get(vtype, 0) + 1
            
            if violation_types:
                ax2.pie(violation_types.values(), labels=violation_types.keys(), autopct='%1.1f%%',
                       colors=sns.color_palette('Set3', len(violation_types)))
                ax2.set_title('Типы нарушений', fontsize=14, fontweight='bold')
            else:
                ax2.text(0.5, 0.5, 'Нарушений не обнаружено ✅', ha='center', va='center', fontsize=14)
                ax2.set_xlim(0, 1)
                ax2.set_ylim(0, 1)
            
            plt.tight_layout()
            
            chart_path = os.path.join(self.reports_dir, f"{report_id}_tariff_comparison.png")
            plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
            plt.close()
            
            return chart_path
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, create_chart)
    
    async def _create_financial_chart(self, analysis_result: Dict[str, Any], report_id: str) -> str:
        """График финансового анализа"""
        
        def create_chart():
            financial = analysis_result.get('financial_analysis', {})
            
            # Format financial values properly
            monthly_overpay = self._safe_float(financial.get('monthly_overpayment', 0))
            yearly_overpay = self._safe_float(financial.get('yearly_overpayment', 0))
            
            fig, ax = plt.subplots(figsize=(10, 6))
            
            if monthly_overpay > 0:
                categories = ['За месяц', 'За год (прогноз)']
                values = [monthly_overpay, yearly_overpay]
                
                bars = ax.bar(categories, values, 
                             color=[ReportSettings.CHART_COLORS['warning'], ReportSettings.CHART_COLORS['danger']],
                             alpha=0.8)
                
                ax.set_title('Финансовые потери от переплат', fontsize=14, fontweight='bold')
                ax.set_ylabel('Сумма (руб.)', fontsize=12)
                
                # Добавляем значения на столбцы
                for bar, value in zip(bars, values):
                    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(values) * 0.01, 
                           f'{value:,.0f}'.replace(',', ' '), ha='center', va='bottom', fontsize=12, fontweight='bold')
                
                # Добавляем сетку
                ax.grid(True, alpha=0.3)
                ax.set_ylim(0, max(values) * 1.2)
                
            else:
                ax.text(0.5, 0.5, '💰 Переплат не обнаружено!\nВаши тарифы соответствуют нормативам', 
                       ha='center', va='center', fontsize=16, 
                       bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.7))
                ax.set_xlim(0, 1)
                ax.set_ylim(0, 1)
                ax.axis('off')
            
            plt.tight_layout()
            
            chart_path = os.path.join(self.reports_dir, f"{report_id}_financial.png")
            plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
            plt.close()
            
            return chart_path
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, create_chart)
    
    def _create_placeholder_chart(self, report_id: str, chart_type: str, message: str) -> str:
        """Создание заглушки для графика"""
        
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.text(0.5, 0.5, message, ha='center', va='center', fontsize=16)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis('off')
        
        chart_path = os.path.join(self.reports_dir, f"{report_id}_{chart_type}.png")
        plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
        plt.close()
        
        return chart_path
    
    def _safe_float(self, value) -> float:
        """Безопасное преобразование в float"""
        
        if value is None:
            return 0.0
        
        try:
            if isinstance(value, str):
                value = value.replace(' ₽', '').replace('₽', '').replace(',', '.').strip()
            return float(value)
        except (ValueError, TypeError):
            return 0.0
    
    def _generate_text_summary(self, analysis_result: Dict[str, Any]) -> str:
        """Генерация текстового резюме"""
        
        summary = analysis_result.get('summary', {})
        violations = analysis_result.get('violations', [])
        financial = analysis_result.get('financial_analysis', {})
        
        text_summary = f"""
📋 КРАТКИЙ ОТЧЕТ АНАЛИЗА

🏠 Общая информация:
• Период: {summary.get('period', 'Н/Д')}
• Общая сумма: {summary.get('total_amount', 'Н/Д')}
• Услуг проанализировано: {summary.get('services_count', 0)}

⚠️ Нарушения:
• Найдено нарушений: {len(violations)}
• Потенциальная переплата: {summary.get('total_overpayment', '0')} ₽

💰 Финансовый анализ:
• Переплата за месяц: {financial.get('monthly_overpayment', '0')} ₽
• Переплата за год: {financial.get('yearly_overpayment', '0')} ₽

📝 Рекомендации:
"""
        
        recommendations = analysis_result.get('recommendations', [])
        for i, rec in enumerate(recommendations[:3], 1):
            text_summary += f"{i}. {rec}\n"
        
        return text_summary.strip()

    def _create_text_summary(self, analysis_result: Dict[str, Any]) -> str:
        """Создание текстового резюме отчета"""
        
        summary = analysis_result.get('summary', {})
        violations = analysis_result.get('violations', [])
        financial = analysis_result.get('financial_analysis', {})
        services = analysis_result.get('services', [])
        
        # Format financial values properly
        monthly_overpayment = financial.get('monthly_overpayment', '0')
        yearly_overpayment = financial.get('yearly_overpayment', '0')
        total_overpayment = summary.get('total_overpayment', '0')
        
        # Format monthly overpayment
        if isinstance(monthly_overpayment, str):
            monthly_clean = monthly_overpayment.replace(' ₽', '').replace('₽', '').replace(' ', '').replace(',', '.')
            try:
                monthly_value = float(monthly_clean)
                monthly_str = f"{monthly_value:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
            except (ValueError, TypeError):
                monthly_str = monthly_overpayment
        elif isinstance(monthly_overpayment, (int, float)):
            monthly_str = f"{monthly_overpayment:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
        else:
            monthly_str = str(monthly_overpayment)
            
        # Format yearly overpayment
        if isinstance(yearly_overpayment, str):
            yearly_clean = yearly_overpayment.replace(' ₽', '').replace('₽', '').replace(' ', '').replace(',', '.')
            try:
                yearly_value = float(yearly_clean)
                yearly_str = f"{yearly_value:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
            except (ValueError, TypeError):
                yearly_str = yearly_overpayment
        elif isinstance(yearly_overpayment, (int, float)):
            yearly_str = f"{yearly_overpayment:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
        else:
            yearly_str = str(yearly_overpayment)
            
        # Format total overpayment
        if isinstance(total_overpayment, str):
            total_clean = total_overpayment.replace(' ₽', '').replace('₽', '').replace(' ', '').replace(',', '.')
            try:
                total_value = float(total_clean)
                total_str = f"{total_value:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
            except (ValueError, TypeError):
                total_str = total_overpayment
        elif isinstance(total_overpayment, (int, float)):
            total_str = f"{total_overpayment:,.2f}".replace(",", " ").replace(".", ",") + " ₽"
        else:
            total_str = str(total_overpayment)
        
        text_summary = f"""
📊 КРАТКИЙ ОТЧЕТ АНАЛИЗА КВИТАНЦИИ ЖКХ

🏠 Информация о квитанции:
• Период: {summary.get('period', 'Н/Д')}
• Общая сумма: {summary.get('total_amount', 'Н/Д')} ₽
• Услуг проанализировано: {summary.get('services_count', 0)}

💰 Финансовый анализ:
• Переплата за месяц: {monthly_str}
• Переплата за год (прогноз): {yearly_str}
• Стоимость за м²: {financial.get('cost_per_m2', 0):.2f} ₽/м²

⚠️ Нарушения:
• Найдено нарушений: {len(violations)}
• Потенциальная переплата: {total_str}

💡 Энергосберегающие улучшения:
• Рекомендованных улучшений: {len(financial.get('recommended_improvements', []))}
• Потенциальная годовая экономия: {financial.get('potential_annual_savings', 0)} ₽

📝 Рекомендации:
"""
        
        recommendations = analysis_result.get('recommendations', [])
        for i, rec in enumerate(recommendations[:5], 1):
            text_summary += f"{i}. {rec}\n"
        
        return text_summary.strip()
    
    async def generate_additional_charts(self, analysis_result: Dict[str, Any], user_id: int) -> Dict[str, str]:
        """Генерация дополнительных графиков"""
        
        logger.info(f"📊 Генерация дополнительных графиков для пользователя {user_id}")
        
        with PerformanceLogger("additional_charts_generation", user_id):
            chart_id = f"charts_{user_id}_{int(datetime.now().timestamp())}"
            
            try:
                # Генерируем 4 дополнительных графика
                violation_trend_chart = await self._create_violation_trend_chart(analysis_result, chart_id)
                service_breakdown_chart = await self._create_service_breakdown_chart(analysis_result, chart_id)
                monthly_comparison_chart = await self._create_monthly_comparison_chart(analysis_result, chart_id)
                savings_potential_chart = await self._create_savings_potential_chart(analysis_result, chart_id)
                
                charts_data = {
                    'violation_trend': violation_trend_chart,
                    'service_breakdown': service_breakdown_chart,
                    'monthly_comparison': monthly_comparison_chart,
                    'savings_potential': savings_potential_chart
                }
                
                logger.info(f"✅ Дополнительные графики {chart_id} созданы успешно")
                return charts_data
                
            except Exception as e:
                logger.error(f"❌ Ошибка генерации дополнительных графиков: {e}")
                return {}
    
    async def _create_violation_trend_chart(self, analysis_result: Dict[str, Any], chart_id: str) -> str:
        """График тренда нарушений"""
        
        def create_chart():
            violations = analysis_result.get('violations', [])
            
            fig, ax = plt.subplots(figsize=(12, 8))
            
            if not violations:
                ax.text(0.5, 0.5, 'Нарушений не обнаружено ✅\nВсе тарифы соответствуют нормативам', 
                       ha='center', va='center', fontsize=16,
                       bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.7))
                ax.set_xlim(0, 1)
                ax.set_ylim(0, 1)
                ax.axis('off')
            else:
                # Группируем нарушения по типам
                violation_types = {}
                violation_amounts = {}
                
                for violation in violations:
                    vtype = violation.get('type', 'Прочие нарушения')
                    amount = self._safe_float(violation.get('amount', 0))
                    
                    if vtype not in violation_types:
                        violation_types[vtype] = 0
                        violation_amounts[vtype] = 0
                    
                    violation_types[vtype] += 1
                    violation_amounts[vtype] += amount
                
                # Создаем столбчатую диаграмму
                types = list(violation_types.keys())
                counts = list(violation_types.values())
                amounts = [violation_amounts[t] for t in types]
                
                x = range(len(types))
                width = 0.35
                
                fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
                
                # Левый график - количество
                colors = sns.color_palette('husl', len(types))
                bars1 = ax1.bar(types, counts, color=colors, alpha=0.8)
                ax1.set_title('Количество нарушений', fontsize=14, fontweight='bold')
                ax1.set_ylabel('Количество', fontsize=12)
                ax1.tick_params(axis='x', rotation=45)
                
                # Правый график - суммы
                bars2 = ax2.bar(types, amounts, color=colors, alpha=0.8)
                ax2.set_title('Суммы переплат', fontsize=14, fontweight='bold')
                ax2.set_ylabel('Сумма (руб.)', fontsize=12)
                ax2.tick_params(axis='x', rotation=45)
                
                # Добавляем значения
                for bar, count in zip(bars1, counts):
                    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, 
                            str(count), ha='center', va='bottom', fontsize=11, fontweight='bold')
                
                for bar, amount in zip(bars2, amounts):
                    if amount > 0:
                        ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(amounts) * 0.01, 
                                f'{amount:.0f}₽', ha='center', va='bottom', fontsize=11, fontweight='bold')
                
                ax1.grid(True, alpha=0.3)
                ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            chart_path = os.path.join(self.reports_dir, f"{chart_id}_violation_trend.png")
            plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
            plt.close()
            return chart_path
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, create_chart)
    
    async def _create_service_breakdown_chart(self, analysis_result: Dict[str, Any], chart_id: str) -> str:
        """Круговая диаграмма распределения услуг"""
        
        def create_chart():
            services = analysis_result.get('services', [])
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
            
            if not services:
                for ax in [ax1, ax2]:
                    ax.text(0.5, 0.5, 'Нет данных', ha='center', va='center', fontsize=14)
                    ax.set_xlim(0, 1)
                    ax.set_ylim(0, 1)
            else:
                # Левая диаграмма - распределение по стоимости
                service_names = []
                service_costs = []
                
                for service in services[:8]:
                    name = service.get('name', 'Неизвестно')[:15]
                    cost = self._safe_float(service.get('amount', 0))
                    if cost > 0:
                        service_names.append(name)
                        service_costs.append(cost)
                
                if service_costs:
                    colors = sns.color_palette('husl', len(service_names))
                    wedges, texts, autotexts = ax1.pie(service_costs, labels=service_names, autopct='%1.1f%%',
                                                      colors=colors, startangle=90)
                    for autotext in autotexts:
                        autotext.set_color('white')
                        autotext.set_fontweight('bold')
                
                ax1.set_title('Распределение стоимости', fontsize=14, fontweight='bold')
                
                # Правая диаграмма - статус соответствия
                compliant_count = sum(1 for s in services if not s.get('is_violation', False))
                violation_count = sum(1 for s in services if s.get('is_violation', False))
                
                if compliant_count > 0 or violation_count > 0:
                    statuses = ['Соответствуют', 'Нарушают']
                    counts = [compliant_count, violation_count]
                    colors = [ReportSettings.CHART_COLORS['normal'], ReportSettings.CHART_COLORS['danger']]
                    
                    filtered_data = [(s, c, col) for s, c, col in zip(statuses, counts, colors) if c > 0]
                    if filtered_data:
                        statuses, counts, colors = zip(*filtered_data)
                        wedges, texts, autotexts = ax2.pie(counts, labels=statuses, autopct='%1.1f%%',
                                                          colors=colors, startangle=90)
                        for autotext in autotexts:
                            autotext.set_color('white')
                            autotext.set_fontweight('bold')
                
                ax2.set_title('Соответствие нормам', fontsize=14, fontweight='bold')
            
            plt.tight_layout()
            chart_path = os.path.join(self.reports_dir, f"{chart_id}_service_breakdown.png")
            plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
            plt.close()
            return chart_path
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, create_chart)
    
    async def _create_monthly_comparison_chart(self, analysis_result: Dict[str, Any], chart_id: str) -> str:
        """График сравнения платежей по месяцам"""
        
        def create_chart():
            months = ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 
                     'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек']
            
            financial = analysis_result.get('financial_analysis', {})
            current_overpay = self._safe_float(financial.get('monthly_overpayment', 0))
            
            # Генерируем симуляцию данных
            import random
            random.seed(42)
            
            overpayments = []
            normal_payments = []
            
            for i in range(12):
                variation = random.uniform(0.7, 1.3)
                month_overpay = current_overpay * variation
                overpayments.append(month_overpay)
                
                base_payment = 5000 + random.uniform(-500, 500)
                normal_payments.append(base_payment)
            
            fig, ax = plt.subplots(figsize=(14, 8))
            
            x = range(len(months))
            width = 0.35
            
            bars1 = ax.bar([i - width/2 for i in x], normal_payments, width, 
                          label='Нормальная оплата', 
                          color=ReportSettings.CHART_COLORS['normal'], alpha=0.8)
            bars2 = ax.bar([i + width/2 for i in x], overpayments, width,
                          label='Переплата', 
                          color=ReportSettings.CHART_COLORS['danger'], alpha=0.8)
            
            ax.set_xlabel('Месяц', fontsize=12)
            ax.set_ylabel('Сумма (руб.)', fontsize=12)
            ax.set_title('Сравнение платежей и переплат', fontsize=14, fontweight='bold')
            ax.set_xticks(x)
            ax.set_xticklabels(months)
            ax.legend()
            ax.grid(True, alpha=0.3)
            
            avg_overpay = sum(overpayments) / len(overpayments) if overpayments else 0
            if avg_overpay > 0:
                ax.axhline(y=avg_overpay, color='red', linestyle='--', alpha=0.7, 
                          label=f'Средняя переплата: {avg_overpay:,.0f}'.replace(',', ' '))
            
            plt.tight_layout()
            chart_path = os.path.join(self.reports_dir, f"{chart_id}_monthly_comparison.png")
            plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
            plt.close()
            return chart_path
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, create_chart)
    
    async def _create_savings_potential_chart(self, analysis_result: Dict[str, Any], chart_id: str) -> str:
        """График потенциальной экономии"""
        
        def create_chart():
            financial = analysis_result.get('financial_analysis', {})
            monthly_overpay = self._safe_float(financial.get('monthly_overpayment', 0))
            yearly_overpay = self._safe_float(financial.get('yearly_overpayment', 0))
            
            fig, ax = plt.subplots(figsize=(12, 8))
            
            if monthly_overpay <= 0:
                ax.text(0.5, 0.5, '💰 Переплат не обнаружено!\nПотенциальной экономии нет', 
                       ha='center', va='center', fontsize=16,
                       bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.7))
                ax.set_xlim(0, 1)
                ax.set_ylim(0, 1)
                ax.axis('off')
            else:
                periods = ['Месяц', 'Квартал', 'Полгода', 'Год', '5 лет']
                savings = [monthly_overpay, monthly_overpay * 3, monthly_overpay * 6, yearly_overpay, yearly_overpay * 5]
                
                colors = ['#ff9999', '#ffcc99', '#ffff99', '#99ff99', '#99ccff']
                bars = ax.bar(periods, savings, color=colors, alpha=0.8)
                
                ax.set_title('Потенциальная экономия при устранении нарушений', fontsize=14, fontweight='bold')
                ax.set_ylabel('Экономия (руб.)', fontsize=12)
                ax.grid(True, alpha=0.3)
                
                # Добавляем значения на столбцы
                for bar, saving in zip(bars, savings):
                    if saving > 0:
                        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(savings) * 0.01, 
                               f'{saving:,.0f}'.replace(',', ' '), ha='center', va='bottom', fontsize=12, fontweight='bold')
                
                # Добавляем пояснительный текст
                ax.text(0.02, 0.98, f'Месячная переплата: {monthly_overpay:,.0f} ₽'.replace(',', ' '), 
                       transform=ax.transAxes, va='top', fontsize=12,
                       bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.7))
            
            plt.tight_layout()
            chart_path = os.path.join(self.reports_dir, f"{chart_id}_savings_potential.png")
            plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
            plt.close()
            return chart_path
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, create_chart)
    
    async def generate_enhanced_report(self, analysis_result: Dict[str, Any], user_id: int, 
                                     property_info: Dict[str, Any]) -> Dict[str, Any]:
        """Генерация расширенного отчета с продвинутой аналитикой"""
        
        logger.info(f"📊 Генерация расширенного отчета для пользователя {user_id}")
        
        # Импортируем расширенный сервис анализа
        from services.advanced_analysis_service import AdvancedAnalysisService
        advanced_service = AdvancedAnalysisService()
        
        with PerformanceLogger("enhanced_report_generation", user_id):
            report_id = f"enhanced_report_{user_id}_{int(datetime.now().timestamp())}"
            
            try:
                # Получаем расширенную аналитику
                property_area = property_info.get('area', 0)
                region = property_info.get('region', 'moscow')
                
                # Годовой прогноз расходов
                annual_forecast = await advanced_service.generate_annual_forecast(analysis_result, property_area)
                
                # Анализ пикового потребления
                peak_analysis = await advanced_service.analyze_peak_consumption(analysis_result)
                
                # Сравнение стоимости за м²
                cost_per_m2_comparison = await advanced_service.calculate_cost_per_m2_comparison(
                    analysis_result, property_area, region)
                
                # ROI энергосберегающих улучшений
                roi_analysis = await advanced_service.calculate_energy_saving_roi(analysis_result, property_area)
                
                # Регулятивная информация
                regulatory_info = await advanced_service.get_regulatory_information(region)
                
                # Продвинутое выявление нарушений
                advanced_violations = await advanced_service.detect_advanced_violations(
                    analysis_result, property_area)
                
                # Генерация пакета документации
                documentation_package = await advanced_service.generate_documentation_package(
                    analysis_result, property_info)
                
                # Создаем расширенные графики
                enhanced_charts = await self._create_enhanced_charts(
                    analysis_result, annual_forecast, cost_per_m2_comparison, 
                    roi_analysis, advanced_violations, report_id)
                
                enhanced_report_data = {
                    'report_id': report_id,
                    'user_id': user_id,
                    'created_at': datetime.now().isoformat(),
                    'charts': enhanced_charts,
                    'enhanced_analysis': {
                        'annual_forecast': annual_forecast,
                        'peak_consumption_analysis': peak_analysis,
                        'cost_per_m2_comparison': cost_per_m2_comparison,
                        'energy_saving_roi': roi_analysis,
                        'regulatory_info': regulatory_info,
                        'advanced_violations': advanced_violations
                    },
                    'documentation': documentation_package,
                    'summary': self._generate_enhanced_text_summary(analysis_result, annual_forecast, 
                                                                  cost_per_m2_comparison, roi_analysis)
                }
                
                logger.info(f"✅ Расширенный отчет {report_id} создан успешно")
                return enhanced_report_data
                
            except Exception as e:
                logger.error(f"❌ Ошибка генерации расширенного отчета: {e}")
                # Возвращаем базовый отчет без расширенной аналитики
                return {
                    'report_id': report_id,
                    'user_id': user_id,
                    'created_at': datetime.now().isoformat(),
                    'charts': {},
                    'enhanced_analysis': {},
                    'documentation': {},
                    'summary': self._generate_text_summary(analysis_result),
                    'error': str(e)
                }
    
    async def _create_enhanced_charts(self, analysis_result: Dict[str, Any], 
                                    annual_forecast: Dict[str, Any],
                                    cost_per_m2_comparison: Dict[str, Any],
                                    roi_analysis: Dict[str, Any],
                                    advanced_violations: Dict[str, Any],
                                    report_id: str) -> Dict[str, str]:
        """Создание расширенных графиков"""
        
        enhanced_charts = {}
        
        try:
            # График годового прогноза
            annual_chart = await self._create_annual_forecast_chart(annual_forecast, report_id)
            enhanced_charts['annual_forecast'] = annual_chart
            
            # График сравнения стоимости за м²
            cost_m2_chart = await self._create_cost_per_m2_chart(cost_per_m2_comparison, report_id)
            enhanced_charts['cost_per_m2'] = cost_m2_chart
            
            # График ROI улучшений
            roi_chart = await self._create_roi_chart(roi_analysis, report_id)
            enhanced_charts['roi_analysis'] = roi_chart
            
            # График продвинутых нарушений
            violations_chart = await self._create_advanced_violations_chart(advanced_violations, report_id)
            enhanced_charts['advanced_violations'] = violations_chart
            
        except Exception as e:
            logger.error(f"❌ Ошибка создания расширенных графиков: {e}")
        
        return enhanced_charts
    
    async def _create_annual_forecast_chart(self, annual_forecast: Dict[str, Any], report_id: str) -> str:
        """График годового прогноза расходов"""
        
        def create_chart():
            monthly_projections = annual_forecast.get('monthly_projections', [])
            
            fig, ax = plt.subplots(figsize=(14, 8))
            
            if not monthly_projections:
                ax.text(0.5, 0.5, 'Нет данных для прогноза', ha='center', va='center', fontsize=16)
                ax.set_xlim(0, 1)
                ax.set_ylim(0, 1)
                ax.axis('off')
            else:
                months = [p['month_name'] for p in monthly_projections]
                amounts = [p['total_amount'] for p in monthly_projections]
                
                bars = ax.bar(months, amounts, color=sns.color_palette('husl', len(months)), alpha=0.8)
                ax.set_title('Годовой прогноз расходов', fontsize=14, fontweight='bold')
                ax.set_ylabel('Сумма (руб.)', fontsize=12)
                ax.tick_params(axis='x', rotation=45)
                ax.grid(True, alpha=0.3)
                
                # Добавляем значения на столбцы
                for bar, amount in zip(bars, amounts):
                    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(amounts) * 0.01, 
                           f'{amount:.0f}₽', ha='center', va='bottom', fontsize=10)
            
            plt.tight_layout()
            chart_path = os.path.join(self.reports_dir, f"{report_id}_annual_forecast.png")
            plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
            plt.close()
            return chart_path
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, create_chart)
    
    async def _create_cost_per_m2_chart(self, cost_per_m2_comparison: Dict[str, Any], report_id: str) -> str:
        """График сравнения стоимости за м²"""
        
        def create_chart():
            services_comparison = cost_per_m2_comparison.get('services_comparison', [])
            
            fig, ax = plt.subplots(figsize=(12, 8))
            
            if not services_comparison:
                ax.text(0.5, 0.5, 'Нет данных для сравнения', ha='center', va='center', fontsize=16)
                ax.set_xlim(0, 1)
                ax.set_ylim(0, 1)
                ax.axis('off')
            else:
                service_names = [s['service_name'][:15] for s in services_comparison]
                current_costs = [s['current_per_m2'] for s in services_comparison]
                regional_costs = [s['regional_per_m2'] for s in services_comparison]
                
                x = range(len(service_names))
                width = 0.35
                
                bars1 = ax.bar([i - width/2 for i in x], current_costs, width, 
                              label='Текущая стоимость', alpha=0.8)
                bars2 = ax.bar([i + width/2 for i in x], regional_costs, width,
                              label='Региональный стандарт', alpha=0.8)
                
                # Выделяем нарушения красным
                for i, (bar, service) in enumerate(zip(bars1, services_comparison)):
                    if service['compliance'] == 'violation':
                        bar.set_color(ReportSettings.CHART_COLORS['danger'])
                
                ax.set_xlabel('Услуги ЖКХ', fontsize=12)
                ax.set_ylabel('Стоимость за м² (руб.)', fontsize=12)
                ax.set_title('Сравнение стоимости за м² с региональными стандартами', fontsize=14, fontweight='bold')
                ax.set_xticks(x)
                ax.set_xticklabels(service_names, rotation=45, ha='right')
                ax.legend()
                ax.grid(True, alpha=0.3)
            
            plt.tight_layout()
            chart_path = os.path.join(self.reports_dir, f"{report_id}_cost_per_m2.png")
            plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
            plt.close()
            return chart_path
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, create_chart)
    
    def _generate_enhanced_text_summary(self, analysis_result: Dict[str, Any], 
                                      annual_forecast: Dict[str, Any],
                                      cost_per_m2_comparison: Dict[str, Any],
                                      roi_analysis: Dict[str, Any]) -> str:
        """Генерация расширенного текстового резюме"""
        
        summary = analysis_result.get('summary', {})
        violations = analysis_result.get('violations', [])
        financial = analysis_result.get('financial_analysis', {})
        
        text_summary = f"""
📊 РАСШИРЕННЫЙ ОТЧЕТ АНАЛИЗА КВИТАНЦИИ ЖКХ

🏠 Общая информация:
• Период: {summary.get('period', 'Н/Д')}
• Общая сумма: {summary.get('total_amount', 'Н/Д')}
• Услуг проанализировано: {summary.get('services_count', 0)}

💰 Финансовый анализ:
• Переплата за месяц: {financial.get('monthly_overpayment', '0')} ₽
• Переплата за год (прогноз): {annual_forecast.get('annual_total', '0')} ₽
• Стоимость за м²: {cost_per_m2_comparison.get('current_cost_per_m2', 0):.2f} ₽/м²

⚠️ Нарушения:
• Найдено нарушений: {len(violations)}
• Потенциальная переплата: {summary.get('total_overpayment', '0')} ₽

💡 Энергосберегающие улучшения:
• Рекомендованных улучшений: {len(roi_analysis.get('recommended_improvements', []))}
• Потенциальная годовая экономия: {roi_analysis.get('total_potential_annual_savings', 0)} ₽

📝 Рекомендации:
"""
        
        recommendations = analysis_result.get('recommendations', [])
        for i, rec in enumerate(recommendations[:5], 1):
            text_summary += f"{i}. {rec}\n"
        
        return text_summary.strip()
    
    async def _create_roi_chart(self, roi_analysis: Dict[str, Any], report_id: str) -> str:
        """График ROI энергосберегающих улучшений"""
        
        def create_chart():
            improvements = roi_analysis.get('improvements', [])
            
            fig, ax = plt.subplots(figsize=(14, 8))
            
            if not improvements:
                ax.text(0.5, 0.5, 'Нет данных по улучшениям', ha='center', va='center', fontsize=16)
                ax.set_xlim(0, 1)
                ax.set_ylim(0, 1)
                ax.axis('off')
            else:
                # Сортируем по ROI
                sorted_improvements = sorted(improvements, key=lambda x: x['roi_percentage'], reverse=True)[:8]
                
                names = [imp['name'][:20] for imp in sorted_improvements]
                roi_values = [imp['roi_percentage'] for imp in sorted_improvements]
                payback_years = [imp['payback_years'] for imp in sorted_improvements]
                
                x = range(len(names))
                
                # Двойная ось Y
                ax1 = ax
                ax2 = ax.twinx()
                
                bars1 = ax1.bar([i - 0.2 for i in x], roi_values, width=0.4, 
                               label='ROI (%)', color='green', alpha=0.7)
                bars2 = ax2.bar([i + 0.2 for i in x], payback_years, width=0.4,
                               label='Окупаемость (лет)', color='orange', alpha=0.7)
                
                ax1.set_xlabel('Улучшения', fontsize=12)
                ax1.set_ylabel('ROI (%)', fontsize=12, color='green')
                ax2.set_ylabel('Окупаемость (лет)', fontsize=12, color='orange')
                ax1.set_title('Экономическая эффективность улучшений', fontsize=14, fontweight='bold')
                ax1.set_xticks(x)
                ax1.set_xticklabels(names, rotation=45, ha='right')
                
                # Добавляем значения
                for bar, value in zip(bars1, roi_values):
                    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1, 
                            f'{value:.1f}%', ha='center', va='bottom', fontsize=9)
                
                for bar, value in zip(bars2, payback_years):
                    if value < float('inf'):
                        ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, 
                                f'{value:.1f}г', ha='center', va='bottom', fontsize=9)
            
            plt.tight_layout()
            chart_path = os.path.join(self.reports_dir, f"{report_id}_roi_analysis.png")
            plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
            plt.close()
            return chart_path
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, create_chart)
    
    async def _create_advanced_violations_chart(self, advanced_violations: Dict[str, Any], report_id: str) -> str:
        """График продвинутых нарушений"""
        
        def create_chart():
            violation_types = [
                'cross_validation_violations',
                'consumption_anomalies', 
                'meter_malfunction_indicators',
                'double_charging',
                'unauthorized_charges'
            ]
            
            violation_counts = []
            violation_names = []
            
            for vtype in violation_types:
                count = len(advanced_violations.get(vtype, []))
                if count > 0:
                    violation_counts.append(count)
                    violation_names.append({
                        'cross_validation_violations': 'Корреляции',
                        'consumption_anomalies': 'Аномалии',
                        'meter_malfunction_indicators': 'Счетчики',
                        'double_charging': 'Двойные начисления',
                        'unauthorized_charges': 'Несанкц. платежи'
                    }[vtype])
            
            fig, ax = plt.subplots(figsize=(12, 8))
            
            if not violation_counts:
                ax.text(0.5, 0.5, 'Продвинутые нарушения не обнаружены ✅', 
                       ha='center', va='center', fontsize=16,
                       bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.7))
                ax.set_xlim(0, 1)
                ax.set_ylim(0, 1)
                ax.axis('off')
            else:
                colors = sns.color_palette('Set3', len(violation_names))
                bars = ax.bar(violation_names, violation_counts, color=colors, alpha=0.8)
                
                ax.set_title('Продвинутое выявление нарушений', fontsize=14, fontweight='bold')
                ax.set_ylabel('Количество', fontsize=12)
                ax.tick_params(axis='x', rotation=45)
                ax.grid(True, alpha=0.3)
                
                # Добавляем значения
                for bar, count in zip(bars, violation_counts):
                    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, 
                           str(count), ha='center', va='bottom', fontsize=12, fontweight='bold')
            
            plt.tight_layout()
            chart_path = os.path.join(self.reports_dir, f"{report_id}_advanced_violations.png")
            plt.savefig(chart_path, dpi=ReportSettings.DPI, bbox_inches='tight')
            plt.close()
            return chart_path
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, create_chart)

# Глобальный экземпляр сервиса
report_service = ReportService()