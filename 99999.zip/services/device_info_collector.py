"""
Веб-приложение для получения MAC-адреса устройства пользователя
(используется в процессе аутентификации для предотвращения дублирования аккаунтов)
"""

import logging
from typing import Optional

logger = logging.getLogger(__name__)


class DeviceInfoCollector:
    """Сборщик информации об устройстве пользователя"""
    
    def __init__(self):
        self.web_app_url = "https://your-domain.com/webapp"  # Замените на реальный URL
    
    def get_web_app_config(self, user_id: int) -> dict:
        """Получить конфигурацию веб-приложения для сбора информации об устройстве"""
        
        return {
            "url": f"{self.web_app_url}?user_id={user_id}",
            "button_text": "🔍 Определить устройство",
            "description": "Нажмите для определения информации об устройстве (требуется для безопасности)"
        }
    
    async def extract_device_info(self, web_app_data: str) -> dict:
        """Извлечь информацию об устройстве из данных веб-приложения"""
        
        try:
            import json
            
            # Парсим данные от веб-приложения
            data = json.loads(web_app_data)
            
            device_info = {
                'mac_address': data.get('mac_address'),
                'user_agent': data.get('user_agent'),
                'screen_resolution': data.get('screen_resolution'),
                'timezone': data.get('timezone'),
                'device_fingerprint': data.get('device_fingerprint'),
                'ip_address': data.get('ip_address')
            }
            
            logger.info(f"📱 Получена информация об устройстве: MAC={bool(device_info.get('mac_address'))}")
            
            return device_info
            
        except Exception as e:
            logger.error(f"❌ Ошибка извлечения информации об устройстве: {e}")
            return {}
    
    def generate_device_fingerprint(self, device_info: dict) -> str:
        """Сгенерировать отпечаток устройства на основе доступной информации"""
        
        import hashlib
        
        # Собираем доступную информацию об устройстве
        fingerprint_data = [
            device_info.get('mac_address', ''),
            device_info.get('user_agent', ''),
            device_info.get('screen_resolution', ''),
            device_info.get('timezone', ''),
            device_info.get('ip_address', '')
        ]
        
        # Создаем хеш на основе собранной информации
        fingerprint_string = '|'.join(filter(None, fingerprint_data))
        
        if fingerprint_string:
            fingerprint = hashlib.sha256(fingerprint_string.encode()).hexdigest()[:16]
            logger.info(f"🔒 Создан отпечаток устройства: {fingerprint}")
            return fingerprint
        else:
            logger.warning("⚠️ Недостаточно данных для создания отпечатка устройства")
            return ""


# Глобальный экземпляр сборщика
device_info_collector = DeviceInfoCollector()


# HTML и JS код для веб-приложения (может быть размещен на отдельном домене)
WEB_APP_HTML = """
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Проверка устройства - ЖКХ Контроль</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            text-align: center;
            max-width: 400px;
            width: 100%;
        }
        .title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .description {
            font-size: 16px;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        .button {
            background: #4CAF50;
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 50px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
        }
        .button:hover {
            background: #45a049;
            transform: translateY(-2px);
        }
        .status {
            margin-top: 20px;
            font-size: 14px;
            opacity: 0.8;
        }
        .warning {
            background: rgba(255, 193, 7, 0.2);
            border: 1px solid rgba(255, 193, 7, 0.5);
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="title">🔒 Проверка устройства</div>
        <div class="description">
            Для обеспечения безопасности и предотвращения злоупотреблений необходимо подтвердить ваше устройство.
        </div>
        
        <div class="warning">
            ⚠️ Информация об устройстве используется только для аутентификации и не передается третьим лицам.
        </div>
        
        <button class="button" onclick="collectDeviceInfo()">
            🔍 Подтвердить устройство
        </button>
        
        <div class="status" id="status">
            Нажмите кнопку для начала проверки
        </div>
    </div>

    <script>
        function updateStatus(message) {
            document.getElementById('status').innerText = message;
        }
        
        async function collectDeviceInfo() {
            updateStatus('🔄 Сбор информации об устройстве...');
            
            try {
                const deviceInfo = {
                    user_agent: navigator.userAgent,
                    screen_resolution: `${screen.width}x${screen.height}`,
                    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                    language: navigator.language,
                    platform: navigator.platform,
                    cookie_enabled: navigator.cookieEnabled,
                    timestamp: new Date().toISOString()
                };
                
                // Попытка получить дополнительную информацию
                try {
                    // Примечание: В современных браузерах MAC-адрес недоступен по соображениям безопасности
                    // Вместо этого создаем уникальный отпечаток браузера
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    ctx.textBaseline = 'top';
                    ctx.font = '14px Arial';
                    ctx.fillText('Device fingerprint', 2, 2);
                    deviceInfo.canvas_fingerprint = canvas.toDataURL();
                } catch (e) {
                    console.log('Canvas fingerprint недоступен');
                }
                
                // Создаем уникальный идентификатор устройства
                const fingerprint = await generateFingerprint(deviceInfo);
                deviceInfo.device_fingerprint = fingerprint;
                
                updateStatus('✅ Информация собрана успешно');
                
                // Отправляем данные обратно в Telegram
                if (window.Telegram && window.Telegram.WebApp) {
                    window.Telegram.WebApp.sendData(JSON.stringify(deviceInfo));
                    window.Telegram.WebApp.close();
                } else {
                    updateStatus('❌ Ошибка: Telegram WebApp недоступен');
                }
                
            } catch (error) {
                console.error('Ошибка сбора информации:', error);
                updateStatus('❌ Ошибка сбора информации об устройстве');
            }
        }
        
        async function generateFingerprint(deviceInfo) {
            const data = [
                deviceInfo.user_agent,
                deviceInfo.screen_resolution,
                deviceInfo.timezone,
                deviceInfo.language,
                deviceInfo.platform,
                deviceInfo.canvas_fingerprint || ''
            ].join('|');
            
            // Простой хеш для создания отпечатка
            let hash = 0;
            for (let i = 0; i < data.length; i++) {
                const char = data.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & hash; // Преобразуем в 32-битное число
            }
            
            return Math.abs(hash).toString(16);
        }
        
        // Автоматический запуск при загрузке страницы
        window.addEventListener('load', function() {
            updateStatus('Готов к проверке устройства');
        });
    </script>
</body>
</html>
"""