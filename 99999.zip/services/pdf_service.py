"""
Сервис обработки PDF документов
Извлечение текста из квитанций ЖКХ
"""

import os
import asyncio
from pathlib import Path
from typing import Optional, Dict, Any, List
import logging

import PyPDF2
import pdfplumber
import fitz  # PyMuPDF

from utils.logger import PerformanceLogger, log_error
from services.yandex_cloud_service import yandex_service

logger = logging.getLogger(__name__)


class PDFService:
    """Сервис для обработки PDF файлов"""
    
    def __init__(self):
        self.temp_dir = Path("temp")
        self.temp_dir.mkdir(exist_ok=True)
    
    async def extract_text(self, file_path: str) -> str:
        """Извлечение текста из PDF файла (мультиметодный подход)"""
        
        logger.info(f"📄 Извлечение текста из PDF: {file_path}")
        
        with PerformanceLogger("pdf_text_extraction"):
            # Попробуем разные методы извлечения текста
            methods = [
                ("pdfplumber", self._extract_with_pdfplumber),
                ("pymupdf", self._extract_with_pymupdf),
                ("pypdf2", self._extract_with_pypdf2),
                ("yandex_cloud", self._extract_with_yandex_cloud)
            ]
            
            best_text = ""
            best_method = ""
            best_length = 0
            
            for method_name, extract_func in methods:
                try:
                    logger.info(f"🔧 Пробуем метод: {method_name}")
                    text = await extract_func(file_path)
                    
                    if text and len(text.strip()) > best_length:
                        best_text = text
                        best_method = method_name
                        best_length = len(text.strip())
                        
                        logger.info(f"✅ {method_name}: {len(text)} символов")
                        
                        # Если получили достаточно текста, можем остановиться
                        if best_length > 500:
                            break
                    else:
                        logger.info(f"⚠️ {method_name}: мало текста ({len(text) if text else 0} символов)")
                        
                except Exception as e:
                    logger.warning(f"❌ Ошибка {method_name}: {e}")
                    continue
            
            if best_text:
                logger.info(f"🏆 Лучший результат: {best_method} ({best_length} символов)")
                return self._clean_text(best_text)
            else:
                logger.error("❌ Не удалось извлечь текст ни одним методом")
                return ""
    
    async def _extract_with_pdfplumber(self, file_path: str) -> str:
        """Извлечение текста с помощью pdfplumber"""
        
        def extract():
            text_parts = []
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text_parts.append(page_text)
            return "\n".join(text_parts)
        
        # Выполняем в отдельном потоке для неблокирующего IO
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, extract)
    
    async def _extract_with_pymupdf(self, file_path: str) -> str:
        """Извлечение текста с помощью PyMuPDF"""
        
        def extract():
            text_parts = []
            doc = fitz.open(file_path)
            try:
                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    page_text = page.get_text()
                    if page_text:
                        text_parts.append(page_text)
                return "\n".join(text_parts)
            finally:
                doc.close()
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, extract)
    
    async def _extract_with_pypdf2(self, file_path: str) -> str:
        """Извлечение текста с помощью PyPDF2"""
        
        def extract():
            text_parts = []
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                for page in pdf_reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text_parts.append(page_text)
            return "\n".join(text_parts)
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, extract)
    
    async def _extract_with_yandex_cloud(self, file_path: str) -> str:
        """Извлечение текста через Yandex.Cloud (для сложных случаев)"""
        
        try:
            with open(file_path, 'rb') as file:
                pdf_content = file.read()
            
            async with yandex_service as service:
                return await service.extract_text_from_pdf(pdf_content)
        except Exception as e:
            logger.warning(f"Ошибка Yandex.Cloud извлечения: {e}")
            return ""
    
    def _clean_text(self, text: str) -> str:
        """Очистка и нормализация извлеченного текста"""
        
        if not text:
            return ""
        
        # Базовая очистка
        lines = []
        for line in text.split('\n'):
            line = line.strip()
            if line:  # Пропускаем пустые строки
                lines.append(line)
        
        cleaned_text = '\n'.join(lines)
        
        # Убираем избыточные пробелы
        import re
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text)
        cleaned_text = re.sub(r'\n\s*\n', '\n', cleaned_text)
        
        logger.info(f"🧹 Текст очищен: {len(cleaned_text)} символов")
        return cleaned_text
    
    async def analyze_pdf_structure(self, file_path: str) -> Dict[str, Any]:
        """Анализ структуры PDF документа"""
        
        logger.info(f"🔍 Анализ структуры PDF: {file_path}")
        
        def analyze():
            try:
                with pdfplumber.open(file_path) as pdf:
                    structure = {
                        "pages_count": len(pdf.pages),
                        "has_text": False,
                        "has_images": False,
                        "has_tables": False,
                        "text_density": 0,
                        "page_sizes": []
                    }
                    
                    total_chars = 0
                    total_area = 0
                    
                    for page in pdf.pages:
                        page_info = {
                            "width": page.width,
                            "height": page.height,
                            "area": page.width * page.height
                        }
                        structure["page_sizes"].append(page_info)
                        total_area += page_info["area"]
                        
                        # Проверяем наличие текста
                        text = page.extract_text()
                        if text and text.strip():
                            structure["has_text"] = True
                            total_chars += len(text.strip())
                        
                        # Проверяем таблицы
                        tables = page.extract_tables()
                        if tables:
                            structure["has_tables"] = True
                        
                        # Проверяем изображения
                        images = page.images
                        if images:
                            structure["has_images"] = True
                    
                    # Плотность текста (символов на единицу площади)
                    if total_area > 0:
                        structure["text_density"] = total_chars / total_area
                    
                    return structure
                    
            except Exception as e:
                logger.error(f"Ошибка анализа структуры: {e}")
                return {"error": str(e)}
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, analyze)
    
    async def extract_tables(self, file_path: str) -> List[List[List[str]]]:
        """Извлечение таблиц из PDF"""
        
        logger.info(f"📊 Извлечение таблиц из PDF: {file_path}")
        
        def extract():
            all_tables = []
            try:
                with pdfplumber.open(file_path) as pdf:
                    for page_num, page in enumerate(pdf.pages):
                        tables = page.extract_tables()
                        if tables:
                            logger.info(f"Найдено {len(tables)} таблиц на странице {page_num + 1}")
                            all_tables.extend(tables)
                
                return all_tables
                
            except Exception as e:
                logger.error(f"Ошибка извлечения таблиц: {e}")
                return []
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, extract)
    
    async def validate_pdf(self, file_path: str) -> Dict[str, Any]:
        """Валидация PDF файла"""
        
        logger.info(f"✅ Валидация PDF: {file_path}")
        
        validation = {
            "is_valid": False,
            "file_size": 0,
            "is_readable": False,
            "is_encrypted": False,
            "pages_count": 0,
            "errors": []
        }
        
        try:
            # Проверяем размер файла
            if os.path.exists(file_path):
                validation["file_size"] = os.path.getsize(file_path)
            else:
                validation["errors"].append("Файл не найден")
                return validation
            
            # Пробуем открыть файл
            def validate():
                try:
                    with pdfplumber.open(file_path) as pdf:
                        validation["pages_count"] = len(pdf.pages)
                        validation["is_valid"] = True
                        
                        # Проверяем, можно ли извлечь текст
                        if pdf.pages:
                            first_page_text = pdf.pages[0].extract_text()
                            if first_page_text and first_page_text.strip():
                                validation["is_readable"] = True
                    
                    return validation
                    
                except Exception as e:
                    validation["errors"].append(f"Ошибка открытия PDF: {e}")
                    
                    # Попробуем альтернативный метод
                    try:
                        doc = fitz.open(file_path)
                        validation["pages_count"] = len(doc)
                        validation["is_encrypted"] = doc.needs_pass
                        validation["is_valid"] = True
                        doc.close()
                    except Exception as e2:
                        validation["errors"].append(f"Критическая ошибка PDF: {e2}")
                    
                    return validation
            
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, validate)
            
        except Exception as e:
            validation["errors"].append(f"Общая ошибка валидации: {e}")
            return validation
    
    def cleanup_temp_files(self, older_than_hours: int = 24):
        """Очистка временных файлов"""
        
        import time
        
        logger.info(f"🧹 Очистка временных файлов старше {older_than_hours} часов")
        
        current_time = time.time()
        cutoff_time = current_time - (older_than_hours * 3600)
        
        deleted_count = 0
        
        for file_path in self.temp_dir.glob("*"):
            if file_path.is_file():
                file_time = file_path.stat().st_mtime
                if file_time < cutoff_time:
                    try:
                        file_path.unlink()
                        deleted_count += 1
                    except Exception as e:
                        logger.warning(f"Не удалось удалить {file_path}: {e}")
        
        logger.info(f"✅ Удалено {deleted_count} временных файлов")


# Глобальный экземпляр сервиса
pdf_service = PDFService()