"""
Сервис для обработки платежей через YooKassa
"""

import uuid
import logging
from typing import Optional, Dict, Any
from datetime import datetime, timedelta

try:
    from yookassa import Configuration, Payment
    from yookassa.domain.exceptions import ApiError
    YOOKASSA_AVAILABLE = True
except ImportError:
    YOOKASSA_AVAILABLE = False
    
from config import settings
from database.connection import save_payment, update_payment_status, get_payment_info, grant_subscription

logger = logging.getLogger(__name__)


class PaymentService:
    """Сервис для работы с платежами YooKassa"""
    
    def __init__(self):
        if not YOOKASSA_AVAILABLE:
            logger.error("YooKassa SDK не установлен. Установите: pip install yookassa")
            return
            
        # Настройка YooKassa
        Configuration.account_id = settings.yookassa_shop_id
        Configuration.secret_key = settings.yookassa_api_key
        
        logger.info("💳 YooKassa сервис инициализирован")
    
    async def create_subscription_payment(self, user_id: int, subscription_type: str = "monthly") -> Dict[str, Any]:
        """Создать платеж за подписку"""
        
        if not YOOKASSA_AVAILABLE:
            raise Exception("YooKassa SDK не доступен")
        
        # Генерируем уникальный ID платежа
        payment_id = str(uuid.uuid4())
        
        try:
            # Создаем платеж в YooKassa
            payment = Payment.create({
                "amount": {
                    "value": str(settings.subscription_price),
                    "currency": "RUB"
                },
                "confirmation": {
                    "type": "redirect",
                    "return_url": f"https://t.me/gkhkontrol_bot?start=payment_{payment_id}"
                },
                "capture": True,
                "description": f"Подписка ЖКХ Контроль - {subscription_type}",
                "metadata": {
                    "user_id": str(user_id),
                    "subscription_type": subscription_type,
                    "internal_payment_id": payment_id
                }
            }, payment_id)
            
            # Сохраняем платеж в базе данных
            await save_payment(
                user_id=user_id,
                payment_id=payment_id,
                amount=settings.subscription_price,
                subscription_type=subscription_type
            )
            
            logger.info(f"💳 Создан платеж {payment_id} для пользователя {user_id}")            
            return {
                "payment_id": payment_id,
                "yookassa_payment_id": payment.id,
                "confirmation_url": payment.confirmation.confirmation_url,
                "amount": settings.subscription_price,
                "status": payment.status
            }
            
        except ApiError as e:
            logger.error(f"❌ Ошибка создания платежа YooKassa: {e}")
            raise Exception(f"Ошибка создания платежа: {e}")
        except Exception as e:
            logger.error(f"❌ Неожиданная ошибка создания платежа: {e}")
            raise
    
    async def check_payment_status(self, payment_id: str) -> Dict[str, Any]:
        """Проверить статус платежа"""
        
        if not YOOKASSA_AVAILABLE:
            raise Exception("YooKassa SDK не доступен")
        
        try:
            # Получаем информацию о платеже из базы
            payment_info = await get_payment_info(payment_id)
            if not payment_info:
                raise Exception(f"Платеж {payment_id} не найден в базе данных")
            
            # Получаем список платежей из YooKassa для поиска по metadata
            payments_list = Payment.list({
                "limit": 100
            })
            
            yookassa_payment = None
            for payment in payments_list.items:
                if (payment.metadata and 
                    payment.metadata.get("internal_payment_id") == payment_id):
                    yookassa_payment = payment
                    break
            
            if not yookassa_payment:
                logger.warning(f"Платеж {payment_id} не найден в YooKassa")
                return {"status": "not_found", "error": "Платеж не найден в системе YooKassa"}
            
            # Обновляем статус в базе данных
            if yookassa_payment.status == "succeeded":
                await update_payment_status(
                    payment_id=payment_id,
                    status="completed",
                    yookassa_payment_id=yookassa_payment.id
                )
                
                # Выдаем подписку пользователю
                await grant_subscription(
                    telegram_id=payment_info["user_id"],
                    subscription_type=payment_info["subscription_type"],
                    days=30
                )
                
                logger.info(f"✅ Платеж {payment_id} успешно завершен")
                
            elif yookassa_payment.status in ["canceled", "failed"]:
                error_message = "Платеж отменен или неуспешен"
                await update_payment_status(
                    payment_id=payment_id,
                    status="failed",
                    error_message=error_message
                )
                
                logger.warning(f"❌ Платеж {payment_id} не прошел: {yookassa_payment.status}")
            
            return {
                "status": yookassa_payment.status,
                "amount": float(yookassa_payment.amount.value),
                "created_at": yookassa_payment.created_at.isoformat(),
                "paid": yookassa_payment.paid,
                "test": yookassa_payment.test
            }
            
        except ApiError as e:
            logger.error(f"❌ Ошибка проверки статуса платежа YooKassa: {e}")
            return {"status": "error", "error": str(e)}
        except Exception as e:
            logger.error(f"❌ Неожиданная ошибка проверки платежа: {e}")
            return {"status": "error", "error": str(e)}
    
    async def process_webhook(self, webhook_data: Dict[str, Any]) -> bool:
        """Обработать webhook от YooKassa"""
        
        try:
            event_type = webhook_data.get("event")
            payment_object = webhook_data.get("object")
            
            if not payment_object or event_type != "payment.succeeded":
                return False
            
            # Извлекаем internal_payment_id из metadata
            metadata = payment_object.get("metadata", {})
            internal_payment_id = metadata.get("internal_payment_id")
            
            if not internal_payment_id:
                logger.warning("Webhook без internal_payment_id в metadata")
                return False
            
            # Обновляем статус платежа
            await update_payment_status(
                payment_id=internal_payment_id,
                status="completed",
                yookassa_payment_id=payment_object.get("id")
            )
            
            # Получаем информацию о платеже и выдаем подписку
            payment_info = await get_payment_info(internal_payment_id)
            if payment_info:
                await grant_subscription(
                    telegram_id=payment_info["user_id"],
                    subscription_type=payment_info["subscription_type"],
                    days=30
                )
                
                logger.info(f"✅ Webhook обработан: подписка выдана пользователю {payment_info['user_id']}")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка обработки webhook: {e}")
            return False


# Глобальный экземпляр сервиса
payment_service = PaymentService()