# -*- coding: utf-8 -*-
"""
Расширенный сервис анализа квитанций ЖКХ с продвинутой аналитикой
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import asyncio

logger = logging.getLogger(__name__)

class AdvancedAnalysisService:
    """Сервис расширенного анализа коммунальных платежей"""
    
    def __init__(self):
        self.regional_standards = self._load_regional_standards()
        self.regulatory_contacts = self._load_regulatory_contacts()
        self.legal_templates = self._load_legal_templates()
    
    def _load_regional_standards(self) -> Dict[str, Dict[str, float]]:
        """Загрузка региональных стандартов тарифов"""
        # В реальном приложении это должно загружаться из базы данных или API
        return {
            "moscow": {
                "cold_water": 24.80,
                "hot_water": 164.20,
                "heating": 2750.0,
                "electricity_day": 6.85,
                "electricity_night": 2.45,
                "maintenance_per_m2": 42.80,
                "capital_repair_per_m2": 18.50
            },
            "spb": {
                "cold_water": 23.50,
                "hot_water": 158.90,
                "heating": 2650.0,
                "electricity_day": 6.45,
                "electricity_night": 2.25,
                "maintenance_per_m2": 39.60,
                "capital_repair_per_m2": 17.20
            }
        }
    
    def _load_regulatory_contacts(self) -> Dict[str, Dict[str, str]]:
        """Загрузка контактов надзорных органов"""
        return {
            "housing_inspection": {
                "name": "Государственная жилищная инспекция",
                "phone": "8-800-200-04-11",
                "email": "info@gzhi.mos.ru",
                "website": "https://www.mos.ru/gzhi/",
                "address": "Москва, ул. Садовая-Самотёчная, д. 11",
                "work_hours": "пн-чт: 8:00-17:00, пт: 8:00-15:45"
            },
            "energy_commission": {
                "name": "Региональная энергетическая комиссия",
                "phone": "8-495-633-63-33",
                "email": "info@rec.mos.ru",
                "website": "https://www.mos.ru/rec/",
                "address": "Москва, Бульварное кольцо, д. 11",
                "work_hours": "пн-чт: 9:00-18:00, пт: 9:00-16:45"
            }
        }
    
    def _load_legal_templates(self) -> Dict[str, str]:
        """Загрузка шаблонов правовых документов"""
        return {
            "complaint_template": """
ЖАЛОБА
на неправомерное начисление коммунальных платежей

В {regulatory_authority}
От: {consumer_name}
Адрес: {property_address}
Телефон: {phone}
Email: {email}

Прошу рассмотреть жалобу на неправомерные начисления по адресу: {property_address}

Суть нарушений:
{violations_list}

Правовые основания:
{legal_basis}

Требую:
1. Провести проверку правомерности начислений
2. Устранить выявленные нарушения
3. Произвести перерасчет с возвратом переплаты

Приложения:
- Копии квитанций
- Расчеты переплат
- Копии нормативных документов

Дата: {date}
Подпись: ________________
            """,
            "recalculation_request": """
ЗАЯВЛЕНИЕ
о перерасчете коммунальных платежей

В {management_company}
От собственника помещения: {consumer_name}
Адрес: {property_address}

На основании выявленных нарушений в начислении коммунальных платежей за период {billing_period}, прошу произвести перерасчет по следующим позициям:

{violations_details}

Общая сумма к перерасчету: {total_overcharge} рублей

Правовые основания: {legal_references}

Дата: {date}
Подпись: ________________
            """
        }
    
    async def generate_annual_forecast(self, analysis_result: Dict[str, Any], property_area: float) -> Dict[str, Any]:
        """Генерация годового прогноза расходов"""
        logger.info("🔮 Генерация годового прогноза расходов")
        
        services = analysis_result.get('services', [])
        violations = analysis_result.get('violations', [])
        
        # Базовые месячные расходы
        monthly_base = sum(service.get('amount', 0) for service in services)
        
        # Сезонные коэффициенты
        seasonal_factors = {
            'heating': [1.8, 1.6, 1.2, 0.8, 0.3, 0.0, 0.0, 0.0, 0.4, 1.0, 1.4, 1.7],
            'electricity': [1.2, 1.1, 1.0, 0.9, 0.9, 1.1, 1.3, 1.2, 1.0, 1.0, 1.1, 1.2],
            'water': [1.0, 1.0, 1.0, 1.0, 1.1, 1.2, 1.3, 1.2, 1.1, 1.0, 1.0, 1.0]
        }
        
        monthly_projections = []
        annual_total = 0
        
        for month in range(12):
            month_total = 0
            month_services = {}
            
            for service in services:
                service_name = service.get('name', '').lower()
                base_amount = service.get('amount', 0)
                
                # Применение сезонного коэффициента
                if 'отопление' in service_name or 'тепло' in service_name:
                    factor = seasonal_factors['heating'][month]
                elif 'электр' in service_name:
                    factor = seasonal_factors['electricity'][month]
                elif 'вода' in service_name:
                    factor = seasonal_factors['water'][month]
                else:
                    factor = 1.0
                
                projected_amount = base_amount * factor
                month_total += projected_amount
                month_services[service_name] = projected_amount
            
            monthly_projections.append({
                'month': month + 1,
                'month_name': self._get_month_name(month + 1),
                'total_amount': month_total,
                'services': month_services
            })
            annual_total += month_total
        
        # Расчет экономии при устранении нарушений
        monthly_violations_cost = sum(v.get('amount', 0) for v in violations)
        annual_violations_cost = monthly_violations_cost * 12
        potential_annual_savings = annual_violations_cost
        
        return {
            'annual_total': annual_total,
            'monthly_average': annual_total / 12,
            'monthly_projections': monthly_projections,
            'potential_annual_savings': potential_annual_savings,
            'cost_per_m2_annual': annual_total / property_area if property_area > 0 else 0
        }
    
    async def analyze_peak_consumption(self, analysis_result: Dict[str, Any]) -> Dict[str, Any]:
        """Анализ пикового/непикового потребления электроэнергии"""
        logger.info("⚡ Анализ пикового потребления электроэнергии")
        
        services = analysis_result.get('services', [])
        electricity_services = [s for s in services if 'электр' in s.get('name', '').lower()]
        
        peak_analysis = {}
        
        for service in electricity_services:
            service_name = service.get('name', '')
            amount = service.get('amount', 0)
            
            # Определение типа тарифа
            if 'день' in service_name.lower() or 'дневной' in service_name.lower():
                tariff_type = 'peak'
                recommended_usage = "Используйте энергоемкие приборы в ночное время для экономии"
            elif 'ночь' in service_name.lower() or 'ночной' in service_name.lower():
                tariff_type = 'off_peak'
                recommended_usage = "Оптимальное время использования - действующий тариф"
            else:
                tariff_type = 'single'
                recommended_usage = "Рассмотрите переход на двухтарифный счетчик для экономии"
            
            peak_analysis[service_name] = {
                'tariff_type': tariff_type,
                'amount': amount,
                'recommendation': recommended_usage
            }
        
        # Расчет потенциальной экономии при оптимизации
        potential_savings = 0
        if len([s for s in peak_analysis.values() if s['tariff_type'] == 'peak']) > 0:
            peak_amount = sum(s['amount'] for s in peak_analysis.values() if s['tariff_type'] == 'peak')
            potential_savings = peak_amount * 0.3  # Примерно 30% экономии при переносе нагрузки
        
        return {
            'services_analysis': peak_analysis,
            'has_multi_tariff': len(peak_analysis) > 1,
            'potential_monthly_savings': potential_savings,
            'recommendations': self._generate_electricity_recommendations(peak_analysis)
        }
    
    def _get_month_name(self, month_num: int) -> str:
        """Получение названия месяца"""
        months = [
            'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
            'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
        ]
        return months[month_num - 1] if 1 <= month_num <= 12 else 'Неизвестно'
    
    def _generate_electricity_recommendations(self, peak_analysis: Dict) -> List[str]:
        """Генерация рекомендаций по электропотреблению"""
        recommendations = []
        
        if any(s['tariff_type'] == 'single' for s in peak_analysis.values()):
            recommendations.append("Установите двухтарифный счетчик для экономии на ночном тарифе")
        
        if any(s['tariff_type'] == 'peak' for s in peak_analysis.values()):
            recommendations.extend([
                "Используйте стиральную и посудомоечную машины в ночное время (23:00-7:00)",
                "Включайте водонагреватель на ночной тариф",
                "Заряжайте электронные устройства в период действия льготного тарифа"
            ])
        
        return recommendations
    
    async def calculate_cost_per_m2_comparison(self, analysis_result: Dict[str, Any], 
                                            property_area: float, region: str = "moscow") -> Dict[str, Any]:
        """Расчет стоимости за квадратный метр в сравнении с региональными стандартами"""
        logger.info("📏 Расчет стоимости за м² в сравнении с региональными стандартами")
        
        if property_area <= 0:
            return {'error': 'Площадь помещения не указана или некорректна'}
        
        services = analysis_result.get('services', [])
        total_cost = sum(service.get('amount', 0) for service in services)
        cost_per_m2 = total_cost / property_area
        
        regional_data = self.regional_standards.get(region, self.regional_standards["moscow"])
        regional_total_per_m2 = sum(regional_data.values()) / len(regional_data)
        
        comparison_result = {
            'current_cost_per_m2': cost_per_m2,
            'regional_average_per_m2': regional_total_per_m2,
            'difference_per_m2': cost_per_m2 - regional_total_per_m2,
            'difference_percentage': ((cost_per_m2 - regional_total_per_m2) / regional_total_per_m2 * 100) if regional_total_per_m2 > 0 else 0,
            'annual_overcharge': (cost_per_m2 - regional_total_per_m2) * property_area * 12 if cost_per_m2 > regional_total_per_m2 else 0,
            'services_comparison': []
        }
        
        # Детальное сравнение по услугам
        for service in services:
            service_name = service.get('name', '').lower()
            service_amount = service.get('amount', 0)
            service_cost_per_m2 = service_amount / property_area
            
            regional_standard = self._match_service_to_standard(service_name, regional_data)
            if regional_standard:
                comparison_result['services_comparison'].append({
                    'service_name': service.get('name', ''),
                    'current_per_m2': service_cost_per_m2,
                    'regional_per_m2': regional_standard,
                    'difference_per_m2': service_cost_per_m2 - regional_standard,
                    'compliance': 'compliant' if service_cost_per_m2 <= regional_standard * 1.05 else 'violation'
                })
        
        return comparison_result
    
    async def calculate_energy_saving_roi(self, analysis_result: Dict[str, Any], 
                                        property_area: float) -> Dict[str, Any]:
        """ROI расчеты для потенциальных энергосберегающих улучшений"""
        logger.info("💰 Расчет ROI энергосберегающих улучшений")
        
        services = analysis_result.get('services', [])
        violations = analysis_result.get('violations', [])
        
        improvements = [
            {
                'name': 'Установка индивидуальных счетчиков тепла',
                'investment_cost': 25000,
                'annual_savings': 8000,
                'payback_years': 3.1,
                'applicable_services': ['отопление'],
                'description': 'Позволяет контролировать потребление тепла и платить только за фактическое потребление'
            },
            {
                'name': 'Замена на энергоэффективные окна',
                'investment_cost': 45000,
                'annual_savings': 12000,
                'payback_years': 3.8,
                'applicable_services': ['отопление', 'электричество'],
                'description': 'Снижение теплопотерь до 30%, экономия на отоплении и кондиционировании'
            },
            {
                'name': 'Установка двухтарифного счетчика электроэнергии',
                'investment_cost': 3500,
                'annual_savings': 2400,
                'payback_years': 1.5,
                'applicable_services': ['электричество'],
                'description': 'Экономия до 30% на электроэнергии при использовании ночного тарифа'
            }
        ]
        
        # Расчет ROI с учетом текущих нарушений
        current_annual_overpayment = sum(v.get('amount', 0) for v in violations) * 12
        
        roi_analysis = []
        for improvement in improvements:
            # Расчет применимости улучшения
            applicable = any(
                any(service_type in service.get('name', '').lower() 
                    for service_type in improvement['applicable_services'])
                for service in services
            )
            
            if applicable:
                # Учет дополнительной экономии от устранения нарушений
                additional_savings = current_annual_overpayment * 0.1  # 10% дополнительной экономии
                total_annual_savings = improvement['annual_savings'] + additional_savings
                
                roi_data = {
                    'name': improvement['name'],
                    'description': improvement['description'],
                    'investment_cost': improvement['investment_cost'],
                    'annual_savings': total_annual_savings,
                    'payback_years': improvement['investment_cost'] / total_annual_savings if total_annual_savings > 0 else float('inf'),
                    'roi_percentage': (total_annual_savings / improvement['investment_cost'] * 100) if improvement['investment_cost'] > 0 else 0,
                    '10_year_profit': total_annual_savings * 10 - improvement['investment_cost'],
                    'priority': self._calculate_priority(improvement['investment_cost'], total_annual_savings)
                }
                roi_analysis.append(roi_data)
        
        # Сортировка по приоритету (ROI)
        roi_analysis.sort(key=lambda x: x['roi_percentage'], reverse=True)
        
        return {
            'improvements': roi_analysis,
            'total_potential_investment': sum(imp['investment_cost'] for imp in roi_analysis),
            'total_potential_annual_savings': sum(imp['annual_savings'] for imp in roi_analysis),
            'recommended_improvements': [imp for imp in roi_analysis if imp['payback_years'] <= 3],
            'current_annual_overpayment': current_annual_overpayment
        }
    
    async def get_regulatory_information(self, region: str = "moscow") -> Dict[str, Any]:
        """Получение информации о датах утверждения тарифов и регулирующих органах"""
        logger.info("📋 Получение регулятивной информации")
        
        # В реальном приложении это должно загружаться из официальных источников
        regulatory_info = {
            'tariff_approval_dates': {
                'cold_water': '01.01.2024',
                'hot_water': '01.01.2024', 
                'heating': '15.10.2023',
                'electricity': '01.07.2023',
                'maintenance': '01.01.2024',
                'capital_repair': '01.01.2024'
            },
            'regulatory_authorities': {
                'water_heating': 'Региональная энергетическая комиссия города Москвы',
                'electricity': 'Федеральная антимонопольная служба России',
                'maintenance': 'Департамент жилищно-коммунального хозяйства города Москвы'
            },
            'legal_documents': {
                'water_heating': 'Постановление РЭК Москвы от 15.12.2023 № 234-пп',
                'electricity': 'Приказ ФАС России от 29.06.2023 № 756/23',
                'maintenance': 'Постановление Правительства Москвы от 25.12.2023 № 1587-ПП'
            },
            'contacts': self.regulatory_contacts,
            'consumer_rights': {
                'dispute_procedures': [
                    'Обращение в управляющую компанию с письменной претензией',
                    'Подача жалобы в государственную жилищную инспекцию',
                    'Обращение в Роспотребнадзор',
                    'Судебное разбирательство при превышении суммы спора 50 000 рублей'
                ],
                'legal_basis': [
                    'Жилищный кодекс РФ, статья 154',
                    'Постановление Правительства РФ № 354 от 06.05.2011',
                    'Федеральный закон "О защите прав потребителей"',
                    'Постановление Правительства РФ № 1498 от 13.08.2006'
                ],
                'deadlines': {
                    'complaint_response': '30 дней с момента подачи жалобы',
                    'recalculation_period': '6 месяцев с момента выявления нарушения',
                    'lawsuit_limitation': '3 года с момента нарушения прав'
                }
            }
        }
        
        return regulatory_info
    
    def _match_service_to_standard(self, service_name: str, regional_data: Dict[str, float]) -> Optional[float]:
        """Сопоставление услуги с региональным стандартом"""
        service_name = service_name.lower()
        
        if 'холодн' in service_name and 'вода' in service_name:
            return regional_data.get('cold_water')
        elif 'горяч' in service_name and 'вода' in service_name:
            return regional_data.get('hot_water')
        elif 'отопление' in service_name or 'тепло' in service_name:
            return regional_data.get('heating')
        elif 'электр' in service_name and ('день' in service_name or 'дневной' in service_name):
            return regional_data.get('electricity_day')
        elif 'электр' in service_name and ('ночь' in service_name or 'ночной' in service_name):
            return regional_data.get('electricity_night')
        elif 'содержан' in service_name or 'управление' in service_name:
            return regional_data.get('maintenance_per_m2')
        elif 'капремонт' in service_name or 'капитальный' in service_name:
            return regional_data.get('capital_repair_per_m2')
        
        return None
    
    def _calculate_priority(self, investment: float, annual_savings: float) -> str:
        """Расчет приоритета инвестиции"""
        if annual_savings <= 0:
            return 'Низкий'
        
        payback = investment / annual_savings
        roi = (annual_savings / investment) * 100
        
        if payback <= 2 and roi >= 50:
            return 'Высокий'
        elif payback <= 3 and roi >= 30:
            return 'Средний'
        else:
            return 'Низкий'
    
    async def detect_advanced_violations(self, analysis_result: Dict[str, Any], 
                                       property_area: float, 
                                       historical_data: Optional[List[Dict]] = None) -> Dict[str, Any]:
        """Продвинутое выявление нарушений с перекрестной валидацией"""
        logger.info("🔍 Продвинутое выявление нарушений")
        
        services = analysis_result.get('services', [])
        violations = analysis_result.get('violations', [])
        
        advanced_violations = {
            'cross_validation_violations': [],
            'consumption_anomalies': [],
            'meter_malfunction_indicators': [],
            'double_charging': [],
            'unauthorized_charges': [],
            'confidence_scores': {}
        }
        
        # Перекрестная валидация услуг
        heating_consumption = self._extract_service_data(services, 'отопление')
        electricity_consumption = self._extract_service_data(services, 'электр')
        
        if heating_consumption and electricity_consumption:
            # Корреляционный анализ отопления и электричества
            correlation_issue = self._analyze_heating_electricity_correlation(
                heating_consumption, electricity_consumption, property_area
            )
            if correlation_issue:
                advanced_violations['cross_validation_violations'].append(correlation_issue)
        
        # Обнаружение аномалий потребления
        if historical_data:
            anomalies = self._detect_consumption_anomalies(services, historical_data)
            advanced_violations['consumption_anomalies'].extend(anomalies)
        
        # Индикаторы неисправности счетчиков
        meter_issues = self._detect_meter_malfunctions(services, property_area)
        advanced_violations['meter_malfunction_indicators'].extend(meter_issues)
        
        # Выявление двойных начислений
        double_charges = self._detect_double_charging(services)
        advanced_violations['double_charging'].extend(double_charges)
        
        # Обнаружение несанкционированных платежей
        unauthorized = self._detect_unauthorized_charges(services)
        advanced_violations['unauthorized_charges'].extend(unauthorized)
        
        # Расчет уверенности для каждого нарушения
        for violation in violations:
            confidence = self._calculate_violation_confidence(violation, services, property_area)
            advanced_violations['confidence_scores'][violation.get('description', 'Unknown')] = confidence
        
        return advanced_violations
    
    async def generate_documentation_package(self, analysis_result: Dict[str, Any], 
                                           property_info: Dict[str, str]) -> Dict[str, str]:
        """Генерация пакета документации для споров"""
        logger.info("📄 Генерация пакета документации")
        
        violations = analysis_result.get('violations', [])
        regulatory_info = await self.get_regulatory_information()
        
        # Заполнение шаблона жалобы
        complaint = self._fill_complaint_template(violations, property_info, regulatory_info)
        
        # Генерация заявления на перерасчет
        recalculation_request = self._fill_recalculation_template(violations, property_info)
        
        # Сводка доказательств
        evidence_summary = self._generate_evidence_summary(violations, analysis_result)
        
        # Расчетные листы
        calculation_sheets = self._generate_calculation_sheets(violations, analysis_result)
        
        return {
            'complaint_template': complaint,
            'recalculation_request': recalculation_request,
            'evidence_summary': evidence_summary,
            'calculation_sheets': calculation_sheets,
            'regulatory_references': self._format_regulatory_references(regulatory_info)
        }
    
    def _extract_service_data(self, services: List[Dict], service_type: str) -> Optional[Dict]:
        """Извлечение данных о конкретной услуге"""
        for service in services:
            if service_type.lower() in service.get('name', '').lower():
                return service
        return None
    
    def _analyze_heating_electricity_correlation(self, heating: Dict, electricity: Dict, area: float) -> Optional[Dict]:
        """Анализ корреляции отопления и электричества"""
        heating_per_m2 = heating.get('amount', 0) / area if area > 0 else 0
        electricity_total = electricity.get('amount', 0)
        
        # Если отопление слишком дешевое, а электричество дорогое - возможно отопление электричеством
        if heating_per_m2 < 50 and electricity_total > 2000:  # Примерные пороги
            return {
                'type': 'heating_electricity_correlation',
                'description': 'Подозрительная корреляция: дешевое отопление при дорогом электричестве',
                'details': f'Отопление: {heating_per_m2:.2f} руб/м², Электричество: {electricity_total} руб',
                'confidence': 0.7
            }
        return None
    
    def _detect_consumption_anomalies(self, services: List[Dict], historical_data: List[Dict]) -> List[Dict]:
        """Обнаружение аномалий потребления"""
        anomalies = []
        # В реальном приложении здесь будет сложный анализ исторических данных
        return anomalies
    
    def _detect_meter_malfunctions(self, services: List[Dict], area: float) -> List[Dict]:
        """Индикаторы неисправности счетчиков"""
        issues = []
        # В реальном приложении здесь будет анализ показаний счетчиков
        return issues
    
    def _detect_double_charging(self, services: List[Dict]) -> List[Dict]:
        """Выявление двойных начислений"""
        double_charges = []
        service_names = [s.get('name', '').lower() for s in services]
        
        # Проверка на дублирование услуг
        seen_services = set()
        for service in services:
            service_name = service.get('name', '').lower()
            if service_name in seen_services:
                double_charges.append({
                    'type': 'double_charging',
                    'description': f'Повторное начисление за услугу: {service.get("name")}',
                    'confidence': 0.9
                })
            seen_services.add(service_name)
        
        return double_charges
    
    def _detect_unauthorized_charges(self, services: List[Dict]) -> List[Dict]:
        """Обнаружение несанкционированных платежей"""
        unauthorized = []
        suspicious_services = ['штраф', 'пени', 'комиссия', 'обслуживание']
        
        for service in services:
            service_name = service.get('name', '').lower()
            if any(suspicious in service_name for suspicious in suspicious_services):
                unauthorized.append({
                    'type': 'unauthorized_charge',
                    'description': f'Потенциально несанкционированное начисление: {service.get("name")}',
                    'confidence': 0.6
                })
        
        return unauthorized
    
    def _calculate_violation_confidence(self, violation: Dict, services: List[Dict], area: float) -> float:
        """Расчет уверенности в нарушении"""
        # В реальном приложении здесь будет сложный алгоритм расчета
        base_confidence = 0.8
        return min(base_confidence + 0.1, 1.0)  # Примерный расчет
    
    def _fill_complaint_template(self, violations: List[Dict], property_info: Dict[str, str], 
                               regulatory_info: Dict[str, Any]) -> str:
        """Заполнение шаблона жалобы"""
        violations_list = "\n".join([f"- {v.get('description', '')}" for v in violations])
        legal_basis = "\n".join(regulatory_info['consumer_rights']['legal_basis'])
        
        complaint = self.legal_templates['complaint_template'].format(
            regulatory_authority=regulatory_info['regulatory_authorities']['water_heating'],
            consumer_name=property_info.get('consumer_name', 'Иванов И.И.'),
            property_address=property_info.get('property_address', 'г. Москва, ул. Примерная, д. 1, кв. 1'),
            phone=property_info.get('phone', '+7 (XXX) XXX-XX-XX'),
            email=property_info.get('email', 'example@email.com'),
            violations_list=violations_list,
            legal_basis=legal_basis,
            date=datetime.now().strftime("%d.%m.%Y")
        )
        
        return complaint
    
    def _fill_recalculation_template(self, violations: List[Dict], property_info: Dict[str, str]) -> str:
        """Заполнение шаблона заявления на перерасчет"""
        violations_details = "\n".join([
            f"- {v.get('description', '')}: {v.get('amount', 0)} руб." 
            for v in violations
        ])
        total_overcharge = sum(v.get('amount', 0) for v in violations)
        
        recalculation = self.legal_templates['recalculation_request'].format(
            management_company=property_info.get('management_company', 'УК "Примерная"'),
            consumer_name=property_info.get('consumer_name', 'Иванов И.И.'),
            property_address=property_info.get('property_address', 'г. Москва, ул. Примерная, д. 1, кв. 1'),
            billing_period=property_info.get('billing_period', 'январь 2024'),
            violations_details=violations_details,
            total_overcharge=total_overcharge,
            legal_references="Жилищный кодекс РФ, статья 154",
            date=datetime.now().strftime("%d.%m.%Y")
        )
        
        return recalculation
    
    def _generate_evidence_summary(self, violations: List[Dict], analysis_result: Dict[str, Any]) -> str:
        """Генерация сводки доказательств"""
        summary = "СВОДКА ДОКАЗАТЕЛЬСТВ НАРУШЕНИЙ\n\n"
        summary += f"Общее количество выявленных нарушений: {len(violations)}\n"
        summary += f"Общая сумма переплаты: {sum(v.get('amount', 0) for v in violations)} руб.\n\n"
        
        for i, violation in enumerate(violations, 1):
            summary += f"{i}. {violation.get('description', 'Нарушение')}\n"
            summary += f"   Сумма переплаты: {violation.get('amount', 0)} руб.\n"
            summary += f"   Уровень достоверности: {violation.get('confidence', 0.8) * 100}%\n\n"
        
        return summary
    
    def _generate_calculation_sheets(self, violations: List[Dict], analysis_result: Dict[str, Any]) -> str:
        """Генерация расчетных листов"""
        sheets = "РАСЧЕТНЫЕ ЛИСТЫ\n\n"
        
        for violation in violations:
            sheets += f"Нарушение: {violation.get('description', 'Не указано')}\n"
            sheets += f"Расчет переплаты: {violation.get('amount', 0)} руб.\n"
            sheets += "Формула расчета: (Фактический тариф - Нормативный тариф) * Объем потребления\n"
            sheets += "---\n\n"
        
        return sheets
    
    def _format_regulatory_references(self, regulatory_info: Dict[str, Any]) -> str:
        """Форматирование регулятивных ссылок"""
        references = "РЕГУЛЯТИВНЫЕ ССЫЛКИ\n\n"
        
        references += "Даты утверждения тарифов:\n"
        for service, date in regulatory_info['tariff_approval_dates'].items():
            references += f"- {service}: {date}\n"
        
        references += "\nПравовые документы:\n"
        for service, doc in regulatory_info['legal_documents'].items():
            references += f"- {service}: {doc}\n"
        
        return references
