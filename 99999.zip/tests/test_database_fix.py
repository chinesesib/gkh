#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test to verify the database connection fix in analysis_service.py
"""

import asyncio
import sys
import os

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.analysis_service import analysis_service


async def test_database_connection():
    """Test that the database connection works properly"""
    print("🔍 Testing database connection fix...")
    
    try:
        # Test getting analysis history (this will use the fixed database connection)
        history = await analysis_service.get_analysis_history(12345, 5)
        print(f"✅ Database connection successful. Found {len(history)} analyses in history")
        return True
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return False


async def main():
    print("🚀 Testing database connection fix in analysis_service.py\n")
    
    success = await test_database_connection()
    
    if success:
        print("\n✅ Database connection fix verified successfully!")
    else:
        print("\n❌ Database connection fix verification failed!")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())