# -*- coding: utf-8 -*-
"""
Тесты для расширенного анализа квитанций ЖКХ
"""

import sys
import os
import asyncio

# Добавляем путь к проекту
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from services.advanced_analysis_service import AdvancedAnalysisService

async def test_advanced_analysis():
    """Тестирование расширенного анализа"""
    
    # Создаем сервис
    service = AdvancedAnalysisService()
    
    # Тестовые данные
    analysis_result = {
        'violations': [
            {'type': 'Превышение тарифа', 'amount': 127.50, 'description': 'Тариф отопления превышает норматив'},
            {'type': 'Необоснованная плата', 'amount': 85.30, 'description': 'Необоснованная плата за содержание'}
        ],
        'services': [
            {'name': 'Отопление', 'amount': 2450.30, 'is_violation': True},
            {'name': 'Холодная вода', 'amount': 567.80, 'is_violation': True},
            {'name': 'Электроэнергия', 'amount': 1876.20, 'is_violation': False}
        ],
        'financial_analysis': {
            'monthly_overpayment': 435.20,
            'yearly_overpayment': 5222.40
        }
    }
    
    property_info = {
        'area': 65.5,
        'region': 'moscow',
        'consumer_name': 'Иванов И.И.',
        'property_address': 'г. Москва, ул. Примерная, д. 1, кв. 1'
    }
    
    print("🚀 Тестирование расширенного анализа квитанций ЖКХ")
    
    # Тест 1: Годовой прогноз расходов
    print("\n🔮 Тест 1: Генерация годового прогноза расходов")
    annual_forecast = await service.generate_annual_forecast(analysis_result, property_info['area'])
    print(f"   Годовой прогноз: {annual_forecast['annual_total']:.2f} ₽")
    print(f"   Среднемесячный прогноз: {annual_forecast['monthly_average']:.2f} ₽")
    
    # Тест 2: Анализ пикового потребления
    print("\n⚡ Тест 2: Анализ пикового потребления электроэнергии")
    peak_analysis = await service.analyze_peak_consumption(analysis_result)
    print(f"   Наличие многотарифного учета: {peak_analysis['has_multi_tariff']}")
    print(f"   Потенциальная экономия: {peak_analysis['potential_monthly_savings']:.2f} ₽")
    
    # Тест 3: Сравнение стоимости за м²
    print("\n📏 Тест 3: Сравнение стоимости за м² с региональными стандартами")
    cost_per_m2 = await service.calculate_cost_per_m2_comparison(
        analysis_result, property_info['area'], property_info['region'])
    print(f"   Текущая стоимость за м²: {cost_per_m2['current_cost_per_m2']:.2f} ₽")
    print(f"   Региональная стоимость за м²: {cost_per_m2['regional_average_per_m2']:.2f} ₽")
    print(f"   Разница: {cost_per_m2['difference_per_m2']:.2f} ₽")
    
    # Тест 4: ROI энергосберегающих улучшений
    print("\n💰 Тест 4: Расчет ROI энергосберегающих улучшений")
    roi_analysis = await service.calculate_energy_saving_roi(analysis_result, property_info['area'])
    print(f"   Всего рекомендованных улучшений: {len(roi_analysis['recommended_improvements'])}")
    if roi_analysis['recommended_improvements']:
        best_improvement = roi_analysis['recommended_improvements'][0]
        print(f"   Лучшее улучшение: {best_improvement['name']}")
        print(f"   ROI: {best_improvement['roi_percentage']:.1f}%")
        print(f"   Окупаемость: {best_improvement['payback_years']:.1f} лет")
    
    # Тест 5: Регулятивная информация
    print("\n📋 Тест 5: Получение регулятивной информации")
    regulatory_info = await service.get_regulatory_information(property_info['region'])
    print(f"   Контактов регуляторов: {len(regulatory_info['contacts'])}")
    print(f"   Правовых оснований: {len(regulatory_info['consumer_rights']['legal_basis'])}")
    
    # Тест 6: Продвинутое выявление нарушений
    print("\n🔍 Тест 6: Продвинутое выявление нарушений")
    advanced_violations = await service.detect_advanced_violations(analysis_result, property_info['area'])
    total_advanced_violations = sum(len(v) for v in advanced_violations.values() if isinstance(v, list))
    print(f"   Найдено продвинутых нарушений: {total_advanced_violations}")
    
    # Тест 7: Генерация документации
    print("\n📄 Тест 7: Генерация пакета документации")
    documentation = await service.generate_documentation_package(analysis_result, property_info)
    print(f"   Шаблонов в пакете: {len(documentation)}")
    print(f"   Длина шаблона жалобы: {len(documentation['complaint_template'])} символов")
    
    print("\n✅ Все тесты пройдены успешно!")

if __name__ == "__main__":
    asyncio.run(test_advanced_analysis())