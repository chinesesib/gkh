#!/usr/bin/env python3
"""
Test script to verify admin functionality
"""

import asyncio
import sys
import os

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database.connection import database, is_user_admin, get_all_users

async def test_admin_functionality():
    """Test admin functionality"""
    print("Testing admin functionality...")
    
    try:
        # Initialize the database
        await database.init_database()
        print("✅ Database initialized")
        
        # Test if user 1043893977 is admin
        is_admin = await is_user_admin(1043893977)
        print(f"User 1043893977 is admin: {is_admin}")
        
        # Test getting all users
        all_users = await get_all_users()
        print(f"Total users: {len(all_users)}")
        print(f"First 5 users: {all_users[:5]}")
        
        print("✅ Admin functionality test completed!")
        
    except Exception as e:
        print(f"❌ Error testing admin functionality: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(test_admin_functionality())