#!/usr/bin/env python3
"""
Скрипт для проверки и исправления схемы базы данных
"""

import asyncio
import aiosqlite
import logging
from pathlib import Path
from database.connection import database

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def check_and_fix_database():
    """Проверить и исправить схему базы данных"""
    
    # Используем тот же путь к БД, что и основное приложение
    db_path = database.db_path
    
    if not Path(db_path).exists():
        logger.warning(f"⚠️ База данных {db_path} не найдена, будет создана при подключении")
    
    logger.info(f"📋 Проверяем базу данных: {db_path}")
    
    async with aiosqlite.connect(db_path) as db:
        # Проверяем текущую схему таблицы users
        cursor = await db.execute("PRAGMA table_info(users)")
        columns = await cursor.fetchall()
        
        logger.info("📊 Текущие колонки в таблице users:")
        has_is_admin = False
        for column in columns:
            logger.info(f"  - {column[1]} ({column[2]})")
            if column[1] == 'is_admin':
                has_is_admin = True
        
        if not has_is_admin:
            logger.info("⚠️ Колонка is_admin отсутствует, добавляем...")
            try:
                await db.execute("ALTER TABLE users ADD COLUMN is_admin BOOLEAN DEFAULT FALSE")
                await db.commit()
                logger.info("✅ Колонка is_admin успешно добавлена!")
            except Exception as e:
                logger.error(f"❌ Ошибка при добавлении колонки: {e}")
        else:
            logger.info("✅ Колонка is_admin уже существует")
        
        # Проверяем текущую схему таблицы analyses
        cursor = await db.execute("PRAGMA table_info(analyses)")
        analyses_columns = await cursor.fetchall()
        
        logger.info("📊 Текущие колонки в таблице analyses:")
        existing_cols = {col[1]: col[2] for col in analyses_columns}
        for name, ctype in existing_cols.items():
            logger.info(f"  - {name} ({ctype})")

        async def add_column_if_missing(name: str, ddl: str):
            if name not in existing_cols:
                logger.info(f"⚠️ Колонка {name} отсутствует, добавляем...")
                try:
                    await db.execute(f"ALTER TABLE analyses ADD COLUMN {ddl}")
                    logger.info(f"✅ Колонка {name} добавлена")
                except Exception as e:
                    logger.error(f"❌ Ошибка при добавлении колонки {name}: {e}")

        # Колонки, ожидаемые кодом (services/analysis_service.py, database/connection.py)
        # SQLite запрещает добавлять колонку с неконстантным значением по умолчанию
        # Поэтому добавляем без DEFAULT, а затем делаем апдейт значений отдельно
        await add_column_if_missing('analysis_started_at', 'analysis_started_at DATETIME')
        await add_column_if_missing('analysis_completed_at', 'analysis_completed_at DATETIME')
        await add_column_if_missing('analysis_duration', 'analysis_duration REAL')
        await add_column_if_missing('violations_count', 'violations_count INTEGER DEFAULT 0')
        await add_column_if_missing('total_overpayment', 'total_overpayment REAL DEFAULT 0')
        await add_column_if_missing('status', "status TEXT DEFAULT 'processing'")
        await add_column_if_missing('result_json', 'result_json TEXT')
        await add_column_if_missing('error_message', 'error_message TEXT')
        await add_column_if_missing('cached', 'cached BOOLEAN DEFAULT FALSE')

        # Пробуем перенести данные из старых колонок, если они были
        try:
            # Обновляем словарь колонок после возможного добавления
            cursor = await db.execute("PRAGMA table_info(analyses)")
            existing_cols = {col[1]: col[2] for col in await cursor.fetchall()}

            # created_at -> analysis_started_at
            if 'analysis_started_at' in existing_cols:
                if 'created_at' in existing_cols:
                    await db.execute("""
                        UPDATE analyses 
                        SET analysis_started_at = COALESCE(analysis_started_at, created_at)
                    """)
                else:
                    # Если created_at нет, заполним текущим временем там, где NULL
                    await db.execute("""
                        UPDATE analyses 
                        SET analysis_started_at = COALESCE(analysis_started_at, CURRENT_TIMESTAMP)
                    """)
            # completed_at -> analysis_completed_at
            if 'completed_at' in existing_cols:
                await db.execute("""
                    UPDATE analyses 
                    SET analysis_completed_at = COALESCE(analysis_completed_at, completed_at)
                """)
            # duration_seconds -> analysis_duration
            if 'duration_seconds' in existing_cols:
                await db.execute("""
                    UPDATE analyses 
                    SET analysis_duration = COALESCE(analysis_duration, duration_seconds)
                """)
        except Exception as e:
            logger.warning(f"⚠️ Ошибка миграции данных analyses: {e}")
        
        await db.commit()
        
        # Проверяем, есть ли пользователи
        cursor = await db.execute("SELECT COUNT(*) FROM users")
        user_count = (await cursor.fetchone())[0]
        logger.info(f"👥 Количество пользователей в базе: {user_count}")
        
        if user_count > 0:
            # Показываем первых нескольких пользователей
            cursor = await db.execute("""
                SELECT telegram_id, username, is_admin 
                FROM users 
                LIMIT 5
            """)
            users = await cursor.fetchall()
            logger.info("👤 Первые пользователи:")
            for user in users:
                logger.info(f"  - ID: {user[0]}, Username: {user[1]}, Admin: {user[2]}")
        
        # Проверяем количество анализов
        cursor = await db.execute("SELECT COUNT(*) FROM analyses")
        analyses_count = (await cursor.fetchone())[0]
        logger.info(f"📊 Количество анализов в базе: {analyses_count}")

async def main():
    """Основная функция"""
    try:
        await check_and_fix_database()
        logger.info("🎉 Проверка завершена успешно!")
    except Exception as e:
        logger.error(f"❌ Ошибка: {e}")

if __name__ == "__main__":
    asyncio.run(main())