"""
Настройка логирования для ЖКХ Контроль бота
"""

import logging
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional
from config import settings


def setup_logging():
    """Настройка системы логирования"""
    
    # Создаем директорию для логов если её нет
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    
    # Настройка уровня логирования
    log_level = getattr(logging, settings.log_level.upper(), logging.INFO)
    
    # Формат логов
    log_format = "[%(asctime)s] %(levelname)s [%(name)s:%(lineno)d] %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"
    
    # Настройка корневого логгера
    logging.basicConfig(
        level=log_level,
        format=log_format,
        datefmt=date_format,
        handlers=[
            # Консольный вывод
            logging.StreamHandler(sys.stdout),
            
            # Файл с общими логами
            logging.FileHandler(
                log_dir / f"zhkh_control_{datetime.now().strftime('%Y%m%d')}.log",
                encoding='utf-8'
            ),
            
            # Отдельный файл для ошибок
            logging.FileHandler(
                log_dir / f"errors_{datetime.now().strftime('%Y%m%d')}.log",
                encoding='utf-8'
            )
        ]
    )
    
    # Настройка логгера для ошибок
    error_logger = logging.getLogger('errors')
    error_handler = logging.FileHandler(
        log_dir / f"errors_{datetime.now().strftime('%Y%m%d')}.log",
        encoding='utf-8'
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(logging.Formatter(log_format, date_format))
    error_logger.addHandler(error_handler)
    
    # Отключаем избыточные логи от библиотек
    logging.getLogger('aiogram').setLevel(logging.WARNING)
    logging.getLogger('aiohttp').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    
    # Логгер для бизнес-логики
    business_logger = logging.getLogger('business')
    business_handler = logging.FileHandler(
        log_dir / f"business_{datetime.now().strftime('%Y%m%d')}.log",
        encoding='utf-8'
    )
    business_handler.setFormatter(logging.Formatter(log_format, date_format))
    business_logger.addHandler(business_handler)
    
    logger = logging.getLogger(__name__)
    logger.info(f"🚀 Система логирования настроена (уровень: {settings.log_level})")
    logger.info(f"📁 Логи сохраняются в: {log_dir.absolute()}")


def get_logger(name: str) -> logging.Logger:
    """Получить логгер для модуля"""
    return logging.getLogger(name)


def log_user_action(user_id: int, action: str, details: str = ""):
    """Логирование действий пользователя"""
    business_logger = logging.getLogger('business')
    business_logger.info(f"USER_ACTION | {user_id} | {action} | {details}")


def log_analysis_start(user_id: int, file_name: str, file_size: int):
    """Логирование начала анализа"""
    business_logger = logging.getLogger('business')
    business_logger.info(f"ANALYSIS_START | {user_id} | {file_name} | {file_size} bytes")


def log_analysis_complete(user_id: int, file_name: str, duration: float, violations_count: int):
    """Логирование завершения анализа"""
    business_logger = logging.getLogger('business')
    business_logger.info(
        f"ANALYSIS_COMPLETE | {user_id} | {file_name} | "
        f"{duration:.2f}s | {violations_count} violations"
    )


def log_error(user_id: int, error_type: str, error_details: str):
    """Логирование ошибок"""
    error_logger = logging.getLogger('errors')
    error_logger.error(f"USER_ERROR | {user_id} | {error_type} | {error_details}")


class PerformanceLogger:
    """Класс для измерения производительности операций"""
    
    def __init__(self, operation_name: str, user_id: Optional[int] = None):
        self.operation_name = operation_name
        self.user_id = user_id
        self.logger = logging.getLogger('performance')
        self.start_time: Optional[float] = None
    
    def __enter__(self):
        import time
        self.start_time = time.time()
        self.logger.info(f"PERF_START | {self.operation_name} | User: {self.user_id}")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        import time
        if self.start_time is not None:
            duration = time.time() - self.start_time
        else:
            duration = 0.0
        
        if exc_type is None:
            self.logger.info(
                f"PERF_COMPLETE | {self.operation_name} | "
                f"User: {self.user_id} | Duration: {duration:.2f}s"
            )
        else:
            self.logger.error(
                f"PERF_ERROR | {self.operation_name} | "
                f"User: {self.user_id} | Duration: {duration:.2f}s | Error: {exc_type.__name__}"
            )