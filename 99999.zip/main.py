# -*- coding: utf-8 -*-
"""
Главная точка входа для Telegram Bot ЖКХ Контроль
"""

import asyncio
import logging

try:
    from aiogram import Bot, Dispatcher
    from aiogram.fsm.storage.memory import MemoryStorage
except ImportError as e:
    print("Error importing aiogram: %s" % str(e))
    print("Install dependencies: pip install aiogram")
    exit(1)

from config import settings

try:
    from bot.middleware import setup_middleware
    from handlers import register_handlers
except ImportError as e:
    print("Error importing modules: %s" % str(e))
    print("Check project structure")
    exit(1)

from utils.logger import setup_logging
from database.connection import init_database
from services.task_scheduler import init_scheduler
from services.notification_service import start_notification_scheduler
from bot.rate_limiting_middleware import start_rate_limit_cleanup
from services.cache_service import cache_service, start_cache_cleanup
from services.progress_service import start_progress_cleanup


async def main():
    """Основная функция запуска бота"""
    
    # Настройка логирования
    setup_logging()
    logger = logging.getLogger(__name__)
    
    logger.info("🤖 Запуск ЖКХ Контроль бота...")
    
    # Инициализация бота и диспетчера
    bot = Bot(token=settings.telegram_bot_token)
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)
    
    # Настройка middleware
    setup_middleware(dp)
    
    # Регистрация обработчиков
    register_handlers(dp)
    
    # Инициализация базы данных
    await init_database()
    
    # Инициализация кэша
    await cache_service.init_cache_table()
    
    # Инициализация и запуск планировщика задач
    scheduler = init_scheduler(bot)
    await scheduler.start()
    # Запуск фоновго планировщика умных напоминаний
    await start_notification_scheduler(bot)
    
    # Запуск фоновой задачи очистки rate limiting
    asyncio.create_task(start_rate_limit_cleanup())
    
    # Запуск фоновой задачи очистки кэша
    asyncio.create_task(start_cache_cleanup())
    
    # Запуск фоновой задачи очистки прогресс-баров
    asyncio.create_task(start_progress_cleanup())
    
    try:
        logger.info("✅ Бот успешно запущен и готов к работе!")
        
        # Запуск polling
        await dp.start_polling(
            bot,
            allowed_updates=["message", "callback_query", "inline_query"],
            skip_updates=True
        )
        
    except Exception as e:
        logger.error("Error starting bot: %s" % str(e))
        raise
    finally:
        logger.info("🛑 Остановка бота...")
        
        # Останавливаем планировщик
        try:
            if 'scheduler' in locals():
                await scheduler.stop()
        except Exception as e:
            logger.error(f"⚠️ Ошибка остановки планировщика: {e}")
        
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("👋 Бот остановлен пользователем")
    except Exception as e:
        print("Critical error: %s" % str(e))