#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script to debug database contents directly
"""

import asyncio
import sys
import os
import aiosqlite
import json

# Add the project root to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database.connection import database

async def debug_database():
    """Debug the database contents directly"""
    print("🔍 Debugging database contents...")
    
    try:
        # Connect to the database
        async with aiosqlite.connect(database.db_path) as db:
            # Get all users
            cursor = await db.execute("SELECT id, telegram_id, username, first_name FROM users")
            users = await cursor.fetchall()
            print(f"👥 Found {len(users)} users:")
            for user in users:
                print(f"   ID: {user[0]}, Telegram ID: {user[1]}, Username: {user[2]}, Name: {user[3]}")
            
            # Get all analyses
            cursor = await db.execute("""
                SELECT id, user_id, file_name, status, violations_count, total_overpayment 
                FROM analyses 
                ORDER BY analysis_started_at DESC
            """)
            analyses = await cursor.fetchall()
            print(f"\n📊 Found {len(analyses)} analyses:")
            for analysis in analyses:
                print(f"   ID: {analysis[0]}, User ID: {analysis[1]}, File: {analysis[2]}")
                print(f"   Status: {analysis[3]}, Violations: {analysis[4]}, Overpayment: {analysis[5]}")
            
            # Check if analysis ID 2 exists
            cursor = await db.execute("""
                SELECT id, user_id, file_name, status, result_json 
                FROM analyses 
                WHERE id = 2
            """)
            analysis = await cursor.fetchone()
            if analysis:
                print(f"\n🔍 Analysis ID 2 found:")
                print(f"   ID: {analysis[0]}, User ID: {analysis[1]}, File: {analysis[2]}")
                print(f"   Status: {analysis[3]}")
                if analysis[4]:  # result_json
                    try:
                        result = json.loads(analysis[4])
                        print(f"   Result keys: {list(result.keys())}")
                        print(f"   Services count: {len(result.get('services', []))}")
                        print(f"   Violations count: {len(result.get('violations', []))}")
                    except json.JSONDecodeError:
                        print("   Result JSON is invalid")
                else:
                    print("   No result JSON found")
            else:
                print(f"\n❌ Analysis ID 2 not found in database")
                
    except Exception as e:
        print(f"❌ Error debugging database: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(debug_database())